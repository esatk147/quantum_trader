# portfolio/optimizer.py
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime, timedelta
import asyncio
from core.logger import logger
from core.config import config
from portfolio.correlation import CorrelationAnalyzer
from portfolio.risk_parity import RiskParityOptimizer


class PortfolioOptimizer:
    """Modern Portföy Teorisi İmplementasyonu"""
    
    def __init__(self, exchange):
        self.exchange = exchange
        self.correlation_analyzer = CorrelationAnalyzer()
        self.risk_parity = RiskParityOptimizer()
        self.cache: Dict[str, Dict] = {}
        self.cache_ttl = timedelta(minutes=15)
        
        # İyileştirme parametreleri
        self.min_weight = 0.01  # Minimum ağırlık %1
        self.max_weight = 0.30  # Maksimum ağırlık %30
        self.max_variance = 0.04  # Maksimum yıllık varyans %4
        self.min_expected_return = 0.05  # Minimum beklenen yıllık getiri %5
        
    async def optimize_portfolio(self, 
                               watchlist: List[str], 
                               available_capital: float,
                               current_positions: Optional[Dict[str, Any]] = None,
                               method: str = 'risk_parity') -> Dict[str, Dict[str, float]]:
        """
        Portföyü optimize et
        methods: 'risk_parity', 'mean_variance', 'equal_weight', 'volatility_weighted'
        """
        try:
            current_positions = current_positions or {}
            
            # Cache kontrolü
            cache_key = f"{'-'.join(watchlist)}_{method}_{available_capital}"
            if self._check_cache(cache_key):
                return self.cache[cache_key]['allocation']
            
            # Veri toplama
            returns_df, covariance_matrix = await self._collect_market_data(watchlist)
            if returns_df.empty or covariance_matrix.empty:
                logger.warning("Insufficient market data for optimization")
                return self._equal_weight_allocation(watchlist, available_capital)
            
            # Optimizasyon yöntemini seç
            if method == 'risk_parity':
                allocation = self._risk_parity_optimization(watchlist, covariance_matrix, available_capital)
            elif method == 'mean_variance':
                expected_returns = self._estimate_returns(returns_df)
                allocation = self._mean_variance_optimization(
                    watchlist, expected_returns, covariance_matrix, available_capital
                )
            elif method == 'volatility_weighted':
                allocation = self._volatility_weighted_allocation(watchlist, covariance_matrix, available_capital)
            else:
                allocation = self._equal_weight_allocation(watchlist, available_capital)
            
            # Mevcut pozisyonları dikkate al
            adjusted_allocation = self._adjust_for_current_positions(allocation, current_positions)
            
            # Cache'e kaydet
            self.cache[cache_key] = {
                'allocation': adjusted_allocation,
                'timestamp': datetime.utcnow(),
                'method': method
            }
            
            return adjusted_allocation
            
        except Exception as e:
            logger.error(f"Portfolio optimization failed: {e}")
            return self._equal_weight_allocation(watchlist, available_capital)
    
    async def _collect_market_data(self, symbols: List[str], timeframe: str = '1h', lookback: int = 200) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Piyasa verisini topla"""
        try:
            returns_data = {}
            
            for symbol in symbols:
                df = await self._get_price_data(symbol, timeframe, lookback)
                if not df.empty:
                    returns = df['close'].pct_change().dropna()
                    returns_data[symbol] = returns
            
            if not returns_data:
                return pd.DataFrame(), pd.DataFrame()
            
            returns_df = pd.DataFrame(returns_data)
            covariance_matrix = returns_df.cov()
            
            return returns_df, covariance_matrix
            
        except Exception as e:
            logger.error(f"Error collecting market data: {e}")
            return pd.DataFrame(), pd.DataFrame()
    
    async def _get_price_data(self, symbol: str, timeframe: str, limit: int) -> pd.DataFrame:
        """Fiyat verisini al"""
        try:
            # Asenkron veri çekme
            loop = asyncio.get_event_loop()
            ohlcv = await loop.run_in_executor(
                None, 
                self.exchange.fetch_ohlcv, 
                symbol, 
                timeframe, 
                limit
            )
            
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            
            return df
            
        except Exception as e:
            logger.error(f"Failed to fetch data for {symbol}: {e}")
            return pd.DataFrame()
    
    def _risk_parity_optimization(self, symbols: List[str], covariance_matrix: pd.DataFrame, capital: float) -> Dict[str, Dict[str, float]]:
        """Risk paritesi optimizasyonu"""
        try:
            weights = self.risk_parity.calculate_weights(covariance_matrix)
            return self._calculate_position_sizes(symbols, weights, capital)
            
        except Exception as e:
            logger.error(f"Risk parity optimization failed: {e}")
            return self._equal_weight_allocation(symbols, capital)
    
    def _mean_variance_optimization(self, 
                                  symbols: List[str], 
                                  expected_returns: pd.Series, 
                                  covariance_matrix: pd.DataFrame, 
                                  capital: float,
                                  target_return: float = None) -> Dict[str, Dict[str, float]]:
        """Modern portföy teorisi optimizasyonu"""
        try:
            n_assets = len(symbols)
            
            # Optimizasyon problemi
            def portfolio_variance(weights):
                return weights.T @ covariance_matrix @ weights
            
            def portfolio_return(weights):
                return np.sum(expected_returns.values * weights) * 252  # Yıllıklaştırma
            
            # Kısıtlar
            constraints = [
                {'type': 'eq', 'fun': lambda x: np.sum(x) - 1},  # Toplam ağırlık = 1
            ]
            
            if target_return is not None:
                constraints.append({
                    'type': 'eq', 
                    'fun': lambda x: portfolio_return(x) - target_return
                })
            
            # Sınırlar
            bounds = [(self.min_weight, self.max_weight) for _ in range(n_assets)]
            
            # İlk tahmin
            initial_weights = np.array([1.0 / n_assets] * n_assets)
            
            # Optimizasyon
            result = minimize(
                portfolio_variance,
                initial_weights,
                method='SLSQP',
                bounds=bounds,
                constraints=constraints,
                options={'disp': False, 'maxiter': 1000}
            )
            
            if result.success:
                weights_dict = dict(zip(symbols, result.x))
                return self._calculate_position_sizes(symbols, weights_dict, capital)
            else:
                logger.warning(f"Mean-variance optimization failed: {result.message}")
                return self._equal_weight_allocation(symbols, capital)
                
        except Exception as e:
            logger.error(f"Mean-variance optimization failed: {e}")
            return self._equal_weight_allocation(symbols, capital)
    
    def _volatility_weighted_allocation(self, symbols: List[str], covariance_matrix: pd.DataFrame, capital: float) -> Dict[str, Dict[str, float]]:
        """Volatiliteye göre ağırlıklandırma"""
        try:
            # Her varlığın volatilitesini hesapla
            volatilities = {}
            for symbol in symbols:
                volatilities[symbol] = np.sqrt(covariance_matrix.loc[symbol, symbol])
            
            # Inverse volatility weights
            inv_vol_weights = {}
            total_inv_vol = 0
            for symbol, vol in volatilities.items():
                inv_vol_weights[symbol] = 1.0 / vol if vol > 0 else 1.0
                total_inv_vol += inv_vol_weights[symbol]
            
            # Normalize weights
            weights = {symbol: w / total_inv_vol for symbol, w in inv_vol_weights.items()}
            
            return self._calculate_position_sizes(symbols, weights, capital)
            
        except Exception as e:
            logger.error(f"Volatility weighted allocation failed: {e}")
            return self._equal_weight_allocation(symbols, capital)
    
    def _equal_weight_allocation(self, symbols: List[str], capital: float) -> Dict[str, Dict[str, float]]:
        """Eşit ağırlıklı dağılım"""
        equal_weight = 1.0 / len(symbols)
        weights = {symbol: equal_weight for symbol in symbols}
        return self._calculate_position_sizes(symbols, weights, capital)
    
    def _calculate_position_sizes(self, symbols: List[str], weights: Dict[str, float], capital: float) -> Dict[str, Dict[str, float]]:
        """Pozisyon büyüklüklerini hesapla"""
        allocation = {}
        total_allocated = 0
        
        for symbol in symbols:
            weight = weights.get(symbol, 0)
            
            # Pozisyon boyutu
            position_size = capital * weight
            
            # Minimum ve maksimum kontrolleri
            min_position = capital * self.min_weight
            max_position = capital * self.max_weight
            
            position_size = max(min_position, min(position_size, max_position))
            total_allocated += position_size
            
            allocation[symbol] = {
                'size': position_size,
                'weight': weight,
                'max_position': max_position,
                'min_position': min_position
            }
        
        # Kalan sermayeyi orantılı dağıt
        if total_allocated < capital and allocation:
            remaining = capital - total_allocated
            for symbol in allocation:
                allocation[symbol]['size'] += remaining * weights[symbol]
        
        return allocation
    
    def _adjust_for_current_positions(self, allocation: Dict[str, Dict[str, float]], current_positions: Dict[str, Dict[str, float]]) -> Dict[str, Dict[str, float]]:
        """Mevcut pozisyonları dikkate al"""
        adjusted_allocation = allocation.copy()
        
        for symbol, position in allocation.items():
            current_size = 0
            
            # Pozisyon büyüklüğünü hesapla
            for open_pos in current_positions.values():
                if open_pos.get('symbol') == symbol:
                    current_size += open_pos.get('position_size', 0)
            
            target_size = position['size']
            
            # Değişiklik eşiği (%10)
            change_threshold = 0.1
            
            if current_size > 0:
                change_pct = abs(target_size - current_size) / current_size
                
                if change_pct < change_threshold:
                    # Küçük değişiklikler için mevcut pozisyonu koru
                    adjusted_allocation[symbol]['size'] = current_size
                    adjusted_allocation[symbol]['action'] = 'hold'
                else:
                    adjusted_allocation[symbol]['action'] = 'adjust'
                    adjusted_allocation[symbol]['change'] = target_size - current_size
            else:
                adjusted_allocation[symbol]['action'] = 'open'
        
        return adjusted_allocation
    
    def _estimate_returns(self, returns_df: pd.DataFrame, method: str = 'exponential') -> pd.Series:
        """Beklenen getirileri tahmin et"""
        if method == 'exponential':
            return returns_df.ewm(span=20).mean().iloc[-1] * 252  # Yıllıklaştırma
        elif method == 'historical':
            return returns_df.mean() * 252
        else:
            return returns_df.ewm(span=20).mean().iloc[-1] * 252
    
    def _check_cache(self, key: str) -> bool:
        """Cache geçerliliğini kontrol et"""
        if key in self.cache:
            cache_data = self.cache[key]
            if datetime.utcnow() - cache_data['timestamp'] < self.cache_ttl:
                return True
            else:
                del self.cache[key]
        return False
    
    def calculate_portfolio_metrics(self, allocation: Dict[str, Dict[str, float]], covariance_matrix: pd.DataFrame, expected_returns: pd.Series) -> Dict[str, float]:
        """Portföy metriklerini hesapla"""
        try:
            symbols = list(allocation.keys())
            weights = np.array([allocation[symbol]['weight'] for symbol in symbols])
            
            # Portföy varyansı
            portfolio_variance = weights.T @ covariance_matrix @ weights
            portfolio_std = np.sqrt(portfolio_variance) * np.sqrt(252)  # Yıllık std
            
            # Portföy getirisi
            portfolio_return = np.sum(expected_returns.values * weights) * 252
            
            # Sharpe oranı (risk-free rate = 0.02 varsayımı)
            sharpe_ratio = (portfolio_return - 0.02) / portfolio_std if portfolio_std > 0 else 0
            
            # Korelasyon riski
            avg_correlation = covariance_matrix.values[np.triu_indices(len(covariance_matrix), k=1)].mean()
            correlation_risk = avg_correlation * np.std(weights)
            
            return {
                'expected_return': portfolio_return,
                'volatility': portfolio_std,
                'sharpe_ratio': sharpe_ratio,
                'max_drawdown': self._estimate_max_drawdown(weights, covariance_matrix),
                'correlation_risk': correlation_risk,
                'diversification_ratio': 1 - (weights ** 2).sum()
            }
            
        except Exception as e:
            logger.error(f"Failed to calculate portfolio metrics: {e}")
            return {}
    
    def _estimate_max_drawdown(self, weights: np.array, covariance_matrix: pd.DataFrame, scenarios: int = 1000) -> float:
        """Potansiyel maksimum drawdown'u tahmin et"""
        try:
            # Monte Carlo simulasyonu
            simulated_returns = np.random.multivariate_normal(
                mean=np.zeros(len(weights)),
                cov=covariance_matrix,
                size=scenarios
            )
            
            portfolio_returns = np.sum(simulated_returns * weights, axis=1)
            cumulative_returns = np.cumsum(portfolio_returns)
            
            # Drawdown hesaplama
            running_max = np.maximum.accumulate(cumulative_returns)
            drawdowns = (cumulative_returns - running_max) / running_max
            
            return np.min(drawdowns) * np.sqrt(252)  # Yıllıklaştırma
            
        except Exception as e:
            logger.error(f"Max drawdown estimation failed: {e}")
            return 0.20  # Varsayılan %20
    
    def rebalance_portfolio(self, current_allocation: Dict[str, Dict[str, float]], target_allocation: Dict[str, Dict[str, float]]) -> List[Dict[str, Any]]:
        """Portföy yeniden dengeleme eylemlerini belirle"""
        rebalance_actions = []
        
        # Mevcut pozisyonları kontrol et
        current_positions = set(current_allocation.keys())
        target_positions = set(target_allocation.keys())
        
        # Kapatılacak pozisyonlar
        for symbol in current_positions - target_positions:
            rebalance_actions.append({
                'action': 'close',
                'symbol': symbol,
                'current_size': current_allocation[symbol]['size'],
                'target_size': 0,
                'priority': 1.0
            })
        
        # Yeni açılacak pozisyonlar
        for symbol in target_positions - current_positions:
            rebalance_actions.append({
                'action': 'open',
                'symbol': symbol,
                'current_size': 0,
                'target_size': target_allocation[symbol]['size'],
                'priority': 0.8
            })
        
        # Ayarlanacak pozisyonlar
        for symbol in current_positions.intersection(target_positions):
            current_size = current_allocation[symbol]['size']
            target_size = target_allocation[symbol]['size']
            
            if abs(target_size - current_size) > current_size * 0.05:  # %5 eşiği
                change_pct = (target_size - current_size) / current_size
                action = 'increase' if change_pct > 0 else 'decrease'
                
                rebalance_actions.append({
                    'action': action,
                    'symbol': symbol,
                    'current_size': current_size,
                    'target_size': target_size,
                    'change_pct': change_pct,
                    'priority': abs(change_pct)
                })
        
        # Önceliğe göre sırala
        rebalance_actions.sort(key=lambda x: x['priority'], reverse=True)
        
        return rebalance_actions