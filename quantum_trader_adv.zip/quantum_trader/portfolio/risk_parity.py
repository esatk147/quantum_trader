# portfolio/risk_parity.py
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from typing import Dict, Any, List, Union, Optional
from core.logger import logger


class RiskParityOptimizer:
    """Risk Paritesi Optimizasyon Sistemi"""
    
    def __init__(self):
        self.min_weight = 0.01  # Minimum %1
        self.max_weight = 0.30  # Maksimum %30
        self.max_iterations = 1000
        self.convergence_tol = 1e-10
        
    def calculate_weights(self, covariance_matrix: Union[pd.DataFrame, np.ndarray]) -> Dict[str, float]:
        """Risk paritesi ağırlıklarını hesapla"""
        try:
            # DataFrame'i numpy array'e çevir
            if isinstance(covariance_matrix, pd.DataFrame):
                symbols = list(covariance_matrix.columns)
                cov_array = covariance_matrix.values
            else:
                cov_array = np.array(covariance_matrix)
                symbols = [f"Asset_{i}" for i in range(len(cov_array))]
            
            n_assets = len(symbols)
            
            # Eşit ağırlıklarla başla
            initial_weights = np.array([1.0 / n_assets] * n_assets)
            
            # Risk paritesi optimizasyonu
            optimal_weights = self._optimize_risk_parity(cov_array, initial_weights)
            
            # Ağırlıkları normalize et
            optimal_weights = self._normalize_weights(optimal_weights)
            
            # Dictionary olarak döndür
            weights_dict = dict(zip(symbols, optimal_weights))
            
            return weights_dict
            
        except Exception as e:
            logger.error(f"Risk parity calculation failed: {e}")
            return self._equal_weight_fallback(symbols if 'symbols' in locals() else [])
    
    def _optimize_risk_parity(self, covariance_matrix: np.ndarray, initial_weights: np.ndarray) -> np.ndarray:
        """Risk paritesi optimizasyonu"""
        try:
            n_assets = len(initial_weights)
            
            # İtme fonksiyonu
            def risk_parity_objective(weights):
                """Risk kontribüsyonları arasındaki farkı minimize et"""
                # Portföy volatilitesi
                portfolio_volatility = np.sqrt(weights.T @ covariance_matrix @ weights)
                
                # Marjinal risk kontribüsyonları
                marginal_risk_contributions = covariance_matrix @ weights / portfolio_volatility
                
                # Risk kontribüsyonları
                risk_contributions = weights * marginal_risk_contributions
                
                # Hedef kontribüsyon (%1/N her varlık için)
                target_contrib = portfolio_volatility / n_assets
                
                # Hedef ile gerçek arasındaki farkı minimize et
                risk_diffs = risk_contributions - target_contrib
                
                # Karelerin toplamını döndür
                return np.sum(risk_diffs ** 2)
            
            # Kısıtlar
            constraints = [
                # Toplam ağırlık = 1
                {'type': 'eq', 'fun': lambda x: np.sum(x) - 1}
            ]
            
            # Ağırlık sınırları
            bounds = [(self.min_weight, self.max_weight) for _ in range(n_assets)]
            
            # Optimizasyon
            result = minimize(
                risk_parity_objective,
                initial_weights,
                method='SLSQP',
                bounds=bounds,
                constraints=constraints,
                options={
                    'disp': False,
                    'maxiter': self.max_iterations,
                    'ftol': self.convergence_tol
                }
            )
            
            if not result.success:
                logger.warning(f"Risk parity optimization warning: {result.message}")
                # Gradyan inişi ile yeniden deneyin
                return self._gradient_descent_fallback(covariance_matrix, initial_weights)
            
            return result.x
            
        except Exception as e:
            logger.error(f"Risk parity optimization error: {e}")
            return self._gradient_descent_fallback(covariance_matrix, initial_weights)
    
    def _gradient_descent_fallback(self, covariance_matrix: np.ndarray, initial_weights: np.ndarray) -> np.ndarray:
        """Gradyan inişi ile risk paritesi"""
        try:
            weights = initial_weights.copy()
            learning_rate = 0.01
            max_iterations = 500
            
            for i in range(max_iterations):
                # Portföy volatilitesi
                portfolio_vol = np.sqrt(weights.T @ covariance_matrix @ weights)
                
                # Marjinal risk kontribüsyonları
                marginal_contrib = covariance_matrix @ weights / portfolio_vol
                
                # Risk kontribüsyonları
                risk_contrib = weights * marginal_contrib
                
                # Hedef kontribüsyondan sapmalar
                target_contrib = portfolio_vol / len(weights)
                gradient = 2 * (risk_contrib - target_contrib) * marginal_contrib
                
                # Ağırlıkları güncelle
                weights = weights - learning_rate * gradient
                
                # Pozitif ve sınır kontrolü
                weights = np.maximum(weights, self.min_weight)
                weights = np.minimum(weights, self.max_weight)
                
                # Normalize et
                weights = weights / np.sum(weights)
                
                # Yakınsama kontrolü
                if np.linalg.norm(gradient) < self.convergence_tol:
                    break
            
            return weights
            
        except Exception as e:
            logger.error(f"Gradient descent fallback failed: {e}")
            return initial_weights / np.sum(initial_weights)
    
    def _normalize_weights(self, weights: np.ndarray) -> np.ndarray:
        """Ağırlıkları normalize et"""
        # Küçük değerleri sıfıra çek
        weights[weights < self.min_weight] = self.min_weight
        
        # Büyük değerleri sınırla
        weights[weights > self.max_weight] = self.max_weight
        
        # Toplam 1 olacak şekilde normalize et
        return weights / np.sum(weights)
    
    def _equal_weight_fallback(self, symbols: List[str]) -> Dict[str, float]:
        """Eşit ağırlık geri dönüş"""
        if not symbols:
            return {}
        
        equal_weight = 1.0 / len(symbols)
        return {symbol: equal_weight for symbol in symbols}
    
    def calculate_risk_contributions(self, 
                                   weights: Union[Dict[str, float], np.ndarray], 
                                   covariance_matrix: Union[pd.DataFrame, np.ndarray]) -> Dict[str, float]:
        """Risk kontribüsyonlarını hesapla"""
        try:
            # Ağırlıkları numpy array'e çevir
            if isinstance(weights, dict):
                symbols = list(weights.keys())
                weights_array = np.array([weights[symbol] for symbol in symbols])
            else:
                weights_array = np.array(weights)
                symbols = [f"Asset_{i}" for i in range(len(weights_array))]
            
            # Kovaryans matrisini numpy array'e çevir
            if isinstance(covariance_matrix, pd.DataFrame):
                cov_array = covariance_matrix.values
            else:
                cov_array = np.array(covariance_matrix)
            
            # Portföy volatilitesi
            portfolio_vol = np.sqrt(weights_array.T @ cov_array @ weights_array)
            
            # Marjinal risk kontribüsyonları
            marginal_contrib = cov_array @ weights_array / portfolio_vol
            
            # Risk kontribüsyonları (yüzde olarak)
            risk_contrib = weights_array * marginal_contrib * 100
            
            return dict(zip(symbols, risk_contrib))
            
        except Exception as e:
            logger.error(f"Risk contribution calculation failed: {e}")
            return {}
    
    def validate_risk_parity(self, 
                           weights: Dict[str, float], 
                           covariance_matrix: pd.DataFrame, 
                           tolerance: float = 0.01) -> bool:
        """Risk paritesi dağılımını doğrula"""
        try:
            risk_contrib = self.calculate_risk_contributions(weights, covariance_matrix)
            
            if not risk_contrib:
                return False
            
            # Tüm risk kontribüsyonları yaklaşık eşit mi?
            contrib_values = list(risk_contrib.values())
            mean_contrib = np.mean(contrib_values)
            
            for contrib in contrib_values:
                if abs(contrib - mean_contrib) > tolerance * mean_contrib:
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"Risk parity validation failed: {e}")
            return False


class AdaptiveRiskParity(RiskParityOptimizer):
    """Adaptif Risk Paritesi"""
    
    def __init__(self, 
                 market_regime_threshold: float = 0.25,
                 min_volatility_ratio: float = 0.5,
                 max_volatility_ratio: float = 2.0):
        super().__init__()
        self.market_regime_threshold = market_regime_threshold
        self.min_volatility_ratio = min_volatility_ratio
        self.max_volatility_ratio = max_volatility_ratio
    
    def calculate_adaptive_weights(self, 
                                 covariance_matrix: pd.DataFrame,
                                 market_indicators: Dict[str, float]) -> Dict[str, float]:
        """Piyasa koşullarına göre uyarlanmış ağırlıklar"""
        try:
            # Temel risk paritesi ağırlıkları
            base_weights = self.calculate_weights(covariance_matrix)
            
            # Piyasa volatilitesi kontrolü
            volatility_regime = self._detect_volatility_regime(covariance_matrix)
            
            # Adaptasyonlar
            adapted_weights = base_weights.copy()
            
            # Yüksek volatilite: Riski azalt
            if volatility_regime > 1.0:
                risk_reduction = min(volatility_regime - 1.0, 0.5)
                for symbol in adapted_weights:
                    # Risk azaltma: minimum ağırlığa yaklaştır
                    adapted_weights[symbol] *= (1 - risk_reduction * 0.5)
            
            # Düşük volatilite: Riski artır
            elif volatility_regime < 1.0:
                risk_increase = min(1.0 - volatility_regime, 0.5)
                for symbol in adapted_weights:
                    # Risk artırma: maksimum ağırlığa yaklaştır
                    adapted_weights[symbol] *= (1 + risk_increase * 0.5)
            
            # Ağırlıkları normalize et
            adapted_weights = self._normalize_weights(np.array(list(adapted_weights.values())))
            
            return dict(zip(base_weights.keys(), adapted_weights))
            
        except Exception as e:
            logger.error(f"Adaptive risk parity failed: {e}")
            return base_weights if 'base_weights' in locals() else {}
    
    def _detect_volatility_regime(self, covariance_matrix: pd.DataFrame, lookback: int = 20) -> float:
        """Volatilite rejimini tespit et"""
        try:
            # Portföy volatilitesini hesapla
            equal_weights = np.ones(len(covariance_matrix)) / len(covariance_matrix)
            current_vol = np.sqrt(equal_weights.T @ covariance_matrix @ equal_weights)
            
            # Tarihsel ortalamaya oranla
            historical_vol_mean = 0.15  # Varsayılan tarihsel ortalama
            volatility_regime = current_vol / historical_vol_mean
            
            return np.clip(volatility_regime, self.min_volatility_ratio, self.max_volatility_ratio)
            
        except Exception as e:
            logger.error(f"Volatility regime detection failed: {e}")
            return 1.0