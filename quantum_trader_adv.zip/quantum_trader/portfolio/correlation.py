# portfolio/correlation.py
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import asyncio
from concurrent.futures import ThreadPoolExecutor
import networkx as nx
from sklearn.decomposition import PCA
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster
from scipy.spatial.distance import squareform
from core.logger import logger


class CorrelationAnalyzer:
    """Varlık Korelasyon Analizi Sistemi"""
    
    def __init__(self):
        self.correlation_cache: Dict[str, Dict] = {}
        self.cache_ttl = timedelta(hours=1)
        self.min_data_points = 50
        
    async def get_crypto_correlations(self, 
                                    exchange, 
                                    symbols: List[str], 
                                    timeframe: str = '1h', 
                                    limit: int = 100) -> Dict[str, Dict[str, float]]:
        """Kripto varlıkları arasındaki korelasyonları hesapla"""
        try:
            # Cache kontrolü
            cache_key = f"{'-'.join(symbols)}_{timeframe}_{limit}"
            if self._check_cache(cache_key):
                return self.correlation_cache[cache_key]['data']
            
            # Asenkron veri toplama
            price_data = await self._collect_price_data(exchange, symbols, timeframe, limit)
            
            if not price_data:
                return {}
            
            # Korelasyon matrisi oluştur
            correlation_matrix = self._calculate_correlation_matrix(price_data)
            
            # Cache'e kaydet
            self.correlation_cache[cache_key] = {
                'data': correlation_matrix,
                'timestamp': datetime.utcnow()
            }
            
            return correlation_matrix
            
        except Exception as e:
            logger.error(f"Correlation analysis failed: {e}")
            return {}
    
    async def _collect_price_data(self, 
                                exchange, 
                                symbols: List[str], 
                                timeframe: str, 
                                limit: int) -> Dict[str, pd.Series]:
        """Fiyat verilerini asenkron topla"""
        price_data = {}
        
        async def fetch_data(symbol):
            try:
                loop = asyncio.get_event_loop()
                ohlcv = await loop.run_in_executor(
                    None, 
                    exchange.fetch_ohlcv, 
                    symbol, 
                    timeframe, 
                    limit
                )
                
                df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
                returns = df['close'].pct_change().dropna()
                
                if len(returns) >= self.min_data_points:
                    return symbol, returns
                else:
                    logger.warning(f"Insufficient data for {symbol}: {len(returns)} points")
                    return symbol, None
                    
            except Exception as e:
                logger.error(f"Failed to fetch data for {symbol}: {e}")
                return symbol, None
        
        # Paralel veri toplama
        tasks = [fetch_data(symbol) for symbol in symbols]
        results = await asyncio.gather(*tasks)
        
        for symbol, returns in results:
            if returns is not None:
                price_data[symbol] = returns
        
        return price_data
    
    def _calculate_correlation_matrix(self, price_data: Dict[str, pd.Series]) -> Dict[str, Dict[str, float]]:
        """Korelasyon matrisini hesapla"""
        if not price_data:
            return {}
            
        # DataFrame oluştur
        df = pd.DataFrame(price_data)
        
        # Korelasyon matrisi
        correlation_matrix = df.corr()
        
        # Dictionary'e çevir
        return correlation_matrix.to_dict()
    
    def analyze_pair_correlation(self, 
                                coin1: str, 
                                coin2: str, 
                                correlation_matrix: Dict[str, Dict[str, float]]) -> Dict[str, Any]:
        """İki varlık arasındaki korelasyonu analiz et"""
        try:
            if coin1 in correlation_matrix and coin2 in correlation_matrix[coin1]:
                correlation = correlation_matrix[coin1][coin2]
                
                # Korelasyon seviyesini değerlendir
                strength = self._evaluate_correlation_strength(correlation)
                
                # Pozisyon risk analizi
                position_risk = self._calculate_position_risk(correlation)
                
                return {
                    'correlation': correlation,
                    'strength': strength,
                    'risk_level': position_risk,
                    'recommendation': self._get_recommendation(correlation)
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Pair correlation analysis failed: {e}")
            return None
    
    def _evaluate_correlation_strength(self, correlation: float) -> Dict[str, Any]:
        """Korelasyon gücünü değerlendir"""
        abs_corr = abs(correlation)
        
        if abs_corr > 0.8:
            level = "Çok Güçlü"
            significance = "Yüksek"
        elif abs_corr > 0.6:
            level = "Güçlü"
            significance = "Orta-Yüksek"
        elif abs_corr > 0.4:
            level = "Orta"
            significance = "Orta"
        elif abs_corr > 0.2:
            level = "Zayıf"
            significance = "Düşük"
        else:
            level = "Çok Zayıf"
            significance = "Çok Düşük"
        
        direction = "Pozitif" if correlation > 0 else "Negatif"
        
        return {
            'level': level,
            'direction': direction,
            'significance': significance,
            'value': abs_corr
        }
    
    def _calculate_position_risk(self, correlation: float) -> Dict[str, float]:
        """Pozisyon riskini hesapla"""
        abs_corr = abs(correlation)
        
        # Risk faktörü (yüksek pozitif korelasyon daha riskli)
        risk_factor = abs_corr if correlation > 0 else abs_corr * 0.5
        
        # Diversifikasyon faydası
        diversification_benefit = 1 - abs_corr
        
        return {
            'risk_factor': risk_factor,
            'diversification_benefit': diversification_benefit,
            'combined_risk': risk_factor * (1 - diversification_benefit)
        }
    
    def _get_recommendation(self, correlation: float) -> str:
        """Korelasyona göre öneri ver"""
        if correlation > 0.7:
            return "İlişkili varlıklarda aynı anda pozisyon almak yüksek risk taşır"
        elif correlation > 0.4:
            return "Pozisyon büyüklüklerini dikkatli belirleyin"
        elif correlation < -0.7:
            return "Tersi ilişkili varlıklar hedging için kullanılabilir"
        elif correlation < -0.4:
            return "İyi diversifikasyon fırsatı"
        else:
            return "Nötr ilişki, normal pozisyon yönetimi"
    
    def create_correlation_network(self, correlation_matrix: Dict[str, Dict[str, float]], 
                                 threshold: float = 0.5) -> nx.Graph:
        """Korelasyon ağını oluştur"""
        try:
            G = nx.Graph()
            
            symbols = list(correlation_matrix.keys())
            
            # Düğümleri ekle
            for symbol in symbols:
                G.add_node(symbol)
            
            # Kenarları ekle (güçlü korelasyonlar için)
            for i, symbol1 in enumerate(symbols):
                for j, symbol2 in enumerate(symbols[i+1:], i+1):
                    corr = correlation_matrix[symbol1][symbol2]
                    if abs(corr) > threshold:
                        G.add_edge(symbol1, symbol2, weight=abs(corr))
            
            return G
            
        except Exception as e:
            logger.error(f"Correlation network creation failed: {e}")
            return nx.Graph()
    
    def perform_cluster_analysis(self, correlation_matrix: Dict[str, Dict[str, float]], 
                               num_clusters: Optional[int] = None) -> Dict[str, List[str]]:
        """Korelasyona dayalı kümeleme analizi"""
        try:
            # Korelasyon matrisini numpy array'e çevir
            symbols = list(correlation_matrix.keys())
            corr_array = np.array([[correlation_matrix[s1][s2] for s2 in symbols] for s1 in symbols])
            
            # Mesafe matrisine çevir (1 - correlation)
            distance_matrix = 1 - corr_array
            
            # Hiyerarşik kümeleme
            linkage_matrix = linkage(squareform(distance_matrix), method='ward')
            
            # Küme sayısını belirle
            if num_clusters is None:
                num_clusters = max(2, min(5, len(symbols) // 3))
            
            # Kümeleri belirle
            clusters = fcluster(linkage_matrix, num_clusters, criterion='maxclust')
            
            # Kümeleri organize et
            cluster_groups = {}
            for i, cluster_id in enumerate(clusters):
                if cluster_id not in cluster_groups:
                    cluster_groups[cluster_id] = []
                cluster_groups[cluster_id].append(symbols[i])
            
            # Daha kullanışlı format
            result = {}
            for cluster_id, members in cluster_groups.items():
                result[f"Cluster_{cluster_id}"] = members
            
            return result
            
        except Exception as e:
            logger.error(f"Cluster analysis failed: {e}")
            return {}
    
    def perform_pca_analysis(self, price_data: Dict[str, pd.Series]) -> Dict[str, Any]:
        """Principal Component Analysis"""
        try:
            if not price_data:
                return {}
            
            # DataFrame oluştur
            df = pd.DataFrame(price_data)
            
            # Standardize et
            from sklearn.preprocessing import StandardScaler
            scaler = StandardScaler()
            scaled_data = scaler.fit_transform(df)
            
            # PCA uygula
            pca = PCA()
            pca_result = pca.fit_transform(scaled_data)
            
            # Varyans açıklaması
            explained_variance_ratio = pca.explained_variance_ratio_
            cumulative_variance_ratio = np.cumsum(explained_variance_ratio)
            
            # Principal componentlerin ağırlıkları
            components = pd.DataFrame(
                pca.components_,
                index=[f'PC{i+1}' for i in range(len(pca.components_))],
                columns=df.columns
            )
            
            return {
                'explained_variance_ratio': explained_variance_ratio.tolist(),
                'cumulative_variance_ratio': cumulative_variance_ratio.tolist(),
                'components': components.to_dict(),
                'n_components_90_variance': int(np.argmax(cumulative_variance_ratio >= 0.9) + 1)
            }
            
        except Exception as e:
            logger.error(f"PCA analysis failed: {e}")
            return {}
    
    def detect_correlation_regime_change(self, 
                                       current_correlations: Dict[str, Dict[str, float]], 
                                       historical_correlations: Dict[str, Dict[str, float]], 
                                       threshold: float = 0.2) -> Dict[str, Any]:
        """Korelasyon rejimi değişimini tespit et"""
        try:
            changes = {}
            significant_changes = []
            
            for symbol1 in current_correlations:
                if symbol1 in historical_correlations:
                    changes[symbol1] = {}
                    for symbol2 in current_correlations[symbol1]:
                        if symbol2 in historical_correlations[symbol1]:
                            current = current_correlations[symbol1][symbol2]
                            historical = historical_correlations[symbol1][symbol2]
                            
                            change = current - historical
                            changes[symbol1][symbol2] = change
                            
                            if abs(change) > threshold:
                                significant_changes.append({
                                    'pair': f"{symbol1}-{symbol2}",
                                    'change': change,
                                    'current': current,
                                    'historical': historical
                                })
            
            # En büyük değişimleri bul
            significant_changes.sort(key=lambda x: abs(x['change']), reverse=True)
            
            return {
                'all_changes': changes,
                'significant_changes': significant_changes[:10],  # Top 10
                'regime_shift_detected': len(significant_changes) > len(current_correlations) * 0.3
            }
            
        except Exception as e:
            logger.error(f"Correlation regime change detection failed: {e}")
            return {}
    
    def calculate_diversification_ratio(self, weights: Dict[str, float], 
                                      correlation_matrix: Dict[str, Dict[str, float]]) -> float:
        """Portföy diversifikasyon oranını hesapla"""
        try:
            symbols = list(weights.keys())
            n_assets = len(symbols)
            
            if n_assets <= 1:
                return 0.0
            
            # Ağırlık vektörünü oluştur
            weight_array = np.array([weights[symbol] for symbol in symbols])
            
            # Korelasyon matrisini numpy array'e çevir
            corr_array = np.array([[correlation_matrix[s1][s2] for s2 in symbols] for s1 in symbols])
            
            # Portföy korelasyonu
            portfolio_correlation = weight_array.T @ corr_array @ weight_array
            
            # Ağırlıklı ortalama korelasyon
            avg_correlation = portfolio_correlation / (weight_array.T @ weight_array)
            
            # Diversifikasyon oranı (1 - portfolio correlation)
            diversification_ratio = 1 - avg_correlation
            
            return float(diversification_ratio)
            
        except Exception as e:
            logger.error(f"Diversification ratio calculation failed: {e}")
            return 0.0
    
    def _check_cache(self, key: str) -> bool:
        """Cache geçerliliğini kontrol et"""
        if key in self.correlation_cache:
            cache_data = self.correlation_cache[key]
            if datetime.utcnow() - cache_data['timestamp'] < self.cache_ttl:
                return True
            else:
                del self.correlation_cache[key]
        return False
    
    async def analyze_correlation_breakdowns(self, 
                                           correlation_matrix: Dict[str, Dict[str, float]], 
                                           threshold: float = 0.7) -> Dict[str, Any]:
        """Korelasyon bozulmalarını analiz et"""
        try:
            breakdown_events = []
            
            for symbol1 in correlation_matrix:
                for symbol2 in correlation_matrix[symbol1]:
                    if symbol1 != symbol2:
                        corr = correlation_matrix[symbol1][symbol2]
                        
                        # Yüksek korelasyon bozulması
                        if abs(corr) < (threshold - 0.2) and abs(corr) > 0.1:
                            breakdown_events.append({
                                'pair': f"{symbol1}-{symbol2}",
                                'correlation': corr,
                                'type': 'breakdown',
                                'severity': (threshold - abs(corr)) / threshold
                            })
                        
                        # Beklenmedik güçlü korelasyon
                        elif abs(corr) > threshold and symbol1 != symbol2:
                            breakdown_events.append({
                                'pair': f"{symbol1}-{symbol2}",
                                'correlation': corr,
                                'type': 'unexpected_strong',
                                'severity': (abs(corr) - threshold) / (1 - threshold)
                            })
            
            # Şiddete göre sırala
            breakdown_events.sort(key=lambda x: x['severity'], reverse=True)
            
            return {
                'breakdown_events': breakdown_events,
                'total_breakdowns': len([e for e in breakdown_events if e['type'] == 'breakdown']),
                'unexpected_strong': len([e for e in breakdown_events if e['type'] == 'unexpected_strong']),
                'systemic_risk': len(breakdown_events) > len(correlation_matrix) * 0.2
            }
            
        except Exception as e:
            logger.error(f"Correlation breakdown analysis failed: {e}")
            return {}


class AdvancedCorrelationAnalyzer(CorrelationAnalyzer):
    """Gelişmiş korelasyon analiz araçları"""
    
    def __init__(self):
        super().__init__()
        self.rolling_window = 20
        self.correlation_regimes = ['low', 'medium', 'high', 'extreme']
    
    async def calculate_rolling_correlations(self, 
                                           exchange, 
                                           symbols: List[str], 
                                           window: int = None) -> Dict[str, pd.DataFrame]:
        """Rolling korelasyonları hesapla"""
        try:
            window = window or self.rolling_window
            
            # Fiyat verilerini topla
            price_data = await self._collect_price_data(exchange, symbols, '1h', window * 2)
            
            if not price_data:
                return {}
            
            # DataFrame oluştur
            df = pd.DataFrame(price_data)
            
            # Rolling korelasyonları hesapla
            rolling_correlations = {}
            
            for i, symbol1 in enumerate(symbols):
                for symbol2 in symbols[i+1:]:
                    if symbol1 in df.columns and symbol2 in df.columns:
                        rolling_corr = df[symbol1].rolling(window).corr(df[symbol2])
                        rolling_correlations[f"{symbol1}-{symbol2}"] = rolling_corr
            
            return rolling_correlations
            
        except Exception as e:
            logger.error(f"Rolling correlation calculation failed: {e}")
            return {}
    
    def detect_correlation_regime(self, 
                                correlation_matrix: Dict[str, Dict[str, float]]) -> Dict[str, Any]:
        """Korelasyon rejimini tespit et"""
        try:
            symbols = list(correlation_matrix.keys())
            
            # Ortalama korelasyonu hesapla
            total_corr = 0
            count = 0
            
            for i, symbol1 in enumerate(symbols):
                for j, symbol2 in enumerate(symbols[i+1:], i+1):
                    corr = correlation_matrix[symbol1][symbol2]
                    total_corr += abs(corr)
                    count += 1
            
            avg_correlation = total_corr / count if count > 0 else 0
            
            # Rejimi belirle
            if avg_correlation > 0.7:
                regime = 'extreme'
                risk_level = 'High'
            elif avg_correlation > 0.5:
                regime = 'high'
                risk_level = 'Medium-High'
            elif avg_correlation > 0.3:
                regime = 'medium'
                risk_level = 'Medium'
            else:
                regime = 'low'
                risk_level = 'Low'
            
            # Ek metrikler
            max_correlation = max([abs(correlation_matrix[s1][s2]) 
                                  for s1 in symbols 
                                  for s2 in symbols 
                                  if s1 != s2])
            
            correlation_dispersion = np.std([abs(correlation_matrix[s1][s2]) 
                                           for s1 in symbols 
                                           for s2 in symbols 
                                           if s1 != s2])
            
            return {
                'regime': regime,
                'risk_level': risk_level,
                'average_correlation': avg_correlation,
                'max_correlation': max_correlation,
                'correlation_dispersion': correlation_dispersion,
                'recommendation': self._get_regime_recommendation(regime)
            }
            
        except Exception as e:
            logger.error(f"Correlation regime detection failed: {e}")
            return {}
    
    def _get_regime_recommendation(self, regime: str) -> str:
        """Rejim önerileri"""
        recommendations = {
            'extreme': "Aşırı yüksek korelasyon - Pozisyon büyüklüklerini azaltın ve hedging stratejileri kullanın",
            'high': "Yüksek korelasyon - Pozisyon yoğunlaşmasından kaçının",
            'medium': "Orta korelasyon - Normal risk yönetimi protokollerini uygulayın",
            'low': "Düşük korelasyon - Diversifikasyon fırsatlarından yararlanın"
        }
        return recommendations.get(regime, "Normal portföy yönetimi")


# Global correlation analyzer instance
correlation_analyzer = AdvancedCorrelationAnalyzer()