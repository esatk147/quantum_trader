# strategies/rsi_bands.py
import pandas as pd
import numpy as np
import talib
from typing import Dict, Any, Optional, Tuple
from strategies.base_strategy import BaseStrategy
from core.logger import logger


class RSIBandsStrategy(BaseStrategy):
    """RSI Bands Trading Stratejisi"""
    
    def __init__(self):
        super().__init__("RSI Bands")
        self.parameters = {
            'rsi_length': 25,
            'rsi_overbought': 70,
            'rsi_oversold': 30,
            'trading_hours': {'start': 0, 'end': 24},
            'min_volatility': 0.001,
            'max_volatility': 0.1,
            'min_volume_ratio': 0.5
        }
    
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """RSI Bands göstergelerini hesapla"""
        try:
            df = df.copy()
            
            length = self.parameters['rsi_length']
            ob_level = self.parameters['rsi_overbought']
            os_level = self.parameters['rsi_oversold']
            
            src = df['close'].values
            ep = 2 * length - 1
            
            # RSI hesapla
            df['rsi'] = talib.RSI(src, timeperiod=length)
            
            # Kaydırılmış fiyat
            prev_src = np.roll(src, 1)
            prev_src[0] = src[0]
            
            # Pozitif ve negatif değişimler
            pos_change = np.maximum(src - prev_src, 0)
            neg_change = np.maximum(prev_src - src, 0)
            
            # EMA hesapla
            auc = talib.EMA(pos_change, timeperiod=ep)
            adc = talib.EMA(neg_change, timeperiod=ep)
            
            # RSI Bant hesaplamaları
            x1 = (length - 1) * (adc * ob_level / (100 - ob_level) - auc)
            ub = np.where(x1 >= 0, src + x1, src + x1 * (100 - ob_level) / ob_level)
            
            x2 = (length - 1) * (adc * os_level / (100 - os_level) - auc)
            lb = np.where(x2 >= 0, src + x2, src + x2 * (100 - os_level) / os_level)
            
            # Orta çizgi
            midline = (ub + lb) / 2
            
            df['upper_band'] = ub
            df['lower_band'] = lb
            df['midline'] = midline
            
            return df
            
        except Exception as e:
            logger.error(f"RSI Bands indicator calculation failed: {e}")
            return df
    
    def generate_signals(self, df: pd.DataFrame) -> Tuple[Optional[str], Dict[str, Any]]:
        """Trading sinyalleri üret"""
        try:
            if 'upper_band' not in df.columns or 'lower_band' not in df.columns:
                return None, {'error': 'Indicators not calculated'}
            
            # Son mumları al
            current_candle = df.iloc[-1]
            previous_candle = df.iloc[-2] if len(df) >= 2 else current_candle
            
            # Sinyal tespiti
            signal = None
            signal_data = {
                'timestamp': current_candle['timestamp'],
                'close': current_candle['close'],
                'rsi': current_candle['rsi'],
                'upper_band': current_candle['upper_band'],
                'lower_band': current_candle['lower_band'],
                'midline': current_candle['midline']
            }
            
            # Alım sinyali: fiyat alt bandın üzerine geçiyor
            if (previous_candle['close'] <= previous_candle['lower_band'] and 
                current_candle['close'] > current_candle['lower_band']):
                signal = 'BUY'
                signal_data.update({
                    'signal_type': 'band_cross_up',
                    'signal_strength': self._calculate_signal_strength(current_candle, 'BUY')
                })
            
            # Satım sinyali: fiyat üst bandın altına geçiyor
            elif (previous_candle['close'] >= previous_candle['upper_band'] and 
                  current_candle['close'] < current_candle['upper_band']):
                signal = 'SELL'
                signal_data.update({
                    'signal_type': 'band_cross_down',
                    'signal_strength': self._calculate_signal_strength(current_candle, 'SELL')
                })
            
            # RSI aşırı alım/satım kontrolleri
            if current_candle['rsi'] < self.parameters['rsi_oversold']:
                if signal == 'BUY':
                    signal_data['confirmation'] = 'rsi_oversold'
            elif current_candle['rsi'] > self.parameters['rsi_overbought']:
                if signal == 'SELL':
                    signal_data['confirmation'] = 'rsi_overbought'
            
            # Band genişliği analizi
            band_width = (current_candle['upper_band'] - current_candle['lower_band']) / current_candle['midline']
            signal_data['band_width'] = band_width
            signal_data['band_position'] = self._get_price_position(current_candle)
            
            return signal, signal_data
            
        except Exception as e:
            logger.error(f"RSI Bands signal generation failed: {e}")
            return None, {'error': str(e)}
    
    def _calculate_signal_strength(self, candle: pd.Series, signal: str) -> float:
        """Sinyal gücünü hesapla"""
        try:
            # Band mesafesi
            if signal == 'BUY':
                distance = (candle['close'] - candle['lower_band']) / candle['lower_band']
            else:
                distance = (candle['upper_band'] - candle['close']) / candle['upper_band']
            
            # RSI mesafesi
            if signal == 'BUY':
                rsi_distance = (self.parameters['rsi_oversold'] - candle['rsi']) / self.parameters['rsi_oversold']
            else:
                rsi_distance = (candle['rsi'] - self.parameters['rsi_overbought']) / (100 - self.parameters['rsi_overbought'])
            
            # Birleşik güç skoru (0-1)
            strength = np.clip((distance + rsi_distance) / 2, 0, 1)
            
            return float(strength)
            
        except Exception as e:
            logger.error(f"Signal strength calculation failed: {e}")
            return 0.5
    
    def _get_price_position(self, candle: pd.Series) -> str:
        """Fiyatın bandlar içindeki konumunu belirle"""
        try:
            close = candle['close']
            upper = candle['upper_band']
            lower = candle['lower_band']
            midline = candle['midline']
            
            if close > upper:
                return 'above_upper'
            elif close < lower:
                return 'below_lower'
            elif close > midline:
                return 'above_mid'
            else:
                return 'below_mid'
                
        except Exception as e:
            logger.error(f"Price position calculation failed: {e}")
            return 'unknown'
    
    def calculate_stop_loss(self, entry_price: float, direction: str) -> float:
        """RSI Bands'e özel stop loss hesapla"""
        try:
            # Dinamik stop loss (band genişliğine göre)
            base_sl = super().calculate_stop_loss(entry_price, direction)
            
            # Band genişliğine göre ayarlama
            band_width_factor = self.parameters.get('band_width_factor', 1.5)
            adjusted_sl = entry_price
            
            if direction == 'BUY':
                sl_distance = entry_price - base_sl
                adjusted_sl = entry_price - (sl_distance * band_width_factor)
            else:
                sl_distance = base_sl - entry_price
                adjusted_sl = entry_price + (sl_distance * band_width_factor)
            
            return adjusted_sl
            
        except Exception as e:
            logger.error(f"Stop loss calculation failed: {e}")
            return super().calculate_stop_loss(entry_price, direction)
    
    def get_position_sizing_recommendation(self, df: pd.DataFrame, signal: str) -> Dict[str, Any]:
        """RSI Bands'e göre pozisyon büyüklüğü önerisi"""
        try:
            current_candle = df.iloc[-1]
            signal_strength = self._calculate_signal_strength(current_candle, signal)
            market_conditions = self.analyze_market_conditions(df)
            
            # Base pozisyon büyüklüğü
            base_size = self.parameters.get('base_position_size', 100)
            
            # Sinyal gücüne göre büyüklük ayarı (0.5x - 1.5x)
            strength_factor = 0.5 + signal_strength
            
            # Volatiliteye göre büyüklük ayarı
            volatility = market_conditions.get('volatility', 0.01)
            volatility_factor = np.clip(1.0 / (volatility * 50), 0.7, 1.3)
            
            # Önerilen pozisyon büyüklüğü
            recommended_size = base_size * strength_factor * volatility_factor
            
            return {
                'recommended_size': recommended_size,
                'signal_strength': signal_strength,
                'strength_factor': strength_factor,
                'volatility_factor': volatility_factor,
                'volatility': volatility
            }
            
        except Exception as e:
            logger.error(f"Position sizing recommendation failed: {e}")
            return {'recommended_size': self.parameters.get('base_position_size', 100)}
    
    def backtest(self, df: pd.DataFrame, initial_capital: float = 10000) -> Dict[str, Any]:
        """RSI Bands stratejisini backtest et"""
        try:
            # Göstergeleri hesapla
            df_with_indicators = self.calculate_indicators(df)
            
            trades = []
            capital = initial_capital
            position = None
            
            for i in range(1, len(df_with_indicators)):
                current = df_with_indicators.iloc[i]
                previous = df_with_indicators.iloc[i-1]
                
                signal, signal_data = self.generate_signals(df_with_indicators.iloc[:i+1])
                
                if signal and position is None:
                    # Pozisyon aç
                    entry_price = current['close']
                    stop_loss = self.calculate_stop_loss(entry_price, signal)
                    take_profit = self.calculate_take_profit(entry_price, signal)
                    
                    position = {
                        'entry_time': current['timestamp'],
                        'entry_price': entry_price,
                        'direction': signal,
                        'stop_loss': stop_loss,
                        'take_profit': take_profit,
                        'signal_data': signal_data
                    }
                
                elif position:
                    # Pozisyon çıkış kontrolü
                    exit_triggered = False
                    exit_reason = None
                    exit_price = None
                    
                    if position['direction'] == 'BUY':
                        if current['low'] <= position['stop_loss']:
                            exit_price = position['stop_loss']
                            exit_reason = 'stop_loss'
                            exit_triggered = True
                        elif current['high'] >= position['take_profit']:
                            exit_price = position['take_profit']
                            exit_reason = 'take_profit'
                            exit_triggered = True
                    else:  # SELL
                        if current['high'] >= position['stop_loss']:
                            exit_price = position['stop_loss']
                            exit_reason = 'stop_loss'
                            exit_triggered = True
                        elif current['low'] <= position['take_profit']:
                            exit_price = position['take_profit']
                            exit_reason = 'take_profit'
                            exit_triggered = True
                    
                    if exit_triggered:
                        # Trade sonucu
                        pnl = (exit_price - position['entry_price']) * position['direction'] == 'BUY' - (position['entry_price'] - exit_price) * position['direction'] == 'SELL'
                        pnl_percent = (pnl / position['entry_price']) * 100
                        
                        trade_result = {
                            'entry_time': position['entry_time'],
                            'exit_time': current['timestamp'],
                            'direction': position['direction'],
                            'entry_price': position['entry_price'],
                            'exit_price': exit_price,
                            'exit_reason': exit_reason,
                            'pnl': pnl,
                            'pnl_percent': pnl_percent,
                            'duration': (current['timestamp'] - position['entry_time']).total_seconds() / 3600  # hours
                        }
                        
                        trades.append(trade_result)
                        position = None
                        capital += pnl
            
            # Performans analizi
            performance = self.get_strategy_performance(trades)
            
            return {
                'trades': trades,
                'performance': performance,
                'final_capital': capital,
                'total_return': ((capital - initial_capital) / initial_capital) * 100
            }
            
        except Exception as e:
            logger.error(f"Backtest failed: {e}")
            return {'error': str(e)}