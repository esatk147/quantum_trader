# strategies/base_strategy.py
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Tuple, List
import pandas as pd
import numpy as np
from datetime import datetime
from core.logger import logger
from core.config import config


class BaseStrategy(ABC):
    """Tüm trading stratejileri için temel sınıf"""
    
    def __init__(self, name: str):
        self.name = name
        self.parameters: Dict[str, Any] = {}
        self.timeframe: str = '1h'
        self.min_data_points: int = 100
        self.last_signal_time: Optional[datetime] = None
        self.indicators: Dict[str, np.ndarray] = {}
        
    @abstractmethod
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Teknik göstergeleri hesapla"""
        pass
    
    @abstractmethod
    def generate_signals(self, df: pd.DataFrame) -> Tuple[Optional[str], Dict[str, Any]]:
        """Trading sinyalleri üret"""
        pass
    
    def set_parameters(self, params: Dict[str, Any]):
        """Strateji parametrelerini ayarla"""
        self.parameters.update(params)
    
    def get_parameters(self) -> Dict[str, Any]:
        """Mevcut parametreleri al"""
        return self.parameters.copy()
    
    def validate_data(self, df: pd.DataFrame) -> bool:
        """Veri kalitesini kontrol et"""
        try:
            if df is None or df.empty:
                logger.warning(f"{self.name}: DataFrame is empty")
                return False
            
            if len(df) < self.min_data_points:
                logger.warning(f"{self.name}: Insufficient data points. Need {self.min_data_points}, have {len(df)}")
                return False
            
            required_columns = ['open', 'high', 'low', 'close', 'volume', 'timestamp']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                logger.error(f"{self.name}: Missing required columns: {missing_columns}")
                return False
            
            # NaN kontrolü
            if df[['open', 'high', 'low', 'close', 'volume']].isnull().any().any():
                logger.warning(f"{self.name}: DataFrame contains NaN values")
                # NaN'ları temizle
                df.fillna(method='ffill', inplace=True)
                df.dropna(inplace=True)
            
            return True
            
        except Exception as e:
            logger.error(f"{self.name}: Data validation failed: {e}")
            return False
    
    def check_signal_cooldown(self, cooldown_minutes: int = 15) -> bool:
        """Son sinyal ile şimdiki zaman arasındaki süreyi kontrol et"""
        if self.last_signal_time is None:
            return True
        
        time_passed = datetime.utcnow() - self.last_signal_time
        return time_passed.total_seconds() / 60 >= cooldown_minutes
    
    def analyze_market_conditions(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Piyasa koşullarını analiz et"""
        try:
            # Volatilite analizi
            returns = df['close'].pct_change()
            volatility = returns.std() * np.sqrt(periods_per_year)
            
            # Trend analizi
            price_change_percent = (df['close'].iloc[-1] - df['close'].iloc[0]) / df['close'].iloc[0] * 100
            
            # Hacim analizi
            avg_volume = df['volume'].mean()
            current_volume = df['volume'].iloc[-1]
            volume_ratio = current_volume / avg_volume
            
            # Momentum analizi
            momentum = (df['close'].ewm(span=10).mean() - df['close'].ewm(span=30).mean()).iloc[-1]
            
            return {
                'volatility': volatility,
                'trend_direction': 'bullish' if price_change_percent > 5 else 'bearish' if price_change_percent < -5 else 'neutral',
                'trend_strength': abs(price_change_percent),
                'volume_ratio': volume_ratio,
                'momentum': momentum
            }
            
        except Exception as e:
            logger.error(f"{self.name}: Market condition analysis failed: {e}")
            return {}
    
    def calculate_position_size(self, account_balance: float, volatility: float = None) -> float:
        """Pozisyon büyüklüğünü hesapla"""
        try:
            base_size = self.parameters.get('position_size', config.get('position_size', 100))
            
            # Volatiliteye göre ayarlama
            if volatility is not None:
                # Volatilite faktörü (0.5 - 1.5 arası)
                volatility_factor = np.clip(1.0 / (volatility * 20), 0.5, 1.5)
                adjusted_size = base_size * volatility_factor
            else:
                adjusted_size = base_size
            
            # Hesap büyüklüğüne göre ölçeklendir
            risk_percent = self.parameters.get('risk_percent', config.get('risk_percent', 1.0))
            max_size = account_balance * (risk_percent / 100)
            
            return min(adjusted_size, max_size)
            
        except Exception as e:
            logger.error(f"{self.name}: Position size calculation failed: {e}")
            return config.get('position_size', 100)
    
    def calculate_stop_loss(self, entry_price: float, direction: str) -> float:
        """Stop loss fiyatını hesapla"""
        try:
            sl_percent = self.parameters.get('stop_loss_percent', config.get('stop_loss_percent', 2.0))
            
            if direction == 'BUY':
                sl_price = entry_price * (1 - sl_percent / 100)
            else:  # SELL
                sl_price = entry_price * (1 + sl_percent / 100)
            
            return sl_price
            
        except Exception as e:
            logger.error(f"{self.name}: Stop loss calculation failed: {e}")
            if direction == 'BUY':
                return entry_price * 0.98  # Default 2% SL for buy
            else:
                return entry_price * 1.02  # Default 2% SL for sell
    
    def calculate_take_profit(self, entry_price: float, direction: str) -> float:
        """Take profit fiyatını hesapla"""
        try:
            tp_percent = self.parameters.get('take_profit_percent', config.get('take_profit_percent', 3.0))
            
            if direction == 'BUY':
                tp_price = entry_price * (1 + tp_percent / 100)
            else:  # SELL
                tp_price = entry_price * (1 - tp_percent / 100)
            
            return tp_price
            
        except Exception as e:
            logger.error(f"{self.name}: Take profit calculation failed: {e}")
            if direction == 'BUY':
                return entry_price * 1.03  # Default 3% TP for buy
            else:
                return entry_price * 0.97  # Default 3% TP for sell
    
    def apply_filters(self, signal: str, df: pd.DataFrame) -> bool:
        """Trading sinyaline filtreler uygula"""
        try:
            # Zaman filtresi
            if not self.check_signal_cooldown():
                logger.debug(f"{self.name}: Signal rejected - cooldown active")
                return False
            
            # Piyasa saatleri filtresi
            current_hour = datetime.utcnow().hour
            trading_hours = self.parameters.get('trading_hours', {'start': 0, 'end': 24})
            if not (trading_hours['start'] <= current_hour < trading_hours['end']):
                logger.debug(f"{self.name}: Signal rejected - outside trading hours")
                return False
            
            # Volatilite filtresi
            volatility = df['close'].pct_change().std()
            min_volatility = self.parameters.get('min_volatility', 0.001)
            max_volatility = self.parameters.get('max_volatility', 0.05)
            
            if not (min_volatility <= volatility <= max_volatility):
                logger.debug(f"{self.name}: Signal rejected - volatility out of range")
                return False
            
            # Hacim filtresi
            current_volume = df['volume'].iloc[-1]
            avg_volume = df['volume'].mean()
            min_volume_ratio = self.parameters.get('min_volume_ratio', 0.5)
            
            if current_volume / avg_volume < min_volume_ratio:
                logger.debug(f"{self.name}: Signal rejected - low volume")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"{self.name}: Filter application failed: {e}")
            return False
    
    def run(self, df: pd.DataFrame) -> Tuple[Optional[str], Dict[str, Any]]:
        """Stratejiyi çalıştır"""
        try:
            # Veri doğrulama
            if not self.validate_data(df):
                return None, {'error': 'Invalid data'}
            
            # Göstergeleri hesapla
            df_with_indicators = self.calculate_indicators(df)
            
            # Sinyalleri üret
            signal, signal_data = self.generate_signals(df_with_indicators)
            
            # Sinyal varsa filtreleri uygula
            if signal and self.apply_filters(signal, df):
                self.last_signal_time = datetime.utcnow()
                
                # Piyasa analizi ekle
                market_conditions = self.analyze_market_conditions(df)
                signal_data['market_conditions'] = market_conditions
                
                return signal, signal_data
            
            return None, signal_data
            
        except Exception as e:
            logger.error(f"{self.name}: Strategy execution failed: {e}")
            return None, {'error': str(e)}
    
    def get_strategy_performance(self, trades: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Strateji performansını değerlendir"""
        try:
            if not trades:
                return {'total_trades': 0}
            
            successful_trades = [t for t in trades if t.get('pnl', 0) > 0]
            total_pnl = sum(t.get('pnl', 0) for t in trades)
            total_trades = len(trades)
            win_rate = len(successful_trades) / total_trades if total_trades > 0 else 0
            
            # Drawdown hesaplama
            cumulative_pnl = np.cumsum([t.get('pnl', 0) for t in trades])
            running_max = np.maximum.accumulate(cumulative_pnl)
            drawdowns = cumulative_pnl - running_max
            max_drawdown = np.min(drawdowns) if len(drawdowns) > 0 else 0
            
            # Sharpe ratio
            returns = [t.get('pnl_percent', 0) for t in trades]
            sharpe_ratio = (np.mean(returns) / np.std(returns)) if np.std(returns) != 0 else 0
            
            return {
                'total_trades': total_trades,
                'successful_trades': len(successful_trades),
                'win_rate': win_rate,
                'total_pnl': total_pnl,
                'average_pnl': total_pnl / total_trades if total_trades > 0 else 0,
                'max_drawdown': max_drawdown,
                'sharpe_ratio': sharpe_ratio,
                'profit_factor': sum(t.get('pnl', 0) for t in successful_trades) / 
                                abs(sum(t.get('pnl', 0) for t in trades if t.get('pnl', 0) < 0)) 
                                if any(t.get('pnl', 0) < 0 for t in trades) else float('inf')
            }
            
        except Exception as e:
            logger.error(f"{self.name}: Performance calculation failed: {e}")
            return {}
    
    def __str__(self):
        return f"Strategy: {self.name}, Timeframe: {self.timeframe}, Parameters: {len(self.parameters)}"
    
    def __repr__(self):
        return f"<{self.__class__.__name__}: {self.name}>"


# Helper fonksiyonları
def calculate_sma(data: pd.Series, period: int) -> pd.Series:
    """Simple Moving Average hesapla"""
    return data.rolling(window=period).mean()


def calculate_ema(data: pd.Series, period: int) -> pd.Series:
    """Exponential Moving Average hesapla"""
    return data.ewm(span=period, adjust=False).mean()


def calculate_rsi(data: pd.Series, period: int = 14) -> pd.Series:
    """Relative Strength Index hesapla"""
    delta = data.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    
    rs = gain / loss
    return 100 - (100 / (1 + rs))


def calculate_macd(data: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[pd.Series, pd.Series, pd.Series]:
    """MACD hesapla"""
    exp1 = data.ewm(span=fast, adjust=False).mean()
    exp2 = data.ewm(span=slow, adjust=False).mean()
    macd = exp1 - exp2
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    histogram = macd - signal_line
    
    return macd, signal_line, histogram


def calculate_bollinger_bands(data: pd.Series, period: int = 20, std_dev: float = 2.0) -> Tuple[pd.Series, pd.Series, pd.Series]:
    """Bollinger Bands hesapla"""
    middle_band = data.rolling(window=period).mean()
    std = data.rolling(window=period).std()
    upper_band = middle_band + (std * std_dev)
    lower_band = middle_band - (std * std_dev)
    
    return upper_band, middle_band, lower_band


def calculate_atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    """Average True Range hesapla"""
    tr1 = pd.DataFrame(high - low)
    tr2 = pd.DataFrame(abs(high - close.shift()))
    tr3 = pd.DataFrame(abs(low - close.shift()))
    
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr = tr.rolling(window=period).mean()
    
    return atr


# Periyot sabitleri
periods_per_year = {
    '1m': 525600,
    '5m': 105120,
    '15m': 35040,
    '30m': 17520,
    '1h': 8760,
    '4h': 2190,
    '1d': 365,
    '1w': 52
}