# strategies/perfect_entry.py
import pandas as pd
import numpy as np
import talib
from typing import Dict, Any, Optional, Tuple
from strategies.base_strategy import BaseStrategy
from core.logger import logger

class PerfectEntryV9Strategy(BaseStrategy):
    """Perfect Entry V9 Trading Stratejisi"""
    
    def __init__(self):
        super().__init__("Perfect Entry V9")
        self.parameters = {
            'signal_period': 5,
            'long_period': 27,
            'buying_pressure_threshold': 0.2,
            'selling_pressure_threshold': -0.2,
            'trend_strength_threshold': 0,
            'trend_smoothing': 14,
            'atr_multiplier': 2,
            'atr_length': 14,
            'di_length': 14,
            'trading_hours': {'start': 0, 'end': 24},
            'min_volatility': 0.001,
            'max_volatility': 0.1,
            'min_volume_ratio': 0.5
        }
    
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Perfect Entry göstergelerini hesapla"""
        try:
            df = df.copy()
            
            signal = self.parameters['signal_period']
            long_period = self.parameters['long_period']
            bpthreshold = self.parameters['buying_pressure_threshold']
            spthreshold = self.parameters['selling_pressure_threshold']
            trendstrgth = self.parameters['trend_strength_threshold']
            trndlen = self.parameters['trend_smoothing']
            atrmultip = self.parameters['atr_multiplier']
            atrlength = self.parameters['atr_length']
            dilen = self.parameters['di_length']
            
            # ATR hesapla
            df['atr'] = talib.ATR(df['high'].values, df['low'].values, df['close'].values, timeperiod=atrlength)
            df['long_atrstop'] = df['close'] - df['atr'] * atrmultip
            df['short_atrstop'] = df['close'] + df['atr'] * atrmultip
            
            # Buying Pressure ve Selling Pressure hesaplamaları
            df['BP'] = 0.0
            df['SP'] = 0.0
            
            for i in range(1, len(df)):
                close = df['close'].iloc[i]
                open_price = df['open'].iloc[i]
                high = df['high'].iloc[i]
                low = df['low'].iloc[i]
                prev_close = df['close'].iloc[i-1]
                prev_open = df['open'].iloc[i-1]
                
                # Buying Pressure hesaplama
                if close < open_price:
                    if prev_close < open_price:
                        df.at[df.index[i], 'BP'] = max(high-prev_close, close-low)
                    else:
                        df.at[df.index[i], 'BP'] = max(high-open_price, close-low)
                elif close > open_price:
                    if prev_close > open_price:
                        df.at[df.index[i], 'BP'] = high-low
                    else:
                        df.at[df.index[i], 'BP'] = max(open_price-prev_close, high-low)
                else:  # close == open_price
                    if high-close > close-low:
                        if prev_close < open_price:
                            df.at[df.index[i], 'BP'] = max(high-prev_close, close-low)
                        else:
                            df.at[df.index[i], 'BP'] = high-open_price
                    elif high-close < close-low:
                        if prev_close > open_price:
                            df.at[df.index[i], 'BP'] = high-low
                        else:
                            df.at[df.index[i], 'BP'] = max(open_price-prev_close, high-low)
                    else:
                        if prev_close > open_price:
                            df.at[df.index[i], 'BP'] = max(high-open_price, close-low)
                        else:
                            df.at[df.index[i], 'BP'] = max(open_price-prev_close, high-low)
                
                # Selling Pressure hesaplama
                if close < open_price:
                    if prev_close > open_price:
                        df.at[df.index[i], 'SP'] = max(prev_close-open_price, high-low)
                    else:
                        df.at[df.index[i], 'SP'] = high-low
                elif close > open_price:
                    if prev_close > open_price:
                        df.at[df.index[i], 'SP'] = max(prev_close-low, high-close)
                    else:
                        df.at[df.index[i], 'SP'] = max(open_price-low, high-close)
                else:  # close == open_price
                    if high-close > close-low:
                        if prev_close > open_price:
                            df.at[df.index[i], 'SP'] = max(prev_close-open_price, high-low)
                        else:
                            df.at[df.index[i], 'SP'] = high-low
                    elif high-close < close-low:
                        if prev_close > open_price:
                            df.at[df.index[i], 'SP'] = max(prev_close-low, high-close)
                        else:
                            df.at[df.index[i], 'SP'] = open_price-low
                    else:
                        if prev_close > open_price:
                            df.at[df.index[i], 'SP'] = max(prev_close-open_price, high-low)
                        else:
                            df.at[df.index[i], 'SP'] = max(open_price-low, high-close)
            
            # Diğer hesaplamalar
            df['TP'] = df['BP'] + df['SP']
            df['BPV'] = (df['BP'] / df['TP']) * df['volume']
            df['SPV'] = (df['SP'] / df['TP']) * df['volume']
            df['TPV'] = df['BPV'] + df['SPV']
            
            # EMA ve WMA hesaplama için talib
            df['BPVavg'] = talib.EMA(talib.EMA(df['BPV'].values, timeperiod=signal), timeperiod=signal)
            df['SPVavg'] = talib.EMA(talib.EMA(df['SPV'].values, timeperiod=signal), timeperiod=signal)
            # WMA'yı çoğaltılmış EMA ile yaklaştır
            df['TPVavg'] = talib.EMA(talib.EMA(df['TPV'].values, timeperiod=signal), timeperiod=signal)
            
            # Convdiv hesaplama
            df['convdivc'] = ((df['BPVavg'] - df['SPVavg']) / df['TPVavg']) * 100
            
            # Trend hesaplama - DI+ ve DI- kullan
            plus_di = talib.PLUS_DI(df['high'].values, df['low'].values, df['close'].values, timeperiod=dilen)
            minus_di = talib.MINUS_DI(df['high'].values, df['low'].values, df['close'].values, timeperiod=dilen)
            
            # Trend gücü hesaplama
            sum_di = plus_di + minus_di
            abs_diff = np.abs(plus_di - minus_di)
            trend_strength = 100 * talib.EMA(abs_diff / np.where(sum_di == 0, 1, sum_di), timeperiod=trndlen)
            df['trend_strength'] = trend_strength
            
            # Buy ve Sell sinyalleri
            df['Buy'] = (df['convdivc'] > bpthreshold) & (df['trend_strength'] > trendstrgth)
            df['Sell'] = (df['convdivc'] < spthreshold) & (df['trend_strength'] > trendstrgth)
            
            # Pine Script'teki mantığı simüle et
            df['long_condition'] = False
            df['short_condition'] = True
            
            for i in range(1, len(df)):
                df.at[df.index[i], 'long_condition'] = df['long_condition'].iloc[i-1]
                df.at[df.index[i], 'short_condition'] = df['short_condition'].iloc[i-1]
                
                if (not df['long_condition'].iloc[i]) and df['Buy'].iloc[i]:
                    df.at[df.index[i], 'long_condition'] = True
                    df.at[df.index[i], 'short_condition'] = False
                
                if (not df['short_condition'].iloc[i]) and df['Sell'].iloc[i]:
                    df.at[df.index[i], 'long_condition'] = False
                    df.at[df.index[i], 'short_condition'] = True
            
            return df
            
        except Exception as e:
            logger.error(f"Perfect Entry indicator calculation failed: {e}")
            return df
    
    def generate_signals(self, df: pd.DataFrame) -> Tuple[Optional[str], Dict[str, Any]]:
        """Trading sinyalleri üret"""
        try:
            if 'Buy' not in df.columns or 'Sell' not in df.columns:
                return None, {'error': 'Indicators not calculated'}
            
            # Son mumları al
            current_candle = df.iloc[-1]
            
            # Sinyal tespiti
            signal = None
            signal_data = {
                'timestamp': current_candle['timestamp'],
                'close': current_candle['close'],
                'convdivc': current_candle['convdivc'],
                'trend_strength': current_candle['trend_strength'],
                'atr': current_candle['atr'],
                'bp': current_candle['BP'],
                'sp': current_candle['SP']
            }
            
            # Alım sinyali
            if current_candle['Buy']:
                signal = 'BUY'
                signal_data.update({
                    'signal_type': 'perfect_entry_buy',
                    'signal_strength': self._calculate_signal_strength(current_candle, 'BUY'),
                    'long_condition': current_candle['long_condition'],
                    'short_condition': current_candle['short_condition']
                })
            
            # Satım sinyali
            elif current_candle['Sell']:
                signal = 'SELL'
                signal_data.update({
                    'signal_type': 'perfect_entry_sell',
                    'signal_strength': self._calculate_signal_strength(current_candle, 'SELL'),
                    'long_condition': current_candle['long_condition'],
                    'short_condition': current_candle['short_condition']
                })
            
            # Ek analizler
            signal_data['pressure_balance'] = self._analyze_pressure_balance(current_candle)
            signal_data['trend_quality'] = self._evaluate_trend_quality(current_candle)
            
            return signal, signal_data
            
        except Exception as e:
            logger.error(f"Perfect Entry signal generation failed: {e}")
            return None, {'error': str(e)}
    
    def _calculate_signal_strength(self, candle: pd.Series, signal: str) -> float:
        """Sinyal gücünü hesapla"""
        try:
            # Convdiv mesafesi
            threshold = self.parameters['buying_pressure_threshold'] if signal == 'BUY' else self.parameters['selling_pressure_threshold']
            conv_distance = abs(candle['convdivc'] - threshold) / 100
            
            # Trend gücü
            trend_strength = candle['trend_strength'] / 100
            
            # Pressure denisi
            pressure_balance = candle['BP'] / (candle['BP'] + candle['SP'])
            if signal == 'SELL':
                pressure_balance = 1 - pressure_balance
            
            # Birleşik güç skoru (0-1)
            strength = (conv_distance + trend_strength + pressure_balance) / 3
            
            return float(np.clip(strength, 0, 1))
            
        except Exception as e:
            logger.error(f"Signal strength calculation failed: {e}")
            return 0.5
    
    def _analyze_pressure_balance(self, candle: pd.Series) -> Dict[str, Any]:
        """Alım/satım baskısı dengesini analiz et"""
        try:
            total_pressure = candle['BP'] + candle['SP']
            
            if total_pressure > 0:
                bp_ratio = candle['BP'] / total_pressure
                sp_ratio = candle['SP'] / total_pressure
            else:
                bp_ratio = sp_ratio = 0.5
            
            # Pressure dominansını belirle
            if bp_ratio > 0.6:
                dominant_pressure = 'buying'
            elif sp_ratio > 0.6:
                dominant_pressure = 'selling'
            else:
                dominant_pressure = 'balanced'
            
            return {
                'buying_pressure_ratio': bp_ratio,
                'selling_pressure_ratio': sp_ratio,
                'dominant_pressure': dominant_pressure,
                'pressure_intensity': total_pressure / candle['volume'] if candle['volume'] > 0 else 0
            }
            
        except Exception as e:
            logger.error(f"Pressure balance analysis failed: {e}")
            return {}
    
    def _evaluate_trend_quality(self, candle: pd.Series) -> Dict[str, Any]:
        """Trend kalitesini değerlendir"""
        try:
            trend_strength = candle['trend_strength']
            
            # Trend seviyesini belirle
            if trend_strength > 80:
                quality = 'very_strong'
                confidence = 0.9
            elif trend_strength > 60:
                quality = 'strong'
                confidence = 0.7
            elif trend_strength > 40:
                quality = 'moderate'
                confidence = 0.5
            elif trend_strength > 20:
                quality = 'weak'
                confidence = 0.3
            else:
                quality = 'very_weak'
                confidence = 0.1
            
            return {
                'trend_strength': trend_strength,
                'quality': quality,
                'confidence': confidence,
                'direction': 'bullish' if candle['BPVavg'] > candle['SPVavg'] else 'bearish'
            }
            
        except Exception as e:
            logger.error(f"Trend quality evaluation failed: {e}")
            return {
                'trend_strength': 0,
                'quality': 'unknown',
                'confidence': 0,
                'direction': 'neutral'
            }