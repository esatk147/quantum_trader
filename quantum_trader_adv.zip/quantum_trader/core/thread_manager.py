# core/thread_manager.py
import asyncio
import threading
import concurrent.futures
from typing import Dict, Any, Callable, Optional, List
from dataclasses import dataclass
from queue import Queue
import time
from .logger import logger


@dataclass
class ThreadTask:
    """Thread task wrapper"""
    name: str
    target: Callable
    args: tuple = ()
    kwargs: dict = None
    daemon: bool = True
    
    def __post_init__(self):
        self.kwargs = self.kwargs or {}


class ThreadSafeCounter:
    """Thread-safe sayaç"""
    def __init__(self, initial_value: int = 0):
        self._value = initial_value
        self._lock = threading.Lock()
    
    def increment(self):
        with self._lock:
            self._value += 1
            return self._value
    
    def decrement(self):
        with self._lock:
            self._value -= 1
            return self._value
    
    @property
    def value(self):
        with self._lock:
            return self._value


class ThreadSafeQueue:
    """Thread-safe kuyruk"""
    def __init__(self, maxsize: int = 0):
        self._queue = Queue(maxsize=maxsize)
        self._lock = threading.Lock()
    
    def put(self, item: Any, block: bool = True, timeout: float = None):
        with self._lock:
            self._queue.put(item, block=block, timeout=timeout)
    
    def get(self, block: bool = True, timeout: float = None) -> Any:
        with self._lock:
            return self._queue.get(block=block, timeout=timeout)
    
    def empty(self) -> bool:
        return self._queue.empty()
    
    def qsize(self) -> int:
        return self._queue.qsize()


class ThreadManager:
    """Thread yönetim sistemi"""
    
    def __init__(self, max_workers: int = 10):
        self.max_workers = max_workers
        self.threads: Dict[str, threading.Thread] = {}
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
        self.shutdown_lock = threading.Lock()
        self.is_shutting_down = False
        self._active_tasks = ThreadSafeCounter()
        
    def create_thread(self, task: ThreadTask) -> bool:
        """Yeni thread oluştur"""
        try:
            if task.name in self.threads:
                logger.warning(f"Thread already exists: {task.name}")
                return False
            
            thread = threading.Thread(
                target=self._wrapped_target,
                name=task.name,
                args=(task.target, task.args, task.kwargs),
                daemon=task.daemon
            )
            
            self.threads[task.name] = thread
            thread.start()
            
            logger.info(f"Thread started: {task.name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create thread {task.name}: {e}")
            return False
    
    def _wrapped_target(self, target: Callable, args: tuple, kwargs: dict):
        """Thread hedef fonksiyonunu wrap'le"""
        thread_name = threading.current_thread().name
        self._active_tasks.increment()
        
        try:
            target(*args, **kwargs)
        except Exception as e:
            logger.error(f"Error in thread {thread_name}: {e}")
        finally:
            self._active_tasks.decrement()
            with self.shutdown_lock:
                if not self.is_shutting_down:
                    del self.threads[thread_name]
    
    def stop_thread(self, thread_name: str, timeout: float = 5.0):
        """Thread'i durdur"""
        if thread_name not in self.threads:
            return
        
        thread = self.threads[thread_name]
        
        # Thread'e durma sinyali gönder (implementation'a bağlı)
        # Bu örnek için thread'in kendisinin stop kontrol etmesi gerekiyor
        
        thread.join(timeout=timeout)
        
        if thread.is_alive():
            logger.warning(f"Thread {thread_name} did not stop gracefully")
        else:
            logger.info(f"Thread {thread_name} stopped")
            del self.threads[thread_name]
    
    def submit_task(self, func: Callable, *args, **kwargs) -> concurrent.futures.Future:
        """Thread pool'a task gönder"""
        return self.executor.submit(func, *args, **kwargs)
    
    def wait_for_all(self, timeout: float = None):
        """Tüm thread'lerin bitmesini bekle"""
        for name, thread in list(self.threads.items()):
            thread.join(timeout=timeout)
            if thread.is_alive():
                logger.warning(f"Thread {name} still running after timeout")
    
    def shutdown(self, wait: bool = True):
        """Tüm thread'leri kapat"""
        with self.shutdown_lock:
            self.is_shutting_down = True
        
        # Mevcut thread'leri durdur
        for name in list(self.threads.keys()):
            self.stop_thread(name)
        
        # Thread pool'u kapat
        self.executor.shutdown(wait=wait)
        
        logger.info("Thread manager shutdown complete")
    
    @property
    def active_threads(self) -> List[str]:
        """Aktif thread'lerin listesi"""
        return list(self.threads.keys())
    
    @property
    def thread_count(self) -> int:
        """Aktif thread sayısı"""
        return len(self.threads)


class AsyncManager:
    """Asenkron işlem yönetimi"""
    
    def __init__(self):
        self.tasks: Dict[str, asyncio.Task] = {}
        self.loops: Dict[str, asyncio.AbstractEventLoop] = {}
        self.running = True
    
    def run_in_loop(self, name: str, coro: Callable):
        """Yeni event loop'ta coroutine çalıştır"""
        if name in self.loops:
            logger.warning(f"Loop already running: {name}")
            return
        
        def _run():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            self.loops[name] = loop
            
            try:
                loop.run_until_complete(coro())
            except Exception as e:
                logger.error(f"Error in async loop {name}: {e}")
            finally:
                loop.close()
                if name in self.loops:
                    del self.loops[name]
        
        thread = threading.Thread(target=_run, name=f"AsyncLoop-{name}", daemon=True)
        thread.start()
    
    def create_task(self, name: str, coro, loop: asyncio.AbstractEventLoop = None):
        """Task oluştur"""
        loop = loop or asyncio.get_event_loop()
        
        if name in self.tasks:
            logger.warning(f"Task already exists: {name}")
            return
        
        task = loop.create_task(coro)
        self.tasks[name] = task
        
        # Task tamamlandığında temizle
        def _cleanup(future):
            if name in self.tasks:
                del self.tasks[name]
        
        task.add_done_callback(_cleanup)
        
        return task
    
    def cancel_task(self, name: str):
        """Task'ı iptal et"""
        if name in self.tasks:
            task = self.tasks[name]
            task.cancel()
            logger.info(f"Task cancelled: {name}")
    
    def cancel_all(self):
        """Tüm task'ları iptal et"""
        for name in list(self.tasks.keys()):
            self.cancel_task(name)
    
    def shutdown(self):
        """Async manager'ı kapat"""
        self.running = False
        self.cancel_all()
        
        # Tüm loop'ları kapat
        for name, loop in list(self.loops.items()):
            if loop.is_running():
                loop.call_soon_threadsafe(loop.stop)


class HybridManager:
    """Thread ve Async işlemleri birleştiren yönetici"""
    
    def __init__(self, max_workers: int = 10):
        self.thread_manager = ThreadManager(max_workers)
        self.async_manager = AsyncManager()
        self.main_loop = None
        self._shutdown = False
    
    def start(self):
        """Hybrid manager'ı başlat"""
        # Ana event loop'u başlat
        self.main_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.main_loop)
        
        # Event loop'u ayrı thread'de çalıştır
        loop_thread = threading.Thread(
            target=self._run_main_loop,
            name="MainEventLoop",
            daemon=True
        )
        loop_thread.start()
        
        # Event loop'un başlamasını bekle
        time.sleep(0.1)
        
        logger.info("Hybrid manager started")
    
    def _run_main_loop(self):
        """Ana event loop'u çalıştır"""
        try:
            self.main_loop.run_forever()
        except Exception as e:
            logger.error(f"Main event loop error: {e}")
        finally:
            self.main_loop.close()
    
    def schedule_async(self, name: str, coro):
        """Async task zamanla"""
        if self.main_loop and not self._shutdown:
            future = asyncio.run_coroutine_threadsafe(coro, self.main_loop)
            return future
        
        logger.warning("Cannot schedule async task: manager is shutdown")
        return None
    
    def create_thread(self, task: ThreadTask) -> bool:
        """Thread oluştur"""
        return self.thread_manager.create_thread(task)
    
    def submit_task(self, func: Callable, *args, **kwargs):
        """Thread pool'a task gönder"""
        return self.thread_manager.submit_task(func, *args, **kwargs)
    
    def shutdown(self, wait: bool = True):
        """Hybrid manager'ı kapat"""
        self._shutdown = True
        
        # Thread manager'ı kapat
        self.thread_manager.shutdown(wait=wait)
        
        # Async manager'ı kapat
        self.async_manager.shutdown()
        
        # Ana event loop'u durdur
        if self.main_loop and self.main_loop.is_running():
            self.main_loop.call_soon_threadsafe(self.main_loop.stop)
        
        logger.info("Hybrid manager shutdown complete")


# Global instance'lar
thread_manager = ThreadManager()
async_manager = AsyncManager()
hybrid_manager = HybridManager()