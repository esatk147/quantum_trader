# core/database.py
import sqlalchemy as sa
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session
from contextlib import contextmanager
from datetime import datetime
from typing import Dict, Any, Optional, List
import json
from .logger import logger
from .config import config


Base = declarative_base()


class TradeSignal(Base):
    """Trade sinyalleri tablosu"""
    __tablename__ = 'trade_signals'
    
    id = sa.Column(sa.Integer, primary_key=True)
    trade_no = sa.Column(sa.Integer)
    timestamp = sa.Column(sa.DateTime, default=datetime.utcnow)
    coin = sa.Column(sa.String(20))
    direction = sa.Column(sa.String(10))
    entry_price = sa.Column(sa.Float)
    exit_tp = sa.Column(sa.Float)
    exit_sl = sa.Column(sa.Float)
    position_size = sa.Column(sa.Float)
    actual_exit_price = sa.Column(sa.Float, nullable=True)
    actual_pnl = sa.Column(sa.Float, nullable=True)
    pnl_percent = sa.Column(sa.Float, nullable=True)
    rsi_4h = sa.Column(sa.Float)
    rsi_15m = sa.Column(sa.Float)
    ema100 = sa.Column(sa.Float)
    macd = sa.Column(sa.Float)
    atr = sa.Column(sa.Float)
    supertrend = sa.Column(sa.Float)
    vwap = sa.Column(sa.Float)
    trend_direction = sa.Column(sa.String(10))
    volume = sa.Column(sa.Float)
    btc_price = sa.Column(sa.Float)
    eth_price = sa.Column(sa.Float)
    btc_dominance = sa.Column(sa.Float)
    funding_rate = sa.Column(sa.Float)
    parameters = sa.Column(sa.Text)  # JSON
    performance = sa.Column(sa.Float, nullable=True)
    execution_status = sa.Column(sa.String(20))
    trade_duration = sa.Column(sa.Integer, nullable=True)
    market_condition = sa.Column(sa.String(50))


class OptimalParameters(Base):
    """Optimum parametre tablosu"""
    __tablename__ = 'optimal_parameters'
    
    id = sa.Column(sa.Integer, primary_key=True)
    coin = sa.Column(sa.String(20))
    timeframe = sa.Column(sa.String(10))
    market_condition = sa.Column(sa.String(50))
    position_size_multiplier = sa.Column(sa.Float)
    tp_distance = sa.Column(sa.Float)
    sl_distance = sa.Column(sa.Float)
    emergency_exit_threshold = sa.Column(sa.Float)
    strategy_params = sa.Column(sa.Text)  # JSON
    win_rate = sa.Column(sa.Float)
    avg_profit = sa.Column(sa.Float)
    sharpe_ratio = sa.Column(sa.Float)
    max_drawdown = sa.Column(sa.Float)
    last_updated = sa.Column(sa.DateTime, default=datetime.utcnow)


class MarketConditions(Base):
    """Piyasa durumu tablosu"""
    __tablename__ = 'market_conditions'
    
    id = sa.Column(sa.Integer, primary_key=True)
    timestamp = sa.Column(sa.DateTime, default=datetime.utcnow)
    volatility = sa.Column(sa.Float)
    trend_strength = sa.Column(sa.Float)
    market_regime = sa.Column(sa.String(50))
    volume_profile = sa.Column(sa.String(50))


class DatabaseManager:
    """Veritabanı yönetici sınıfı"""
    
    def __init__(self, db_url: Optional[str] = None):
        self.db_url = db_url or f"sqlite:///{config.get('database_path', 'data/crypto_data.db')}"
        self.engine = None
        self.Session = None
        self._session = None
        
    def connect(self):
        """Veritabanına bağlan"""
        try:
            self.engine = sa.create_engine(
                self.db_url,
                echo=False,
                pool_size=5,
                max_overflow=10,
                pool_timeout=30,
                pool_recycle=1800,
                pool_pre_ping=True
            )
            
            self.Session = scoped_session(sessionmaker(bind=self.engine))
            Base.metadata.create_all(self.engine)
            
            logger.info(f"Connected to database: {self.db_url}")
            return True
            
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            return False
    
    @contextmanager
    def get_session(self):
        """Session context manager"""
        session = self.Session()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
    
    def save_signal(self, signal_data: Dict[str, Any]):
        """Sinyal verisini kaydet"""
        try:
            with self.get_session() as session:
                signal = TradeSignal(**signal_data)
                session.add(signal)
                logger.debug(f"Saved signal for {signal_data.get('coin')}")
                
        except Exception as e:
            logger.error(f"Failed to save signal: {e}")
    
    def save_trade_result(self, trade_id: int, result: Dict[str, Any]):
        """Trade sonucunu güncelle"""
        try:
            with self.get_session() as session:
                signal = session.query(TradeSignal).filter_by(id=trade_id).first()
                if signal:
                    for key, value in result.items():
                        setattr(signal, key, value)
                    logger.debug(f"Updated trade result for ID: {trade_id}")
                else:
                    logger.warning(f"Trade not found: {trade_id}")
                    
        except Exception as e:
            logger.error(f"Failed to update trade result: {e}")
    
    def save_optimal_parameters(self, coin: str, timeframe: str, condition: str, params: Dict[str, Any]):
        """Optimum parametreleri kaydet"""
        try:
            with self.get_session() as session:
                existing = session.query(OptimalParameters).filter_by(
                    coin=coin,
                    timeframe=timeframe,
                    market_condition=condition
                ).first()
                
                if existing:
                    for key, value in params.items():
                        if key != 'strategy_params':
                            setattr(existing, key, value)
                        else:
                            existing.strategy_params = json.dumps(value)
                    existing.last_updated = datetime.utcnow()
                else:
                    params['strategy_params'] = json.dumps(params.get('strategy_params', {}))
                    optimal = OptimalParameters(
                        coin=coin,
                        timeframe=timeframe,
                        market_condition=condition,
                        **params
                    )
                    session.add(optimal)
                    
                logger.debug(f"Saved optimal parameters for {coin}")
                
        except Exception as e:
            logger.error(f"Failed to save optimal parameters: {e}")
    
    def get_optimal_parameters(self, coin: str, timeframe: str, condition: str) -> Optional[Dict[str, Any]]:
        """Optimum parametreleri getir"""
        try:
            with self.get_session() as session:
                params = session.query(OptimalParameters).filter_by(
                    coin=coin,
                    timeframe=timeframe,
                    market_condition=condition
                ).order_by(
                    OptimalParameters.win_rate.desc(),
                    OptimalParameters.avg_profit.desc()
                ).first()
                
                if params:
                    result = params.__dict__.copy()
                    result.pop('_sa_instance_state', None)
                    result['strategy_params'] = json.loads(result.get('strategy_params', '{}'))
                    return result
                    
        except Exception as e:
            logger.error(f"Failed to get optimal parameters: {e}")
        
        return None
    
    def analyze_trade_performance(self, coin: str, timeframe: str = None) -> Optional[Dict[str, Any]]:
        """Trade performansını analiz et"""
        try:
            with self.get_session() as session:
                query = session.query(TradeSignal).filter(
                    TradeSignal.coin == coin,
                    TradeSignal.execution_status == 'closed',
                    TradeSignal.pnl_percent.isnot(None)
                )
                
                if timeframe:
                    # Timeframe'e göre filtreleme eklenebilir
                    pass
                
                results = query.limit(100).all()
                
                if not results:
                    return None
                
                pnl_percentages = [r.pnl_percent for r in results]
                win_count = sum(1 for pnl in pnl_percentages if pnl > 0)
                
                import numpy as np
                
                performance = {
                    'win_rate': win_count / len(pnl_percentages) * 100,
                    'avg_profit': np.mean(pnl_percentages),
                    'sharpe_ratio': np.mean(pnl_percentages) / np.std(pnl_percentages) if np.std(pnl_percentages) != 0 else 0,
                    'max_drawdown': self._calculate_max_drawdown(pnl_percentages),
                    'sample_size': len(results),
                    'total_profit': sum(pnl_percentages)
                }
                
                return performance
                
        except Exception as e:
            logger.error(f"Failed to analyze trade performance: {e}")
            return None
    
    @staticmethod
    def _calculate_max_drawdown(returns: List[float]) -> float:
        """Maksimum drawdown hesapla"""
        cumulative = np.cumsum(returns)
        running_max = np.maximum.accumulate(cumulative)
        drawdown = cumulative - running_max
        return np.min(drawdown)
    
    def clean_old_data(self, days: int = 30):
        """Eski verileri temizle"""
        try:
            with self.get_session() as session:
                cutoff_date = datetime.utcnow() - timedelta(days=days)
                
                deleted = session.query(TradeSignal).filter(
                    TradeSignal.timestamp < cutoff_date,
                    TradeSignal.execution_status == 'closed'
                ).delete()
                
                logger.info(f"Cleaned {deleted} old records")
                
        except Exception as e:
            logger.error(f"Failed to clean old data: {e}")
    
    def backup_database(self, backup_path: str):
        """Veritabanını yedekle"""
        try:
            if 'sqlite' in self.db_url:
                import shutil
                db_file = self.db_url.replace('sqlite:///', '')
                shutil.copy2(db_file, backup_path)
                logger.info(f"Database backed up to: {backup_path}")
            else:
                logger.warning("Backup only supports SQLite databases")
                
        except Exception as e:
            logger.error(f"Database backup failed: {e}")
    
    def close(self):
        """Veritabanı bağlantısını kapat"""
        if self.Session:
            self.Session.remove()
        if self.engine:
            self.engine.dispose()
        logger.info("Database connection closed")


# Global database instance
db_manager = DatabaseManager()