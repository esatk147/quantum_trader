# core/data_collector.py
from typing import Dict, Any, Optional, List, Union
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import json
from .database import db_manager
from .logger import logger
from .config import config


class DataCollector:
    """Merkezi veri toplama ve yönetim sistemi"""
    
    def __init__(self):
        self.cache: Dict[str, Dict] = {}
        self.cache_ttl = timedelta(minutes=5)
        
    def save_signal(self, signal_data: Dict[str, Any]):
        """Trading sinyalini kaydet"""
        try:
            # Signal verisini veritabanı formatına çevir
            trade_signal_data = {
                'trade_no': signal_data.get('trade_no'),
                'timestamp': datetime.utcnow(),
                'coin': signal_data.get('coin'),
                'direction': signal_data.get('direction'),
                'entry_price': signal_data.get('entry_price'),
                'exit_tp': signal_data.get('exit_tp'),
                'exit_sl': signal_data.get('exit_sl'),
                'position_size': signal_data.get('position_size'),
                'actual_exit_price': signal_data.get('actual_exit_price'),
                'actual_pnl': signal_data.get('actual_pnl'),
                'pnl_percent': signal_data.get('pnl_percent'),
                'rsi_4h': signal_data.get('rsi_4h'),
                'rsi_15m': signal_data.get('rsi_15m'),
                'ema100': signal_data.get('ema100'),
                'macd': signal_data.get('macd'),
                'atr': signal_data.get('atr'),
                'supertrend': signal_data.get('supertrend'),
                'vwap': signal_data.get('vwap'),
                'trend_direction': signal_data.get('trend_direction'),
                'volume': signal_data.get('volume'),
                'btc_price': signal_data.get('btc_price'),
                'eth_price': signal_data.get('eth_price'),
                'btc_dominance': signal_data.get('btc_dominance'),
                'funding_rate': signal_data.get('funding_rate'),
                'parameters': json.dumps(signal_data.get('parameters', {})),
                'performance': signal_data.get('performance'),
                'execution_status': signal_data.get('execution_status', 'pending'),
                'trade_duration': signal_data.get('trade_duration'),
                'market_condition': signal_data.get('market_condition', 'normal')
            }
            
            db_manager.save_signal(trade_signal_data)
            logger.debug(f"Signal saved: {signal_data.get('coin')} {signal_data.get('direction')}")
            
        except Exception as e:
            logger.error(f"Failed to save signal: {e}")
    
    def save_trade_result(self, trade_id: int, result: Dict[str, Any]):
        """Trade sonucunu güncelle"""
        try:
            update_data = {
                'actual_exit_price': result.get('exit_price'),
                'actual_pnl': result.get('pnl'),
                'pnl_percent': result.get('pnl_percent'),
                'execution_status': result.get('status', 'closed'),
                'trade_duration': result.get('duration'),
                'performance': result.get('performance')
            }
            
            db_manager.save_trade_result(trade_id, update_data)
            logger.debug(f"Trade result updated: {trade_id}")
            
        except Exception as e:
            logger.error(f"Failed to save trade result: {e}")
    
    def save_optimal_parameters(self, coin: str, timeframe: str, market_condition: str, params: Dict[str, Any]):
        """Optimum parametreleri kaydet"""
        try:
            db_manager.save_optimal_parameters(coin, timeframe, market_condition, params)
            logger.debug(f"Optimal parameters saved: {coin}")
            
        except Exception as e:
            logger.error(f"Failed to save optimal parameters: {e}")
    
    def get_optimal_parameters(self, coin: str, timeframe: str, market_condition: str) -> Optional[Dict[str, Any]]:
        """Optimum parametreleri getir"""
        try:
            cache_key = f"optimal_params_{coin}_{timeframe}_{market_condition}"
            
            # Cache kontrolü
            if self._check_cache(cache_key):
                return self.cache[cache_key]['data']
            
            # Veritabanından al
            params = db_manager.get_optimal_parameters(coin, timeframe, market_condition)
            
            if params:
                # Cache'e kaydet
                self.cache[cache_key] = {
                    'data': params,
                    'timestamp': datetime.utcnow()
                }
            
            return params
            
        except Exception as e:
            logger.error(f"Failed to get optimal parameters: {e}")
            return None
    
    def calculate_trade_performance(self, coin: str, timeframe: str = None) -> Optional[Dict[str, Any]]:
        """Trade performansını analiz et"""
        try:
            cache_key = f"performance_{coin}_{timeframe}"
            
            # Cache kontrolü
            if self._check_cache(cache_key):
                return self.cache[cache_key]['data']
            
            # Performans analizi
            performance = db_manager.analyze_trade_performance(coin, timeframe)
            
            if performance:
                # Cache'e kaydet
                self.cache[cache_key] = {
                    'data': performance,
                    'timestamp': datetime.utcnow()
                }
            
            return performance
            
        except Exception as e:
            logger.error(f"Failed to calculate trade performance: {e}")
            return None
    
    def analyze_market_condition(self, df: pd.DataFrame) -> str:
        """Piyasa durumunu analiz et"""
        try:
            # Volatilite hesapla
            volatility = df['close'].pct_change().std() * np.sqrt(252)
            
            # Trend gücü
            price_change_20d = (df['close'].iloc[-1] - df['close'].iloc[-20]) / df['close'].iloc[-20]
            
            # Hacim profili
            volume_change = df['volume'].pct_change().mean()
            
            # Koşulları değerlendir
            if volatility > 0.5:
                condition = "high_volatility"
            elif abs(price_change_20d) > 0.2:
                condition = "strong_trend"
            elif volatility < 0.1 and abs(price_change_20d) < 0.05:
                condition = "ranging"
            elif volume_change > 0.5:
                condition = "high_volume"
            else:
                condition = "normal"
            
            return condition
            
        except Exception as e:
            logger.error(f"Market condition analysis failed: {e}")
            return "normal"
    
    def get_market_metrics(self, symbols: List[str]) -> Dict[str, Any]:
        """Genel piyasa metriklerini al"""
        try:
            metrics = {
                'timestamp': datetime.utcnow(),
                'btc_dominance': self._get_btc_dominance(),
                'market_cap': self._get_total_market_cap(),
                'fear_greed_index': self._get_fear_greed_index(),
                'funding_rates': self._get_funding_rates(symbols),
                'volume_profile': self._get_volume_profile(symbols)
            }
            
            return metrics
            
        except Exception as e:
            logger.error(f"Failed to get market metrics: {e}")
            return {}
    
    def _get_btc_dominance(self) -> float:
        """BTC dominansını al"""
        try:
            # API'den veya cache'den al
            # Bu örnekte sabit değer dönüyoruz
            return 42.5
            
        except Exception as e:
            logger.error(f"Failed to get BTC dominance: {e}")
            return 40.0
    
    def _get_total_market_cap(self) -> float:
        """Toplam piyasa değerini al"""
        try:
            # API'den veya cache'den al
            # Bu örnekte sabit değer dönüyoruz
            return 1.2e12  # 1.2 trilyon
            
        except Exception as e:
            logger.error(f"Failed to get market cap: {e}")
            return 1.0e12
    
    def _get_fear_greed_index(self) -> int:
        """Fear & Greed index'i al"""
        try:
            # API'den veya cache'den al
            # Bu örnekte sabit değer dönüyoruz
            return 45  # Nötr
            
        except Exception as e:
            logger.error(f"Failed to get fear & greed index: {e}")
            return 50
    
    def _get_funding_rates(self, symbols: List[str]) -> Dict[str, float]:
        """Funding rate'leri al"""
        try:
            funding_rates = {}
            
            for symbol in symbols:
                # Exchange'den al
                # Bu örnekte sabit değer dönüyoruz
                funding_rates[symbol] = 0.0001
            
            return funding_rates
            
        except Exception as e:
            logger.error(f"Failed to get funding rates: {e}")
            return {}
    
    def _get_volume_profile(self, symbols: List[str]) -> Dict[str, Dict[str, float]]:
        """Hacim profilini analiz et"""
        try:
            volume_profiles = {}
            
            for symbol in symbols:
                # Hacim profil analizi
                # Bu örnekte sabit değerler dönüyoruz
                volume_profiles[symbol] = {
                    'average_24h': 1000000,
                    'spike_factor': 1.2,
                    'distribution': 'normal'
                }
            
            return volume_profiles
            
        except Exception as e:
            logger.error(f"Failed to get volume profile: {e}")
            return {}
    
    def get_signal_statistics(self, coin: str = None, days: int = 30) -> Dict[str, Any]:
        """Sinyal istatistiklerini al"""
        try:
            with db_manager.get_session() as session:
                from .database import TradeSignal
                
                query = session.query(TradeSignal)
                
                if coin:
                    query = query.filter(TradeSignal.coin == coin)
                
                # Son N günü filtrele
                if days:
                    start_date = datetime.utcnow() - timedelta(days=days)
                    query = query.filter(TradeSignal.timestamp >= start_date)
                
                signals = query.all()
                
                if not signals:
                    return {'total_signals': 0}
                
                # İstatistikler
                stats = {
                    'total_signals': len(signals),
                    'buy_signals': sum(1 for s in signals if s.direction == 'BUY'),
                    'sell_signals': sum(1 for s in signals if s.direction == 'SELL'),
                    'closed_trades': sum(1 for s in signals if s.execution_status == 'closed'),
                    'pending_trades': sum(1 for s in signals if s.execution_status != 'closed'),
                    'successful_trades': sum(1 for s in signals if s.actual_pnl and s.actual_pnl > 0),
                    'total_pnl': sum(s.actual_pnl for s in signals if s.actual_pnl),
                    'average_pnl': np.mean([s.actual_pnl for s in signals if s.actual_pnl]),
                    'win_rate': sum(1 for s in signals if s.actual_pnl and s.actual_pnl > 0) / 
                                max(1, sum(1 for s in signals if s.actual_pnl))
                }
                
                return stats
                
        except Exception as e:
            logger.error(f"Failed to get signal statistics: {e}")
            return {}
    
    def _check_cache(self, key: str) -> bool:
        """Cache geçerliliğini kontrol et"""
        if key in self.cache:
            cache_data = self.cache[key]
            if datetime.utcnow() - cache_data['timestamp'] < self.cache_ttl:
                return True
            else:
                del self.cache[key]
        return False
    
    def clean_old_data(self, days: int = 30):
        """Eski verileri temizle"""
        try:
            db_manager.clean_old_data(days)
            
            # Cache temizleme
            current_time = datetime.utcnow()
            keys_to_remove = []
            
            for key, cache_data in self.cache.items():
                if current_time - cache_data['timestamp'] > self.cache_ttl:
                    keys_to_remove.append(key)
            
            for key in keys_to_remove:
                del self.cache[key]
            
            logger.info(f"Data cleanup completed. Cache cleaned: {len(keys_to_remove)} items")
            
        except Exception as e:
            logger.error(f"Data cleanup failed: {e}")
    
    def export_data(self, output_path: str, format: str = 'csv', coin: str = None, 
                   start_date: datetime = None, end_date: datetime = None):
        """Verileri dışa aktar"""
        try:
            with db_manager.get_session() as session:
                from .database import TradeSignal
                
                query = session.query(TradeSignal)
                
                if coin:
                    query = query.filter(TradeSignal.coin == coin)
                if start_date:
                    query = query.filter(TradeSignal.timestamp >= start_date)
                if end_date:
                    query = query.filter(TradeSignal.timestamp <= end_date)
                
                signals = query.all()
                
                # DataFrame'e çevir
                data = []
                for signal in signals:
                    signal_dict = {c.name: getattr(signal, c.name) for c in signal.__table__.columns}
                    if signal.parameters:
                        signal_dict['parameters'] = json.loads(signal.parameters)
                    data.append(signal_dict)
                
                df = pd.DataFrame(data)
                
                # Export format
                if format == 'csv':
                    df.to_csv(output_path, index=False)
                elif format == 'json':
                    df.to_json(output_path, orient='records', indent=4)
                elif format == 'excel':
                    df.to_excel(output_path, index=False)
                else:
                    raise ValueError(f"Unsupported format: {format}")
                
                logger.info(f"Data exported to {output_path}")
                
        except Exception as e:
            logger.error(f"Data export failed: {e}")


# Global data collector instance
data_collector = DataCollector()