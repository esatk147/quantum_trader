# core/logger.py
import logging
import logging.handlers
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional
import coloredlogs


class CustomFormatter(logging.Formatter):
    """Özel log formatı"""
    
    FORMATS = {
        logging.DEBUG: "%(asctime)s - %(name)s - DEBUG - %(message)s",
        logging.INFO: "%(asctime)s - %(name)s - INFO - %(message)s",
        logging.WARNING: "%(asctime)s - %(name)s - WARNING - %(message)s",
        logging.ERROR: "%(asctime)s - %(name)s - ERROR - %(message)s",
        logging.CRITICAL: "%(asctime)s - %(name)s - CRITICAL - %(message)s",
    }
    
    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


class LoggerManager:
    """Merkezi logger yönetimi"""
    
    def __init__(self, name: str = "QuantumTrader", log_file: Optional[str] = None):
        self.name = name
        self.log_file = log_file or str(Path("logs") / f"{name.lower()}_{datetime.now():%Y%m%d}.log")
        self._logger = None
        
    def setup_logger(self, level: str = "INFO") -> logging.Logger:
        """Logger'ı ayarla"""
        if self._logger is not None:
            return self._logger
            
        # Logger oluştur
        self._logger = logging.getLogger(self.name)
        self._logger.setLevel(getattr(logging, level))
        
        # Log dosyası için handler
        log_dir = Path(self.log_file).parent
        log_dir.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.handlers.RotatingFileHandler(
            self.log_file,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setFormatter(CustomFormatter())
        file_handler.setLevel(getattr(logging, level))
        
        # Konsol için handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(CustomFormatter())
        console_handler.setLevel(getattr(logging, level))
        
        # Handlers'ı ekle
        self._logger.addHandler(file_handler)
        self._logger.addHandler(console_handler)
        
        # Coloredlogs ile terminal renklendirme
        coloredlogs.install(
            level=level,
            logger=self._logger,
            fmt='%(asctime)s %(hostname)s %(name)s[%(process)d] %(levelname)s %(message)s'
        )
        
        return self._logger
    
    def get_logger(self, name: Optional[str] = None) -> logging.Logger:
        """Logger instance'ını al"""
        if name:
            return logging.getLogger(name)
        
        if self._logger is None:
            self._logger = self.setup_logger()
        
        return self._logger
    
    @staticmethod
    def log_exception(logger: logging.Logger, e: Exception, context: str = ""):
        """Exception'ı detaylı şekilde logla"""
        import traceback
        
        logger.error(f"Exception occurred{' in ' + context if context else ''}: {str(e)}")
        logger.debug(f"Stack trace:\n{traceback.format_exc()}")
    
    @staticmethod
    def log_performance(logger: logging.Logger, start_time: float, operation: str):
        """İşlem süresini logla"""
        import time
        
        elapsed_time = time.time() - start_time
        logger.info(f"{operation} completed in {elapsed_time:.3f} seconds")


class AsyncLogger:
    """Asenkron logging için wrapper"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        
    def debug(self, msg, *args, **kwargs):
        self.logger.debug(msg, *args, **kwargs)
        
    def info(self, msg, *args, **kwargs):
        self.logger.info(msg, *args, **kwargs)
        
    def warning(self, msg, *args, **kwargs):
        self.logger.warning(msg, *args, **kwargs)
        
    def error(self, msg, *args, **kwargs):
        self.logger.error(msg, *args, **kwargs)
        
    def critical(self, msg, *args, **kwargs):
        self.logger.critical(msg, *args, **kwargs)


# Global logger instance
logger_manager = LoggerManager()
logger = logger_manager.get_logger()