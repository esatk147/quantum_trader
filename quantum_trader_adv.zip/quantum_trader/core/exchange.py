# core/exchange.py
import ccxt
import asyncio
import time
from typing import Dict, Any, Optional, List
import pandas as pd
from functools import wraps
from .logger import logger
from .config import config


class ExchangeError(Exception):
    """Exchange işlem hataları için özel exception"""
    pass


class RateLimitError(ExchangeError):
    """Rate limit hatası"""
    pass


def rate_limit_handler(func):
    """Rate limit hatalarını yöneten decorator"""
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        max_retries = 3
        retry_delay = 1
        
        for attempt in range(max_retries):
            try:
                return func(self, *args, **kwargs)
            except ccxt.RateLimitExceeded as e:
                if attempt == max_retries - 1:
                    raise RateLimitError(f"Rate limit exceeded after {max_retries} attempts")
                
                sleep_time = retry_delay * (2 ** attempt)
                logger.warning(f"Rate limit hit, sleeping for {sleep_time} seconds...")
                time.sleep(sleep_time)
            except Exception as e:
                logger.error(f"Exchange error in {func.__name__}: {e}")
                raise ExchangeError(f"Error in {func.__name__}: {str(e)}")
        
        return None
    return wrapper


class ExchangeManager:
    """CCXT Exchange wrapper sınıfı"""
    
    def __init__(self, 
                 api_key: Optional[str] = None, 
                 api_secret: Optional[str] = None, 
                 exchange_name: str = 'binance',
                 demo_mode: bool = True):
        
        self.api_key = api_key or config.get('api_key')
        self.api_secret = api_secret or config.get('api_secret')
        self.exchange_name = exchange_name.lower()
        self.demo_mode = demo_mode
        self.exchange = None
        self._market_cache = {}
        self._last_cache_update = 0
        self._cache_ttl = 3600  # 1 saat
        
    def _initialize_exchange(self) -> ccxt.Exchange:
        """Exchange nesnesini oluştur"""
        try:
            exchange_class = getattr(ccxt, self.exchange_name)
            exchange_options = {
                'apiKey': self.api_key,
                'secret': self.api_secret,
                'enableRateLimit': True,
                'rateLimit': 1200,  # Binance için rate limit
                'options': {
                    'defaultType': config.get('trading_mode', 'spot')
                }
            }
            
            # Demo mode için testnet ayarları
            if self.demo_mode and self.exchange_name == 'bybit':
                exchange_options['urls'] = {
                    'api': 'https://api-testnet.bybit.com'
                }
            elif self.demo_mode and self.exchange_name == 'binance':
                logger.warning("Binance testnet desteklenmiyor. Ana ağ kullanılacak!")
            
            exchange = exchange_class(exchange_options)
            return exchange
            
        except Exception as e:
            raise ExchangeError(f"Exchange initialization failed: {str(e)}")
    
    def connect(self) -> bool:
        """Exchange'e bağlan"""
        try:
            self.exchange = self._initialize_exchange()
            self.exchange.load_markets()
            
            # API izinlerini kontrol et
            if self.api_key and self.api_secret:
                self.check_api_permissions()
            
            logger.info(f"Connected to {self.exchange_name} exchange")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to exchange: {e}")
            return False
    
    def check_api_permissions(self) -> bool:
        """API izinlerini kontrol et"""
        try:
            # Basit bir API çağrısı yaparak bağlantıyı test et
            balance = self.exchange.fetch_balance()
            
            # Trading izni kontrolü
            if not self.demo_mode:
                # Test için açık poziyon sorgusu
                positions = self.fetch_positions()
                
            logger.info("API permissions verified")
            return True
            
        except Exception as e:
            logger.error(f"API permission check failed: {e}")
            return False
    
    @rate_limit_handler
    def fetch_ticker(self, symbol: str) -> Dict[str, Any]:
        """Ticker bilgisini al"""
        return self.exchange.fetch_ticker(symbol)
    
    @rate_limit_handler
    def fetch_ohlcv(self, symbol: str, timeframe: str = '1h', limit: int = 100) -> List[List]:
        """OHLCV verisini al"""
        return self.exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
    
    def get_ohlcv_df(self, symbol: str, timeframe: str = '1h', limit: int = 100) -> pd.DataFrame:
        """OHLCV verisini DataFrame olarak al"""
        try:
            ohlcv = self.fetch_ohlcv(symbol, timeframe, limit)
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            return df
            
        except Exception as e:
            logger.error(f"Error fetching OHLCV data for {symbol}: {e}")
            return pd.DataFrame()
    
    @rate_limit_handler
    def fetch_order_book(self, symbol: str, limit: int = 20) -> Dict[str, Any]:
        """Order book verisini al"""
        return self.exchange.fetch_order_book(symbol, limit)
    
    @rate_limit_handler
    def fetch_balance(self) -> Dict[str, Any]:
        """Hesap bakiyesini al"""
        return self.exchange.fetch_balance()
    
    @rate_limit_handler
    def create_order(self, 
                     symbol: str, 
                     order_type: str, 
                     side: str, 
                     amount: float, 
                     price: Optional[float] = None,
                     params: Dict[str, Any] = None) -> Dict[str, Any]:
        """Emir oluştur"""
        return self.exchange.create_order(symbol, order_type, side, amount, price, params)
    
    @rate_limit_handler
    def cancel_order(self, order_id: str, symbol: str) -> Dict[str, Any]:
        """Emri iptal et"""
        return self.exchange.cancel_order(order_id, symbol)
    
    @rate_limit_handler
    def fetch_order(self, order_id: str, symbol: str) -> Dict[str, Any]:
        """Emir durumunu sorgula"""
        return self.exchange.fetch_order(order_id, symbol)
    
    @rate_limit_handler
    def fetch_positions(self) -> List[Dict[str, Any]]:
        """Açık pozisyonları getir"""
        if hasattr(self.exchange, 'fetch_positions'):
            return self.exchange.fetch_positions()
        return []
    
    def fetch_markets(self, force_reload: bool = False) -> Dict[str, Any]:
        """Markets verisini cache'li olarak al"""
        current_time = time.time()
        
        if force_reload or current_time - self._last_cache_update > self._cache_ttl:
            try:
                self._market_cache = self.exchange.load_markets()
                self._last_cache_update = current_time
            except Exception as e:
                logger.error(f"Failed to fetch markets: {e}")
                
        return self._market_cache
    
    def get_market_info(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Specific market info al"""
        markets = self.fetch_markets()
        return markets.get(symbol)
    
    def is_market_active(self, symbol: str) -> bool:
        """Market'in aktif olup olmadığını kontrol et"""
        market_info = self.get_market_info(symbol)
        return market_info.get('active', False) if market_info else False
    
    async def start_websocket(self, symbol: str, callback):
        """WebSocket bağlantısını başlat"""
        # Gelecekte websocket implementasyonu burada olacak
        logger.info(f"WebSocket başlatılacak: {symbol}")
        raise NotImplementedError("WebSocket implementation pending")
    
    def close(self):
        """Exchange bağlantısını kapat"""
        if self.exchange:
            self.exchange.close()
            logger.info(f"Closed connection to {self.exchange_name}")


# Global exchange instance
exchange_manager = ExchangeManager()