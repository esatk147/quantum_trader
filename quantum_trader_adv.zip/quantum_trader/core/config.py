# core/config.py
import os
from pathlib import Path
from typing import Dict, Any, Optional
from dotenv import load_dotenv
import yaml
import json


class Config:
    """Merkezi konfigürasyon yönetimi"""
    
    def __init__(self):
        self._config: Dict[str, Any] = {}
        self._env_loaded = False
        
    def load_env(self, env_file: Optional[str] = None):
        """Environment değişkenlerini yükle"""
        if not self._env_loaded:
            load_dotenv(env_file)
            self._env_loaded = True
            
            # Temel environment değişkenlerini yükle
            self._config.update({
                # Exchange ayarları
                'api_key': os.getenv('API_KEY', ''),
                'api_secret': os.getenv('API_SECRET', ''),
                'exchange_name': os.getenv('EXCHANGE_NAME', 'binance'),
                'trading_mode': os.getenv('TRADING_MODE', 'spot'),
                'demo_mode': os.getenv('DEMO_MODE', 'True').lower() == 'true',
                
                # Telegram ayarları
                'telegram_token': os.getenv('TELEGRAM_TOKEN', ''),
                'telegram_chat_id': os.getenv('TELEGRAM_CHAT_ID', ''),
                
                # Database ayarları
                'database_path': os.getenv('DATABASE_PATH', './data/crypto_data.db'),
                
                # Logging ayarları
                'log_level': os.getenv('LOG_LEVEL', 'INFO'),
                'log_file_path': os.getenv('LOG_FILE_PATH', './logs/quantum_trader.log'),
                
                # Trading parametreleri
                'position_size': float(os.getenv('POSITION_SIZE', '1.0')),
                'risk_percent': float(os.getenv('RISK_PERCENT', '1.0')),
                'max_positions': int(os.getenv('MAX_POSITIONS', '5')),
                'stop_loss_percent': float(os.getenv('STOP_LOSS_PERCENT', '2.0')),
                'take_profit_percent': float(os.getenv('TAKE_PROFIT_PERCENT', '3.0')),
                
                # Strateji parametreleri
                'rsi_length': int(os.getenv('RSI_LENGTH', '25')),
                'rsi_overbought': int(os.getenv('RSI_OVERBOUGHT', '70')),
                'rsi_oversold': int(os.getenv('RSI_OVERSOLD', '30')),
                'signal_period': int(os.getenv('SIGNAL_PERIOD', '5')),
                'long_period': int(os.getenv('LONG_PERIOD', '27')),
                
                # ML ayarları
                'learning_threshold': int(os.getenv('LEARNING_THRESHOLD', '5000')),
                'ml_train_interval': int(os.getenv('ML_TRAIN_INTERVAL', '100')),
            })
    
    def load_json(self, json_file: str):
        """JSON konfigürasyon dosyasını yükle"""
        if os.path.exists(json_file):
            with open(json_file, 'r') as f:
                self._config.update(json.load(f))
    
    def load_yaml(self, yaml_file: str):
        """YAML konfigürasyon dosyasını yükle"""
        if os.path.exists(yaml_file):
            with open(yaml_file, 'r') as f:
                self._config.update(yaml.safe_load(f))
    
    def get(self, key: str, default: Any = None) -> Any:
        """Konfigürasyon değerini al"""
        return self._config.get(key, default)
    
    def set(self, key: str, value: Any):
        """Konfigürasyon değerini ayarla"""
        self._config[key] = value
    
    def get_trading_settings(self) -> Dict[str, Any]:
        """Trading ayarlarını al"""
        return {
            'position_size': self.get('position_size'),
            'risk_percent': self.get('risk_percent'),
            'max_positions': self.get('max_positions'),
            'stop_loss_percent': self.get('stop_loss_percent'),
            'take_profit_percent': self.get('take_profit_percent'),
            'take_profit_type': self.get('take_profit_type', 'percent'),
        }
    
    def get_strategy_settings(self) -> Dict[str, Any]:
        """Strateji ayarlarını al"""
        return {
            'rsi_length': self.get('rsi_length'),
            'rsi_overbought': self.get('rsi_overbought'),
            'rsi_oversold': self.get('rsi_oversold'),
            'signal_period': self.get('signal_period'),
            'long_period': self.get('long_period'),
            'buying_pressure_threshold': self.get('buying_pressure_threshold', 0.2),
            'selling_pressure_threshold': self.get('selling_pressure_threshold', -0.2),
            'trend_strength_threshold': self.get('trend_strength_threshold', 0),
            'trend_smoothing': self.get('trend_smoothing', 14),
            'atr_multiplier': self.get('atr_multiplier', 2),
            'atr_length': self.get('atr_length', 14),
            'di_length': self.get('di_length', 14),
        }
    
    def ensure_directories(self):
        """Gerekli dizinleri oluştur"""
        dirs = [
            Path('data'),
            Path('logs'),
            Path('data/watchlists'),
            Path('data/config'),
            Path('data/backups'),
        ]
        
        for dir_path in dirs:
            dir_path.mkdir(parents=True, exist_ok=True)
            
        # Base directory'yi de ayarla
        self._config['base_dir'] = Path.home() / '.quantum_trader'
        self._config['base_dir'].mkdir(exist_ok=True)
        
    @property
    def config(self) -> Dict[str, Any]:
        """Tüm konfigürasyonu döndür"""
        return self._config.copy()


# Global config instance
config = Config()