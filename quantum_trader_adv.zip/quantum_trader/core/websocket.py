# core/websocket.py
import websockets
import json
import asyncio
import aiohttp
from typing import Dict, Any, Optional, Callable, List, Coroutine
from dataclasses import dataclass
from datetime import datetime
from .logger import logger
from .config import config


@dataclass
class WSConfig:
    """WebSocket konfigürasyonu"""
    url: str
    ping_interval: int = 20
    ping_timeout: int = 20
    reconnect_delay: int = 5
    max_reconnects: int = 10
    buffer_size: int = 1000


class WSMessage:
    """WebSocket mesaj wrapper'ı"""
    def __init__(self, message: Dict[str, Any], timestamp: datetime = None):
        self.message = message
        self.timestamp = timestamp or datetime.utcnow()
        self.channel = message.get('channel')
        self.event = message.get('event')
        self.data = message.get('data')


class WebSocketManager:
    """WebSocket bağlantı yönetimi"""
    
    def __init__(self, config: WSConfig):
        self.config = config
        self.websocket = None
        self.callbacks: Dict[str, List[Callable]] = {}
        self.buffer = asyncio.Queue(maxsize=config.buffer_size)
        self.is_running = False
        self.reconnect_count = 0
        self._connection_lost = asyncio.Event()
        self._receive_task = None
        self._process_task = None
        
    async def connect(self) -> bool:
        """WebSocket'e bağlan"""
        try:
            self.websocket = await websockets.connect(
                self.config.url,
                ping_interval=self.config.ping_interval,
                ping_timeout=self.config.ping_timeout
            )
            
            self.is_running = True
            self.reconnect_count = 0
            self._connection_lost.clear()
            
            logger.info(f"WebSocket connected to: {self.config.url}")
            
            # Mesaj alma ve işleme task'larını başlat
            self._receive_task = asyncio.create_task(self._receive_messages())
            self._process_task = asyncio.create_task(self._process_messages())
            
            return True
            
        except Exception as e:
            logger.error(f"WebSocket connection failed: {e}")
            return False
    
    async def disconnect(self):
        """WebSocket bağlantısını kapat"""
        self.is_running = False
        
        if self._receive_task:
            self._receive_task.cancel()
        if self._process_task:
            self._process_task.cancel()
            
        if self.websocket:
            await self.websocket.close()
            self.websocket = None
            
        logger.info("WebSocket disconnected")
    
    async def _receive_messages(self):
        """Mesajları al ve buffer'a ekle"""
        try:
            while self.is_running and self.websocket:
                message = await self.websocket.recv()
                
                try:
                    data = json.loads(message)
                    ws_message = WSMessage(data)
                    
                    if not self.buffer.full():
                        await self.buffer.put(ws_message)
                    else:
                        logger.warning("Message buffer is full, dropping message")
                        
                except json.JSONDecodeError:
                    logger.error(f"Failed to parse WebSocket message: {message}")
                    
        except websockets.exceptions.ConnectionClosed:
            logger.warning("WebSocket connection closed")
            self._connection_lost.set()
        except Exception as e:
            logger.error(f"Error receiving WebSocket messages: {e}")
            self._connection_lost.set()
    
    async def _process_messages(self):
        """Buffer'daki mesajları işle"""
        while self.is_running:
            try:
                message = await asyncio.wait_for(self.buffer.get(), timeout=1.0)
                
                if message.channel in self.callbacks:
                    for callback in self.callbacks[message.channel]:
                        try:
                            if asyncio.iscoroutinefunction(callback):
                                await callback(message)
                            else:
                                callback(message)
                        except Exception as e:
                            logger.error(f"Callback error for channel {message.channel}: {e}")
                
                self.buffer.task_done()
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error processing message: {e}")
    
    async def subscribe(self, channel: str, callback: Callable):
        """Kanala abone ol"""
        if channel not in self.callbacks:
            self.callbacks[channel] = []
        
        self.callbacks[channel].append(callback)
        logger.info(f"Subscribed to channel: {channel}")
        
        # Kanalı subscribe et
        if self.websocket:
            subscribe_message = {
                "method": "SUBSCRIBE",
                "params": [channel],
                "id": int(datetime.utcnow().timestamp() * 1000)
            }
            await self.websocket.send(json.dumps(subscribe_message))
    
    async def unsubscribe(self, channel: str):
        """Kanaldan ayrıl"""
        if channel in self.callbacks:
            del self.callbacks[channel]
        
        if self.websocket:
            unsubscribe_message = {
                "method": "UNSUBSCRIBE",
                "params": [channel],
                "id": int(datetime.utcnow().timestamp() * 1000)
            }
            await self.websocket.send(json.dumps(unsubscribe_message))
        
        logger.info(f"Unsubscribed from channel: {channel}")
    
    async def send_message(self, message: Dict[str, Any]):
        """Mesaj gönder"""
        if self.websocket:
            await self.websocket.send(json.dumps(message))
        else:
            logger.warning("Cannot send message: WebSocket not connected")
    
    async def run_with_reconnect(self):
        """Otomatik yeniden bağlanma ile çalıştır"""
        while self.reconnect_count < self.config.max_reconnects:
            success = await self.connect()
            
            if success:
                await self._connection_lost.wait()
                
                if self.is_running:  # Sadece beklenmedik bağlantı kopmasında
                    self.reconnect_count += 1
                    if self.reconnect_count < self.config.max_reconnects:
                        logger.info(f"Attempting to reconnect... (Attempt {self.reconnect_count})")
                        await asyncio.sleep(self.config.reconnect_delay)
                    else:
                        logger.error("Max reconnection attempts reached")
                        break
            else:
                self.reconnect_count += 1
                await asyncio.sleep(self.config.reconnect_delay)
        
        logger.info("WebSocket manager stopped")


class ExchangeWebSocket:
    """Exchange'e özel WebSocket implementasyonu"""
    
    def __init__(self, exchange_name: str):
        self.exchange_name = exchange_name
        self.ws_config = self._get_ws_config(exchange_name)
        self.manager = WebSocketManager(self.ws_config)
        self.connected_streams = set()
        
    def _get_ws_config(self, exchange_name: str) -> WSConfig:
        """Exchange'e göre WebSocket konfigürasyonu"""
        ws_urls = {
            'binance': 'wss://stream.binance.com:9443/ws',
            'bybit': 'wss://stream.bybit.com/realtime'
        }
        
        if exchange_name.lower() in ws_urls:
            return WSConfig(url=ws_urls[exchange_name.lower()])
        else:
            raise ValueError(f"Unsupported exchange: {exchange_name}")
    
    async def connect(self):
        """Bağlan"""
        await self.manager.run_with_reconnect()
    
    async def subscribe_ticker(self, symbol: str, callback: Callable):
        """Ticker güncellemelerine abone ol"""
        if self.exchange_name.lower() == 'binance':
            channel = f"{symbol.lower()}@ticker"
        elif self.exchange_name.lower() == 'bybit':
            channel = f"instrument_info.100ms.{symbol}"
        else:
            raise ValueError(f"Unsupported exchange: {self.exchange_name}")
        
        await self.manager.subscribe(channel, callback)
        self.connected_streams.add(channel)
    
    async def subscribe_orderbook(self, symbol: str, callback: Callable, levels: int = 20):
        """Order book güncellemelerine abone ol"""
        if self.exchange_name.lower() == 'binance':
            channel = f"{symbol.lower()}@depth{levels}"
        elif self.exchange_name.lower() == 'bybit':
            channel = f"orderBookL2_25.{symbol}"
        else:
            raise ValueError(f"Unsupported exchange: {self.exchange_name}")
        
        await self.manager.subscribe(channel, callback)
        self.connected_streams.add(channel)
    
    async def subscribe_trades(self, symbol: str, callback: Callable):
        """Trade akışına abone ol"""
        if self.exchange_name.lower() == 'binance':
            channel = f"{symbol.lower()}@trade"
        elif self.exchange_name.lower() == 'bybit':
            channel = f"trade.{symbol}"
        else:
            raise ValueError(f"Unsupported exchange: {self.exchange_name}")
        
        await self.manager.subscribe(channel, callback)
        self.connected_streams.add(channel)
    
    async def disconnect(self):
        """Bağlantıyı kes"""
        await self.manager.disconnect()
        self.connected_streams.clear()


# Async context manager
class AsyncWebSocket:
    """Asenkron WebSocket context manager"""
    
    def __init__(self, exchange_name: str):
        self.exchange_name = exchange_name
        self.ws = None
    
    async def __aenter__(self):
        self.ws = ExchangeWebSocket(self.exchange_name)
        await self.ws.connect()
        return self.ws
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.ws:
            await self.ws.disconnect()


# Example usage
async def ticker_callback(message: WSMessage):
    """Ticker message handler örneği"""
    logger.info(f"Ticker update: {message.data}")


async def example_usage():
    """Kullanım örneği"""
    ws_config = WSConfig(url='wss://stream.binance.com:9443/ws')
    manager = WebSocketManager(ws_config)
    
    # Manual connection
    if await manager.connect():
        await manager.subscribe('btcusdt@ticker', ticker_callback)
        # Run for some time
        await asyncio.sleep(60)
        await manager.disconnect()
    
    # Or using context manager
    async with AsyncWebSocket('binance') as ws:
        await ws.subscribe_ticker('BTCUSDT', ticker_callback)
        await asyncio.sleep(60)