# ui/dashboard.py
import PySimpleGUI as sg
import sys
import os
from datetime import datetime
from typing import Dict, Any, Optional, List
import queue
import threading
from ui.components.charts import ChartComponent
from ui.components.dialogs import ConfirmDialog, ErrorDialog
from ui.windows.strategy_settings import StrategySettingsWindow
from ui.windows.trading_settings import TradingSettingsWindow
from ui.windows.portfolio_status import PortfolioStatusWindow
from ui.windows.performance_analysis import PerformanceAnalysisWindow
from core.config import config
from core.logger import logger
from core.thread_manager import thread_manager, ThreadTask


class Dashboard:
    """Ana uygulama kontrol paneli"""
    
    def __init__(self):
        self.window = None
        self.app = None
        self.is_running = False
        self.log_queue = queue.Queue()
        self.status_bar_text = ""
        self.active_threads = []
        
        # Componetler
        self.chart = None
        self.strategy_window = None
        self.trading_window = None
        self.portfolio_window = None
        self.performance_window = None
        
        # Tema ayarları
        sg.theme('DarkBlue15')
        
    def create_ui(self) -> sg.Window:
        """Kullanıcı arayüzünü oluştur"""
        
        # Menü tanımı
        menu_def = [
            ['Dosya', ['Yeni Portföy', 'Portföy Yükle', 'Portföy Kaydet', '---', 'Ayarlar', '---', 'Çıkış']],
            ['Strateji', ['Strateji Ayarları', 'Backtest Çalıştır', 'Optimizasyon']],
            ['Trading', ['Trading Ayarları', 'Manuel Order', 'Pozisyonları Kapat']],
            ['Analiz', ['Performans Analizi', 'Coin Performansları', 'Risk Dashboard', 'Korelasyon Analizi']],
            ['Portföy', ['Portföy Durumu', 'Manuel Dengeleme', 'Portföy Raporları']],
            ['Sıktem', ['Test Net/Live', 'API İzinleri', 'Log Görüntüleyici', 'Veri Yedekleme']],
            ['Yardım', ['Hakkında', 'Kullanım Kılavuzu', 'Güncellemeleri Kontrol Et']]
        ]
        
        # Kontrol Paneli
        control_col = [
            [sg.Frame('Bağlantı Kontrolü', [
                [sg.Text('Exchange:'), sg.Text('❌ Bağlı Değil', key='EXCHANGE_STATUS', text_color='red')],
                [sg.Text('Telegram:'), sg.Text('❌ Bağlı Değil', key='TELEGRAM_STATUS', text_color='red')],
                [sg.Text('ML Sistemi:'), sg.Text('⌛ Yükleniyor', key='ML_STATUS', text_color='yellow')],
                [sg.Button('Bağlan', key='CONNECT', size=(10,1)), 
                 sg.Button('Başlat', key='START', size=(10,1), disabled=True),
                 sg.Button('Durdur', key='STOP', size=(10,1), disabled=True)]
            ], expand_x=True)],
            
            [sg.Frame('Trading Ayarları', [
                [sg.Text('Mod:'), sg.Combo(['Spot', 'Futures'], default_value='Spot', key='TRADING_MODE', readonly=True)],
                [sg.Checkbox('Telegram Bildirimleri', default=True, key='TELEGRAM_ENABLED')],
                [sg.Checkbox('Otomatik Trading', default=False, key='TRADING_ENABLED')],
                [sg.Checkbox('Demo Modu', default=True, key='DEMO_MODE')]
            ], expand_x=True)],
            
            [sg.Frame('Hızlı Eylemler', [
                [sg.Button('Sinyal Taraması', key='QUICK_SCAN', size=(15,1))],
                [sg.Button('Portföy Yeniden dengele', key='QUICK_REBALANCE', size=(15,1))],
                [sg.Button('Acil Çıkış', key='EMERGENCY_EXIT', size=(15,1), button_color=('white', 'red'))]
            ], expand_x=True)]
        ]
        
        # İstatistikler Paneli
        stats_col = [
            [sg.Frame('Sistem İstatistikleri', [
                [sg.Text('Aktif Pozisyonlar:', font=('Helvetica', 10)), 
                 sg.Text('0', key='ACTIVE_POSITIONS', font=('Helvetica', 10, 'bold'), text_color='yellow')],
                [sg.Text('Bugünkü Kazanç:', font=('Helvetica', 10)), 
                 sg.Text('0.00 USDT', key='DAILY_PNL', font=('Helvetica', 10, 'bold'), text_color='green')],
                [sg.Text('Toplam Risk:', font=('Helvetica', 10)), 
                 sg.Text('0%', key='TOTAL_RISK', font=('Helvetica', 10, 'bold'), text_color='red')],
                [sg.Text('Portföy Sağlığı:', font=('Helvetica', 10)), 
                 sg.Text('İyi', key='PORTFOLIO_HEALTH', font=('Helvetica', 10, 'bold'), text_color='green')]
            ], expand_x=True)],
            
            [sg.Frame('ML Sistemi', [
                [sg.Text('Model Durumu:', font=('Helvetica', 10)), 
                 sg.Text('Eğitiliyor', key='MODEL_STATUS', font=('Helvetica', 10, 'bold'), text_color='cyan')],
                [sg.Text('Öğrenme Süreci:', font=('Helvetica', 10)), 
                 sg.ProgressBar(5000, orientation='h', size=(20, 20), key='LEARNING_PROGRESS', bar_color=('green', 'lightgray'))],
                [sg.Text('İlerleme:', font=('Helvetica', 10)), 
                 sg.Text('0/5000', key='SIGNAL_COUNT', font=('Helvetica', 10, 'bold'), text_color='yellow')]
            ], expand_x=True)],
            
            [sg.Frame('Son Aktivite', [
                [sg.Text('Son Sinyal:', font=('Helvetica', 10))],
                [sg.Text('--:--:--', key='LAST_SIGNAL_TIME', font=('Helvetica', 10, 'bold'), text_color='white')],
                [sg.Text('Son İşlem:', font=('Helvetica', 10))],
                [sg.Text('--:--:--', key='LAST_TRADE_TIME', font=('Helvetica', 10, 'bold'), text_color='white')]
            ], expand_x=True)]
        ]
        
        # Chart Alanı
        chart_frame = [[sg.Canvas(key='CHART_CANVAS', size=(600, 300))]]
        chart_col = [
            [sg.Frame('Piyasa Grafikleri', chart_frame, expand_x=True, expand_y=True)]
        ]
        
        # Aktif Sinyaller Tablosu
        headers = ['Sembol', 'Sinyal', 'Fiyat', 'ML Tahmin', 'Saat', 'Durum']
        signal_col = [
            [sg.Frame('Aktif Sinyaller', [
                [sg.Table(values=[], headings=headers, max_col_width=15,
                         auto_size_columns=True,
                         display_row_numbers=False,
                         justification='center',
                         num_rows=10,
                         key='SIGNAL_TABLE',
                         row_height=25,
                         enable_click_events=True)]
            ], expand_x=True)]
        ]
        
        # Log Alanı
        log_col = [
            [sg.Frame('Sistem Günlüğü', [
                [sg.Multiline('', key='LOG_OUTPUT', size=(50, 8), autoscroll=True, disabled=True, 
                              font=('Courier', 9), background_color='#1a1a1a', text_color='lightgreen')]
            ], expand_x=True)]
        ]
        
        # Ana Düzen
        layout = [
            [sg.Menu(menu_def)],
            [sg.Text('Quantum Trader Pro - ML Destekli Trading Sistemi', 
                     font=('Helvetica', 16, 'bold'), justification='center', expand_x=True)],
            [sg.HSeparator()],
            
            # Üst Bölüm
            [sg.Col(control_col, vertical_alignment='top'),
             sg.VSeparator(),
             sg.Col(stats_col, vertical_alignment='top'),
             sg.VSeparator(),
             sg.Col(signal_col, vertical_alignment='top', expand_x=True)],
            
            [sg.HSeparator()],
            
            # Orta Bölüm - Chart
            [sg.Col(chart_col, expand_x=True, expand_y=True)],
            
            [sg.HSeparator()],
            
            # Alt Bölüm - Log
            [sg.Col(log_col, expand_x=True)],
            
            # Durum Çubuğu
            [sg.StatusBar('Hazır', key='STATUS_BAR', expand_x=True)]
        ]
        
        # Pencereyi oluştur
        self.window = sg.Window('Quantum Trader Pro', layout, 
                               finalize=True, 
                               resizable=True,
                               size=(1200, 900),
                               enable_close_attempted_event=True)
        
        # Chart componenti başlat
        self.chart = ChartComponent(self.window['CHART_CANVAS'].TKCanvas)
        
        return self.window
    
    def run(self, app):
        """Uygulamayı çalıştır"""
        self.app = app
        self.window = self.create_ui()
        
        # Log güncelleme thread'i başlat
        log_thread = threading.Thread(target=self.update_log_window, daemon=True)
        log_thread.start()
        
        while True:
            event, values = self.window.read(timeout=100)
            
            if event == sg.WINDOW_CLOSED or event == '-WINDOW CLOSE ATTEMPTED-':
                if self.is_running:
                    if ConfirmDialog.show("Çıkış", "Sistem çalışıyor. Çıkmak istediğinize emin misiniz?"):
                        self.app.stop()
                        break
                else:
                    break
            
            elif event == 'CONNECT':
                self.connect_to_systems()
            
            elif event == 'START':
                self.start_trading()
            
            elif event == 'STOP':
                self.stop_trading()
            
            elif event == 'QUICK_SCAN':
                self.run_quick_scan()
            
            elif event == 'QUICK_REBALANCE':
                self.rebalance_portfolio()
            
            elif event == 'EMERGENCY_EXIT':
                self.emergency_exit()
            
            # Menü işlemleri
            elif event == 'Strateji Ayarları':
                self.open_strategy_settings()
            
            elif event == 'Trading Ayarları':
                self.open_trading_settings()
            
            elif event == 'Portföy Durumu':
                self.open_portfolio_status()
            
            elif event == 'Performans Analizi':
                self.open_performance_analysis()
            
            elif event == 'Ayarlar':
                self.open_general_settings()
            
            elif event == 'Hakkında':
                self.show_about_dialog()
            
            elif event == 'SIGNAL_TABLE':
                self.handle_signal_table_click(values)
            
        self.window.close()
    
    def connect_to_systems(self):
        """Sistemlere bağlan"""
        self.window['CONNECT'].update(disabled=True)
        self.update_status("Bağlanıyor...")
        
        def connect_thread():
            try:
                # Exchange bağlantısı
                if self.app.init_exchange():
                    self.window.write_event_value('EXCHANGE_CONNECTED', True)
                else:
                    self.window.write_event_value('EXCHANGE_CONNECTED', False)
                
                # Telegram bağlantısı
                if self.app.init_telegram():
                    self.window.write_event_value('TELEGRAM_CONNECTED', True)
                else:
                    self.window.write_event_value('TELEGRAM_CONNECTED', False)
                
                # ML sistemi yükle
                self.app.initialize_ml()
                self.window.write_event_value('ML_INITIALIZED', True)
                
            except Exception as e:
                self.window.write_event_value('CONNECTION_ERROR', str(e))
        
        task = ThreadTask("connect", connect_thread)
        thread_manager.create_thread(task)
    
    def start_trading(self):
        """Trading'i başlat"""
        self.is_running = True
        self.window['START'].update(disabled=True)
        self.window['STOP'].update(disabled=False)
        
        # Ayarları al
        self.app.trading_mode = self.window['TRADING_MODE'].get().lower()
        self.app.telegram_enabled = self.window['TELEGRAM_ENABLED'].get()
        self.app.trading_enabled = self.window['TRADING_ENABLED'].get()
        self.app.demo_mode = self.window['DEMO_MODE'].get()
        
        self.app.start_scanning()
        self.update_status("Trading başlatıldı")
    
    def stop_trading(self):
        """Trading'i durdur"""
        if ConfirmDialog.show("Trading Durdur", "Trading'i durdurmak istediğinize emin misiniz?"):
            self.is_running = False
            self.window['STOP'].update(disabled=True)
            self.window['START'].update(disabled=False)
            
            self.app.stop_scanning()
            self.update_status("Trading durduruldu")
    
    def run_quick_scan(self):
        """Hızlı sinyal taraması"""
        self.update_status("Sinyal taraması başlatılıyor...")
        
        def scan_thread():
            try:
                self.app.quick_scan()
                self.window.write_event_value('SCAN_COMPLETE', True)
            except Exception as e:
                self.window.write_event_value('SCAN_ERROR', str(e))
        
        task = ThreadTask("quick_scan", scan_thread)
        thread_manager.create_thread(task)
    
    def rebalance_portfolio(self):
        """Portföyü yeniden dengele"""
        if ConfirmDialog.show("Portföy Dengeleme", "Portföyü yeniden dengelemek istediğinize emin misiniz?"):
            try:
                self.app.rebalance_portfolio()
                self.update_status("Portföy dengelendi")
            except Exception as e:
                ErrorDialog.show("Hata", f"Portföy dengeleme hatası: {str(e)}")
    
    def emergency_exit(self):
        """Acil çıkış - tüm pozisyonları kapat"""
        if ConfirmDialog.show("Acil Çıkış", "TÜM POZİSYONLARI kapatmak istediğinize emin misiniz?"):
            try:
                self.app.emergency_exit_all_positions()
                self.update_status("Acil çıkış gerçekleştirildi")
            except Exception as e:
                ErrorDialog.show("Hata", f"Acil çıkış hatası: {str(e)}")
    
    def open_strategy_settings(self):
        """Strateji ayarları penceresini aç"""
        if not self.strategy_window:
            self.strategy_window = StrategySettingsWindow(self.app)
            self.strategy_window.open()
    
    def open_trading_settings(self):
        """Trading ayarları penceresini aç"""
        if not self.trading_window:
            self.trading_window = TradingSettingsWindow(self.app)
            self.trading_window.open()
    
    def open_portfolio_status(self):
        """Portföy durumu penceresini aç"""
        if not self.portfolio_window:
            self.portfolio_window = PortfolioStatusWindow(self.app)
            self.portfolio_window.open()
    
    def open_performance_analysis(self):
        """Performans analizi penceresini aç"""
        if not self.performance_window:
            self.performance_window = PerformanceAnalysisWindow(self.app)
            self.performance_window.open()
    
    def open_general_settings(self):
        """Genel ayarlar penceresini aç"""
        # TODO: Implement
        pass
    
    def show_about_dialog(self):
        """Hakkında dialog'unu göster"""
        about_text = """
Quantum Trader Pro v1.0

ML Destekli Kripto Para Trading Sistemi

Özellikler:
• RSI Bands & Perfect Entry V9 stratejileri
• Makine öğrenimi destekli tahmin
• Modern Portföy Teorisi ile optimizasyon
• Real-time WebSocket veri akışı
• Akıllı risk yönetimi
• Otomatik portföy dengeleme

© 2024 Quantum Trader Pro
        """
        sg.popup(about_text, title="Hakkında", keep_on_top=True)
    
    def handle_signal_table_click(self, values):
        """Sinyal tablosu tıklama işlemi"""
        if values['SIGNAL_TABLE']:
            row = values['SIGNAL_TABLE'][0]
            self.show_signal_details(row)
    
    def show_signal_details(self, row_index: int):
        """Sinyal detaylarını göster"""
        # TODO: Sinyal detay penceresi
        pass
    
    def update_status(self, message: str):
        """Durum çubuğunu güncelle"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.status_bar_text = f"[{timestamp}] {message}"
        self.window['STATUS_BAR'].update(self.status_bar_text)
    
    def log(self, message: str, level: str = "INFO"):
        """Log mesajı ekle"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {level}: {message}"
        self.log_queue.put(log_entry)
    
    def update_log_window(self):
        """Log penceresini güncelle"""
        while True:
            try:
                log_messages = []
                while not self.log_queue.empty():
                    message = self.log_queue.get_nowait()
                    log_messages.append(message)
                
                if log_messages:
                    current_text = self.window['LOG_OUTPUT'].get()
                    new_text = current_text + "\n" + "\n".join(log_messages)
                    
                    # Son 1000 satırı tut
                    lines = new_text.split('\n')
                    if len(lines) > 1000:
                        lines = lines[-1000:]
                        new_text = '\n'.join(lines)
                    
                    self.window['LOG_OUTPUT'].update(new_text)
                    
            except queue.Empty:
                pass
            except Exception as e:
                print(f"Log update error: {e}")
            
            import time
            time.sleep(0.1)
    
    def update_ui_elements(self, update_data: Dict[str, Any]):
        """UI elementlerini güncelle"""
        try:
            for key, value in update_data.items():
                if key in self.window:
                    self.window[key].update(value)
        except Exception as e:
            print(f"UI update error: {e}")