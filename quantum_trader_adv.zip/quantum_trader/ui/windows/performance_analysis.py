import PySimpleGUI as sg
from ui.components.dialogs import ConfirmDialog, ErrorDialog
from ui.components.charts import ChartComponent
import pandas as pd
from datetime import datetime, timedelta

class PerformanceAnalysisWindow:
    """Performans analizi penceresi"""
    
    def __init__(self, app):
        self.app = app
        self.window = None
        self.chart = None
    
    def open(self):
        """Pencereyi aç ve çalıştır"""
        layout = [
            [sg.Text('Performans Analizi', font=('Helvetica', 16, 'bold'))],
            [sg.HSeparator()],
            
            [sg.Frame('Filtreler', [
                [sg.Text('Periyot:', size=(10,1)), 
                 sg.Combo(['7 Gün', '30 Gün', '90 Gün', '1 Yıl', 'Tümü'], default_value='30 Gün', key='PERIOD'),
                 sg.Text('Strateji:', size=(10,1)),
                 sg.Combo(['Tümü', 'RSI Bands', 'Perfect Entry'], default_value='Tümü', key='STRATEGY'),
                 sg.Button('Uygula', key='APPLY_FILTER')]
            ], expand_x=True)],
            
            [sg.Frame('Genel Metrikler', [
                [sg.Text('Toplam Getiri:', size=(15,1)), sg.Text('0.00%', key='TOTAL_RETURN', size=(20,1))],
                [sg.Text('Kazanma Oranı:', size=(15,1)), sg.Text('0.00%', key='WIN_RATE', size=(20,1))],
                [sg.Text('Sharpe Oranı:', size=(15,1)), sg.Text('0.00', key='SHARPE_RATIO', size=(20,1))],
                [sg.Text('Maks. Drawdown:', size=(15,1)), sg.Text('0.00%', key='MAX_DRAWDOWN', size=(20,1))]
            ], expand_x=True)],
            
            [sg.Frame('Performans Grafiği', [
                [sg.Canvas(key='CHART_CANVAS', size=(800, 400))]
            ], expand_x=True, expand_y=True)],
            
            [sg.Frame('Son İşlemler', [
                [sg.Table(values=[],
                          headings=['Tarih', 'Strateji', 'Sembol', 'İşlem', 'P/L', 'Duration'],
                          col_widths=[15, 12, 10, 8, 10, 10],
                          num_rows=10,
                          key='TRADES_TABLE')]
            ], expand_x=True)],
            
            [sg.Button('Excel Export', key='EXPORT'), 
             sg.Button('Raporla', key='GENERATE_REPORT'),
             sg.Button('Kapat', key='CLOSE')]
        ]
        
        self.window = sg.Window('Performans Analizi', layout, size=(1000, 800), modal=True, finalize=True)
        
        # Chart oluştur
        self.chart = ChartComponent(self.window['CHART_CANVAS'].TKCanvas)
        
        self.refresh_data()
        
        while True:
            event, values = self.window.read()
            
            if event == sg.WINDOW_CLOSED or event == 'CLOSE':
                break
            
            elif event == 'APPLY_FILTER':
                self.refresh_data(values['PERIOD'], values['STRATEGY'])
            
            elif event == 'EXPORT':
                self.export_data()
            
            elif event == 'GENERATE_REPORT':
                self.generate_report()
        
        self.window.close()
        self.window = None
    
    def refresh_data(self, period='30 Gün', strategy='Tümü'):
        """Performans verilerini yenile"""
        try:
            # Performans verileri
            performance_data = self.app.get_performance_data(period, strategy)
            
            if performance_data:
                # Genel metrikler
                self.window['TOTAL_RETURN'].update(f"{performance_data.get('total_return', 0):.2f}%")
                self.window['WIN_RATE'].update(f"{performance_data.get('win_rate', 0):.2f}%")
                self.window['SHARPE_RATIO'].update(f"{performance_data.get('sharpe_ratio', 0):.2f}")
                self.window['MAX_DRAWDOWN'].update(f"{performance_data.get('max_drawdown', 0):.2f}%")
                
                # Trades tablosu
                trades_data = []
                for trade in performance_data.get('recent_trades', []):
                    trades_data.append([
                        trade.get('date', ''),
                        trade.get('strategy', ''),
                        trade.get('symbol', ''),
                        trade.get('direction', ''),
                        f"{trade.get('pnl', 0):.2f}%",
                        trade.get('duration', '')
                    ])
                
                self.window['TRADES_TABLE'].update(values=trades_data)
                
                # Equity curve chart
                if 'equity_curve' in performance_data:
                    self.chart.plot_performance_chart(performance_data['equity_curve'])
                
        except Exception as e:
            ErrorDialog.show("Hata", f"Performans verileri yüklenirken hata: {str(e)}")
    
    def export_data(self):
        """Verileri Excel'e aktar"""
        try:
            filename = sg.popup_get_file('Excel dosyası kaydet', save_as=True, 
                                         file_types=(('Excel Files', '*.xlsx'),),
                                         default_extension='.xlsx')
            if filename:
                # Export logic
                self.app.export_performance_data(filename)
                sg.popup("Başarılı", "Veriler export edildi!", keep_on_top=True)
                
        except Exception as e:
            ErrorDialog.show("Hata", f"Export hatası: {str(e)}")
    
    def generate_report(self):
        """Performans raporu oluştur"""
        try:
            report_file = self.app.generate_performance_report()
            if report_file:
                import os
                os.startfile(report_file)  # Windows için
            else:
                sg.popup("Hata", "Rapor oluşturulamadı!", keep_on_top=True)
                
        except Exception as e:
            ErrorDialog.show("Hata", f"Rapor oluşturma hatası: {str(e)}")