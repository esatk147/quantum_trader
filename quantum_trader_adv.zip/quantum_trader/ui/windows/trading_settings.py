# ui/windows/trading_settings.py
import PySimpleGUI as sg
from typing import Dict, Any, Optional
from ui.components.dialogs import ConfirmDialog, ErrorDialog
from core.config import config


class TradingSettingsWindow:
    """Trading ayarları penceresi"""
    
    def __init__(self, app):
        self.app = app
        self.window = None
        
        # Default trading settings
        self.defaults = {
            'position_size': 100.0,
            'risk_percent': 1.0,
            'max_positions': 5,
            'stop_loss_percent': 2.0,
            'take_profit_type': 'percent',
            'take_profit_value': 3.0,
            'partial_take_profit': True,
            'trailing_stop': True,
            'use_leverage': False,
            'leverage_multiplier': 1.0
        }
    
    def create_window(self):
        """Pencereyi oluştur"""
        # Risk Yönetimi
        risk_management_frame = [
            [sg.Text('Pozisyon Büyüklüğü (USDT):', size=(25,1)), 
             sg.InputText(str(self.defaults['position_size']), key='POSITION_SIZE', size=(15,1))],
            [sg.Text('Risk Yüzdesi (%):', size=(25,1)), 
             sg.InputText(str(self.defaults['risk_percent']), key='RISK_PERCENT', size=(15,1))],
            [sg.Text('Maksimum Pozisyon Sayısı:', size=(25,1)), 
             sg.InputText(str(self.defaults['max_positions']), key='MAX_POSITIONS', size=(15,1))],
            [sg.Text('Maksimum Toplam Risk (%):', size=(25,1)), 
             sg.InputText('20', key='MAX_TOTAL_RISK', size=(15,1))]
        ]
        
        # Stop Loss ve Take Profit
        exit_strategy_frame = [
            [sg.Text('Stop Loss (%):', size=(25,1)), 
             sg.InputText(str(self.defaults['stop_loss_percent']), key='STOP_LOSS', size=(15,1))],
            [sg.Text('Take Profit Tipi:', size=(25,1)), 
             sg.Combo(['percent', 'atr', 'fibonacci'], default_value=self.defaults['take_profit_type'], 
                     key='TP_TYPE', size=(15,1), readonly=True)],
            [sg.Text('Take Profit Değeri:', size=(25,1)), 
             sg.InputText(str(self.defaults['take_profit_value']), key='TP_VALUE', size=(15,1))],
            [sg.Checkbox('Kısmi Kar Al', default=self.defaults['partial_take_profit'], key='PARTIAL_TP')],
            [sg.Checkbox('Trailing Stop Kullan', default=self.defaults['trailing_stop'], key='TRAILING_STOP')]
        ]
        
        # Leverage Ayarları
        leverage_frame = [
            [sg.Checkbox('Leverage Kullan', default=self.defaults['use_leverage'], key='USE_LEVERAGE', enable_events=True)],
            [sg.Text('Leverage Çarpanı:', size=(25,1)), 
             sg.Slider(range=(1,10), default_value=self.defaults['leverage_multiplier'], 
                      orientation='h', size=(20,15), key='LEVERAGE_MULTI', disabled=True)],
            [sg.Text('⚠️ Yüksek leverage yüksek risk taşır!', text_color='red', visible=False, key='LEVERAGE_WARNING')]
        ]
        
        # Kısmi Kar Alma Ayarları
        partial_tp_frame = [
            [sg.Text('Seviye 1:', size=(10,1)), 
             sg.Text('Fiyat:', size=(8,1)), sg.InputText('3', key='TP1_PERCENT', size=(5,1)),
             sg.Text('Oran:', size=(8,1)), sg.InputText('30', key='TP1_RATIO', size=(5,1))],
            [sg.Text('Seviye 2:', size=(10,1)), 
             sg.Text('Fiyat:', size=(8,1)), sg.InputText('5', key='TP2_PERCENT', size=(5,1)),
             sg.Text('Oran:', size=(8,1)), sg.InputText('20', key='TP2_RATIO', size=(5,1))],
            [sg.Text('Seviye 3:', size=(10,1)), 
             sg.Text('Fiyat:', size=(8,1)), sg.InputText('8', key='TP3_PERCENT', size=(5,1)),
             sg.Text('Oran:', size=(8,1)), sg.InputText('20', key='TP3_RATIO', size=(5,1))],
            [sg.Text('Kalan %30 son take profit seviyesinde')] 
        ]
        
        # Advanced Ayarları
        advanced_frame = [
            [sg.Text('Order Type:', size=(25,1)), 
             sg.Combo(['market', 'limit', 'stop_market'], default_value='market', key='ORDER_TYPE', readonly=True)],
            [sg.Text('Limit Order Spread (%):', size=(25,1)), 
             sg.InputText('0.05', key='LIMIT_SPREAD', size=(15,1))],
            [sg.Text('Slippage Toleransı (%):', size=(25,1)), 
             sg.InputText('0.5', key='SLIPPAGE', size=(15,1))],
            [sg.Text('Order Timeout (saniye):', size=(25,1)), 
             sg.InputText('30', key='ORDER_TIMEOUT', size=(15,1))]
        ]
        
        # Ana Layout
        layout = [
            [sg.Text('Trading Ayarları', font=('Helvetica', 16, 'bold'), expand_x=True, justification='center')],
            [sg.HSeparator()],
            
            [sg.Frame('Risk Yönetimi', risk_management_frame, expand_x=True)],
            
            [sg.Frame('Stop Loss & Take Profit', exit_strategy_frame, expand_x=True)],
            
            [sg.Frame('Leverage Ayarları (Futures)', leverage_frame, expand_x=True)],
            
            [sg.Frame('Kısmi Kar Alma Seviyeleri', partial_tp_frame, expand_x=True, visible=True, key='PARTIAL_FRAME')],
            
            [sg.Frame('Gelişmiş Ayarlar', advanced_frame, expand_x=True)],
            
            [sg.Frame('Risk Hesaplayıcı', [
                [sg.Text('Hesap Bakiyesi:', size=(20,1)), 
                 sg.InputText('10000', key='ACCOUNT_BALANCE', size=(15,1), enable_events=True)],
                [sg.Text('Trade Boyutu:', size=(20,1)), 
                 sg.Text('0 USDT', key='TRADE_SIZE', size=(15,1), text_color='yellow')],
                [sg.Text('Risk Tutarı:', size=(20,1)), 
                 sg.Text('0 USDT', key='RISK_AMOUNT', size=(15,1), text_color='orange')],
                [sg.Text('Potansiyel Kar:', size=(20,1)), 
                 sg.Text('0 USDT', key='POTENTIAL_PROFIT', size=(15,1), text_color='green')]
            ], expand_x=True)],
            
            [sg.HSeparator()],
            
            [sg.Button('Kaydet', key='SAVE', size=(10,1), button_color=('white', 'green')),
             sg.Button('İptal', key='CANCEL', size=(10,1), button_color=('white', 'red')),
             sg.Push(),
             sg.Button('Profil Kaydet', key='SAVE_PROFILE', size=(12,1), button_color=('white', 'blue')),
             sg.Button('Profil Yükle', key='LOAD_PROFILE', size=(12,1), button_color=('white', 'blue'))]
        ]
        
        self.window = sg.Window('Trading Ayarları', layout, size=(600, 900), modal=True, finalize=True)
        
        self.load_current_settings()
        self.bind_events()
        self.update_risk_calculator()
        
        return self.window
    
    def bind_events(self):
        """Event binding'leri ayarla"""
        # Değişken değerlerle risk hesaplayıcısını güncelle
        self.window['POSITION_SIZE'].bind('<KeyRelease>', '_KEYRELEASE')
        self.window['RISK_PERCENT'].bind('<KeyRelease>', '_KEYRELEASE')
        self.window['ACCOUNT_BALANCE'].bind('<KeyRelease>', '_KEYRELEASE')
        self.window['STOP_LOSS'].bind('<KeyRelease>', '_KEYRELEASE')
        self.window['TP_VALUE'].bind('<KeyRelease>', '_KEYRELEASE')
    
    def load_current_settings(self):
        """Mevcut ayarları yükle"""
        try:
            settings = self.app.get_trading_settings()
            
            if settings:
                self.window['POSITION_SIZE'].update(settings.get('position_size', self.defaults['position_size']))
                self.window['RISK_PERCENT'].update(settings.get('risk_percent', self.defaults['risk_percent']))
                self.window['MAX_POSITIONS'].update(settings.get('max_positions', self.defaults['max_positions']))
                self.window['STOP_LOSS'].update(settings.get('stop_loss_percent', self.defaults['stop_loss_percent']))
                self.window['TP_TYPE'].update(settings.get('take_profit_type', self.defaults['take_profit_type']))
                self.window['TP_VALUE'].update(settings.get('take_profit_value', self.defaults['take_profit_value']))
                self.window['PARTIAL_TP'].update(settings.get('partial_take_profit', self.defaults['partial_take_profit']))
                self.window['TRAILING_STOP'].update(settings.get('trailing_stop', self.defaults['trailing_stop']))
                self.window['USE_LEVERAGE'].update(settings.get('use_leverage', self.defaults['use_leverage']))
                self.window['LEVERAGE_MULTI'].update(settings.get('leverage_multiplier', self.defaults['leverage_multiplier']))
                
                # Partial take profit ayarları
                partial_tp = settings.get('partial_take_profits', [])
                if len(partial_tp) >= 3:
                    self.window['TP1_PERCENT'].update(partial_tp[0]['percent'])
                    self.window['TP1_RATIO'].update(partial_tp[0]['ratio'])
                    self.window['TP2_PERCENT'].update(partial_tp[1]['percent'])
                    self.window['TP2_RATIO'].update(partial_tp[1]['ratio'])
                    self.window['TP3_PERCENT'].update(partial_tp[2]['percent'])
                    self.window['TP3_RATIO'].update(partial_tp[2]['ratio'])
                
                # Advanced ayarlar
                self.window['ORDER_TYPE'].update(settings.get('order_type', 'market'))
                self.window['LIMIT_SPREAD'].update(settings.get('limit_spread', '0.05'))
                self.window['SLIPPAGE'].update(settings.get('slippage', '0.5'))
                self.window['ORDER_TIMEOUT'].update(settings.get('order_timeout', '30'))
                
        except Exception as e:
            ErrorDialog.show("Hata", f"Ayarlar yüklenirken hata: {str(e)}")
    
    def save_settings(self):
        """Ayarları kaydet"""
        try:
            # Kısmi take profit seviyeleri
            partial_tp = [
                {'percent': float(self.window['TP1_PERCENT'].get()), 'ratio': float(self.window['TP1_RATIO'].get())},
                {'percent': float(self.window['TP2_PERCENT'].get()), 'ratio': float(self.window['TP2_RATIO'].get())},
                {'percent': float(self.window['TP3_PERCENT'].get()), 'ratio': float(self.window['TP3_RATIO'].get())}
            ]
            
            settings = {
                'position_size': float(self.window['POSITION_SIZE'].get()),
                'risk_percent': float(self.window['RISK_PERCENT'].get()),
                'max_positions': int(self.window['MAX_POSITIONS'].get()),
                'stop_loss_percent': float(self.window['STOP_LOSS'].get()),
                'take_profit_type': self.window['TP_TYPE'].get(),
                'take_profit_value': float(self.window['TP_VALUE'].get()),
                'partial_take_profit': self.window['PARTIAL_TP'].get(),
                'trailing_stop': self.window['TRAILING_STOP'].get(),
                'use_leverage': self.window['USE_LEVERAGE'].get(),
                'leverage_multiplier': float(self.window['LEVERAGE_MULTI'].get()),
                'partial_take_profits': partial_tp,
                'order_type': self.window['ORDER_TYPE'].get(),
                'limit_spread': float(self.window['LIMIT_SPREAD'].get()),
                'slippage': float(self.window['SLIPPAGE'].get()),
                'order_timeout': int(self.window['ORDER_TIMEOUT'].get())
            }
            
            # Ayarları uygulamaya kaydet
            self.app.set_trading_settings(settings)
            self.app.save_config()
            
            sg.popup("Başarılı", "Trading ayarları kaydedildi!", keep_on_top=True)
            
        except ValueError as e:
            ErrorDialog.show("Geçersiz Değer", "Lütfen tüm sayısal alanlara geçerli değerler girin.")
        except Exception as e:
            ErrorDialog.show("Hata", f"Ayarlar kaydedilirken hata: {str(e)}")
    
    def update_risk_calculator(self):
        """Risk hesaplayıcısını güncelle"""
        try:
            balance = float(self.window['ACCOUNT_BALANCE'].get())
            position_size = float(self.window['POSITION_SIZE'].get())
            risk_percent = float(self.window['RISK_PERCENT'].get())
            sl_percent = float(self.window['STOP_LOSS'].get())
            tp_value = float(self.window['TP_VALUE'].get())
            
            # Risk tutarı
            risk_amount = position_size * (sl_percent / 100)
            
            # Potansiyel kar
            potential_profit = position_size * (tp_value / 100)
            
            # Risk/Reward oranı
            risk_reward_ratio = potential_profit / risk_amount if risk_amount > 0 else 0
            
            # Güncelle
            self.window['TRADE_SIZE'].update(f"{position_size:.2f} USDT")
            self.window['RISK_AMOUNT'].update(f"{risk_amount:.2f} USDT")
            self.window['POTENTIAL_PROFIT'].update(f"{potential_profit:.2f} USDT")
            
            # Risk uyarısı
            total_risk = (risk_amount / balance) * 100
            if total_risk > 5:
                self.window['RISK_AMOUNT'].update(text_color='red')
            elif total_risk > 2:
                self.window['RISK_AMOUNT'].update(text_color='orange')
            else:
                self.window['RISK_AMOUNT'].update(text_color='green')
                
        except ValueError:
            pass  # Geçersiz giriş durumunda hesaplama yapma
    
    def save_profile(self):
        """Mevcut ayarları profil olarak kaydet"""
        profile_name = sg.popup_get_text('Profil Adı', 'Profil ismi girin:')
        if profile_name:
            try:
                settings = self.get_all_settings()
                self.app.save_trading_profile(profile_name, settings)
                sg.popup("Başarılı", f"'{profile_name}' profili kaydedildi!", keep_on_top=True)
            except Exception as e:
                ErrorDialog.show("Hata", f"Profil kaydedilirken hata: {str(e)}")
    
    def load_profile(self):
        """Kaydedilmiş bir profili yükle"""
        profiles = self.app.get_trading_profiles()
        if profiles:
            layout = [
                [sg.Text('Profil Seçin:', font=('Helvetica', 12))],
                [sg.Listbox(profiles, size=(30, 6), key='PROFILE_LIST')],
                [sg.Button('Yükle', key='LOAD'), sg.Button('İptal', key='CANCEL')]
            ]
            
            window = sg.Window('Profil Yükle', layout, modal=True)
            
            while True:
                event, values = window.read()
                
                if event == sg.WINDOW_CLOSED or event == 'CANCEL':
                    break
                
                elif event == 'LOAD':
                    if values['PROFILE_LIST']:
                        selected_profile = values['PROFILE_LIST'][0]
                        settings = self.app.load_trading_profile(selected_profile)
                        if settings:
                            self.apply_settings(settings)
                            sg.popup("Başarılı", f"'{selected_profile}' profili yüklendi!", keep_on_top=True)
                        break
            
            window.close()
    
    def get_all_settings(self) -> Dict[str, Any]:
        """Tüm ayarları al"""
        try:
            settings = {
                'position_size': float(self.window['POSITION_SIZE'].get()),
                'risk_percent': float(self.window['RISK_PERCENT'].get()),
                'max_positions': int(self.window['MAX_POSITIONS'].get()),
                'stop_loss_percent': float(self.window['STOP_LOSS'].get()),
                'take_profit_type': self.window['TP_TYPE'].get(),
                'take_profit_value': float(self.window['TP_VALUE'].get()),
                'partial_take_profit': self.window['PARTIAL_TP'].get(),
                'trailing_stop': self.window['TRAILING_STOP'].get(),
                'use_leverage': self.window['USE_LEVERAGE'].get(),
                'leverage_multiplier': float(self.window['LEVERAGE_MULTI'].get()),
                'order_type': self.window['ORDER_TYPE'].get(),
                'limit_spread': float(self.window['LIMIT_SPREAD'].get()),
                'slippage': float(self.window['SLIPPAGE'].get()),
                'order_timeout': int(self.window['ORDER_TIMEOUT'].get())
            }
            return settings
        except ValueError:
            raise ValueError("Geçersiz değerler var!")
    
    def apply_settings(self, settings: Dict[str, Any]):
        """Ayarları forma uygula"""
        for key, value in settings.items():
            if key in self.window:
                self.window[key].update(value)
        
        self.update_risk_calculator()
    
    def open(self):
        """Pencereyi aç ve çalıştır"""
        window = self.create_window()
        
        while True:
            event, values = window.read()
            
            if event == sg.WINDOW_CLOSED or event == 'CANCEL':
                break
            
            elif event == 'SAVE':
                self.save_settings()
                break
            
            elif event == 'USE_LEVERAGE':
                # Leverage checkbox değiştiğinde
                is_enabled = values['USE_LEVERAGE']
                self.window['LEVERAGE_MULTI'].update(disabled=not is_enabled)
                self.window['LEVERAGE_WARNING'].update(visible=is_enabled)
            
            elif event == 'SAVE_PROFILE':
                self.save_profile()
            
            elif event == 'LOAD_PROFILE':
                self.load_profile()
            
            elif event.endswith('_KEYRELEASE'):
                # Risk hesaplayıcısını güncelle
                self.update_risk_calculator()
        
        window.close()
        self.window = None