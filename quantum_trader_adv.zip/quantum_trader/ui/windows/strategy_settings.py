# ui/windows/strategy_settings.py
import PySimpleGUI as sg
from typing import Dict, Any, Optional
from ui.components.dialogs import ConfirmDialog, ErrorDialog
from core.config import config


class StrategySettingsWindow:
    """Strateji ayarları penceresi"""
    
    def __init__(self, app):
        self.app = app
        self.window = None
        self.current_strategy = 'RSI Bands'
        self.strategy_tabs = {}
        
        # Default settings
        self.defaults = {
            'RSI Bands': {
                'rsi_length': 25,
                'rsi_overbought': 70,
                'rsi_oversold': 30,
                'trading_hours': {'start': 0, 'end': 24},
                'min_volatility': 0.001,
                'max_volatility': 0.1,
                'min_volume_ratio': 0.5
            },
            'Perfect Entry V9': {
                'signal_period': 5,
                'long_period': 27,
                'buying_pressure_threshold': 0.2,
                'selling_pressure_threshold': -0.2,
                'trend_strength_threshold': 0,
                'trend_smoothing': 14,
                'atr_multiplier': 2,
                'atr_length': 14,
                'di_length': 14
            }
        }
    
    def create_window(self):
        """Pencereyi oluştur"""
        # RSI Bands sekmesi
        rsi_tab = [
            [sg.Frame('Temel Ayarlar', [
                [sg.Text('RSI Uzunluğu:', size=(20,1)), 
                 sg.InputText(str(self.defaults['RSI Bands']['rsi_length']), key='RSI_LENGTH', size=(10,1))],
                [sg.Text('RSI Aşırı Alım Seviyesi:', size=(20,1)), 
                 sg.InputText(str(self.defaults['RSI Bands']['rsi_overbought']), key='RSI_OVERBOUGHT', size=(10,1))],
                [sg.Text('RSI Aşırı Satım Seviyesi:', size=(20,1)), 
                 sg.InputText(str(self.defaults['RSI Bands']['rsi_oversold']), key='RSI_OVERSOLD', size=(10,1))]
            ], expand_x=True)],
            
            [sg.Frame('Trading Saatleri', [
                [sg.Text('Başlangıç Saati:', size=(20,1)), 
                 sg.Spin([i for i in range(24)], initial_value=0, key='RSI_TRADING_START', size=(5,1))],
                [sg.Text('Bitiş Saati:', size=(20,1)), 
                 sg.Spin([i for i in range(24)], initial_value=24, key='RSI_TRADING_END', size=(5,1))]
            ], expand_x=True)],
            
            [sg.Frame('Volatilite Filtreleri', [
                [sg.Text('Minimum Volatilite:', size=(20,1)), 
                 sg.InputText(str(self.defaults['RSI Bands']['min_volatility']), key='RSI_MIN_VOL', size=(10,1))],
                [sg.Text('Maksimum Volatilite:', size=(20,1)), 
                 sg.InputText(str(self.defaults['RSI Bands']['max_volatility']), key='RSI_MAX_VOL', size=(10,1))],
                [sg.Text('Minimum Volume Oranı:', size=(20,1)), 
                 sg.InputText(str(self.defaults['RSI Bands']['min_volume_ratio']), key='RSI_MIN_VOL_RATIO', size=(10,1))]
            ], expand_x=True)]
        ]
        
        # Perfect Entry sekmesi
        perfect_entry_tab = [
            [sg.Frame('Temel Göstergeler', [
                [sg.Text('Sinyal Periyodu:', size=(20,1)), 
                 sg.InputText(str(self.defaults['Perfect Entry V9']['signal_period']), key='PE_SIGNAL_PERIOD', size=(10,1))],
                [sg.Text('Uzun Periyot:', size=(20,1)), 
                 sg.InputText(str(self.defaults['Perfect Entry V9']['long_period']), key='PE_LONG_PERIOD', size=(10,1))],
                [sg.Text('ATR Uzunluğu:', size=(20,1)), 
                 sg.InputText(str(self.defaults['Perfect Entry V9']['atr_length']), key='PE_ATR_LENGTH', size=(10,1))],
                [sg.Text('ATR Çarpanı:', size=(20,1)), 
                 sg.InputText(str(self.defaults['Perfect Entry V9']['atr_multiplier']), key='PE_ATR_MULTI', size=(10,1))]
            ], expand_x=True)],
            
            [sg.Frame('Baskı Eşikleri', [
                [sg.Text('Alım Baskısı Eşiği:', size=(20,1)), 
                 sg.InputText(str(self.defaults['Perfect Entry V9']['buying_pressure_threshold']), key='PE_BUY_THRESHOLD', size=(10,1))],
                [sg.Text('Satım Baskısı Eşiği:', size=(20,1)), 
                 sg.InputText(str(self.defaults['Perfect Entry V9']['selling_pressure_threshold']), key='PE_SELL_THRESHOLD', size=(10,1))]
            ], expand_x=True)],
            
            [sg.Frame('Trend Parametreleri', [
                [sg.Text('Trend Gücü Eşiği:', size=(20,1)), 
                 sg.InputText(str(self.defaults['Perfect Entry V9']['trend_strength_threshold']), key='PE_TREND_THRESHOLD', size=(10,1))],
                [sg.Text('Trend Yumuşatma:', size=(20,1)), 
                 sg.InputText(str(self.defaults['Perfect Entry V9']['trend_smoothing']), key='PE_TREND_SMOOTH', size=(10,1))],
                [sg.Text('DI Uzunluğu:', size=(20,1)), 
                 sg.InputText(str(self.defaults['Perfect Entry V9']['di_length']), key='PE_DI_LENGTH', size=(10,1))]
            ], expand_x=True)]
        ]
        
        # Ana layout
        layout = [
            [sg.Text('Strateji Ayarları', font=('Helvetica', 16, 'bold'), expand_x=True, justification='center')],
            [sg.HSeparator()],
            
            [sg.TabGroup([
                [sg.Tab('RSI Bands', rsi_tab, key='RSI_TAB')],
                [sg.Tab('Perfect Entry V9', perfect_entry_tab, key='PE_TAB')]
            ], key='STRATEGY_TABS', expand_x=True, enable_events=True)],
            
            [sg.HSeparator()],
            
            [sg.Frame('Önceden Tanımlı Ayarlar', [
                [sg.Button('Agresif', key='PRESET_AGGRESSIVE', size=(10,1)),
                 sg.Button('Orta', key='PRESET_MODERATE', size=(10,1)),
                 sg.Button('Konservatif', key='PRESET_CONSERVATIVE', size=(10,1))],
                [sg.Button('Varsayılan Ayarları Geri Yükle', key='RESET_DEFAULTS', size=(25,1), button_color=('white', '#f39c12'))]
            ], expand_x=True)],
            
            [sg.Frame('Strateji Testleri', [
                [sg.Button('Backtest Çalıştır', key='BACKTEST', size=(15,1)),
                 sg.Text('', key='BACKTEST_STATUS', size=(30,1), text_color='yellow')],
                [sg.Text('Timeframe:'), 
                 sg.Combo(['1m', '5m', '15m', '30m', '1h', '4h', '1d'], default_value='1h', key='BACKTEST_TF', readonly=True),
                 sg.Text('Tarih Aralığı:'),
                 sg.InputText('7', key='BACKTEST_DAYS', size=(5,1)), sg.Text('gün')]
            ], expand_x=True)],
            
            [sg.HSeparator()],
            
            [sg.Button('Kaydet', key='SAVE', size=(10,1), button_color=('white', 'green')),
             sg.Button('İptal', key='CANCEL', size=(10,1), button_color=('white', 'red')),
             sg.Push(),
             sg.Button('Test Et', key='TEST_STRATEGY', size=(10,1), button_color=('white', 'blue')),
             sg.Button('Optimizasyon', key='OPTIMIZE', size=(12,1), button_color=('white', 'purple'))]
        ]
        
        self.window = sg.Window('Strateji Ayarları', layout, size=(800, 700), modal=True, finalize=True)
        
        self.load_current_settings()
        return self.window
    
    def load_current_settings(self):
        """Mevcut ayarları yükle"""
        try:
            # RSI Bands ayarları
            rsi_settings = self.app.get_strategy_settings('RSI Bands')
            if rsi_settings:
                self.window['RSI_LENGTH'].update(rsi_settings.get('rsi_length', 25))
                self.window['RSI_OVERBOUGHT'].update(rsi_settings.get('rsi_overbought', 70))
                self.window['RSI_OVERSOLD'].update(rsi_settings.get('rsi_oversold', 30))
                self.window['RSI_MIN_VOL'].update(rsi_settings.get('min_volatility', 0.001))
                self.window['RSI_MAX_VOL'].update(rsi_settings.get('max_volatility', 0.1))
                self.window['RSI_MIN_VOL_RATIO'].update(rsi_settings.get('min_volume_ratio', 0.5))
                
                trading_hours = rsi_settings.get('trading_hours', {'start': 0, 'end': 24})
                self.window['RSI_TRADING_START'].update(trading_hours.get('start', 0))
                self.window['RSI_TRADING_END'].update(trading_hours.get('end', 24))
            
            # Perfect Entry ayarları
            pe_settings = self.app.get_strategy_settings('Perfect Entry V9')
            if pe_settings:
                self.window['PE_SIGNAL_PERIOD'].update(pe_settings.get('signal_period', 5))
                self.window['PE_LONG_PERIOD'].update(pe_settings.get('long_period', 27))
                self.window['PE_ATR_LENGTH'].update(pe_settings.get('atr_length', 14))
                self.window['PE_ATR_MULTI'].update(pe_settings.get('atr_multiplier', 2))
                self.window['PE_BUY_THRESHOLD'].update(pe_settings.get('buying_pressure_threshold', 0.2))
                self.window['PE_SELL_THRESHOLD'].update(pe_settings.get('selling_pressure_threshold', -0.2))
                self.window['PE_TREND_THRESHOLD'].update(pe_settings.get('trend_strength_threshold', 0))
                self.window['PE_TREND_SMOOTH'].update(pe_settings.get('trend_smoothing', 14))
                self.window['PE_DI_LENGTH'].update(pe_settings.get('di_length', 14))
                
        except Exception as e:
            ErrorDialog.show("Hata", f"Ayarlar yüklenirken hata: {str(e)}")
    
    def apply_preset(self, preset_type: str):
        """Önceden tanımlı ayarları uygula"""
        presets = {
            'aggressive': {
                'RSI Bands': {
                    'rsi_length': 14,
                    'rsi_overbought': 75,
                    'rsi_oversold': 25,
                    'min_volatility': 0.005,
                    'max_volatility': 0.2
                },
                'Perfect Entry V9': {
                    'signal_period': 3,
                    'buying_pressure_threshold': 0.15,
                    'selling_pressure_threshold': -0.15,
                    'trend_strength_threshold': -5
                }
            },
            'moderate': {
                'RSI Bands': {
                    'rsi_length': 25,
                    'rsi_overbought': 70,
                    'rsi_oversold': 30,
                    'min_volatility': 0.001,
                    'max_volatility': 0.1
                },
                'Perfect Entry V9': {
                    'signal_period': 5,
                    'buying_pressure_threshold': 0.2,
                    'selling_pressure_threshold': -0.2,
                    'trend_strength_threshold': 0
                }
            },
            'conservative': {
                'RSI Bands': {
                    'rsi_length': 50,
                    'rsi_overbought': 65,
                    'rsi_oversold': 35,
                    'min_volatility': 0.0005,
                    'max_volatility': 0.05
                },
                'Perfect Entry V9': {
                    'signal_period': 10,
                    'buying_pressure_threshold': 0.3,
                    'selling_pressure_threshold': -0.3,
                    'trend_strength_threshold': 5
                }
            }
        }
        
        if preset_type in presets:
            # RSI Bands ayarları
            rsi_preset = presets[preset_type]['RSI Bands']
            self.window['RSI_LENGTH'].update(rsi_preset.get('rsi_length', 25))
            self.window['RSI_OVERBOUGHT'].update(rsi_preset.get('rsi_overbought', 70))
            self.window['RSI_OVERSOLD'].update(rsi_preset.get('rsi_oversold', 30))
            self.window['RSI_MIN_VOL'].update(rsi_preset.get('min_volatility', 0.001))
            self.window['RSI_MAX_VOL'].update(rsi_preset.get('max_volatility', 0.1))
            
            # Perfect Entry ayarları
            pe_preset = presets[preset_type]['Perfect Entry V9']
            self.window['PE_SIGNAL_PERIOD'].update(pe_preset.get('signal_period', 5))
            self.window['PE_BUY_THRESHOLD'].update(pe_preset.get('buying_pressure_threshold', 0.2))
            self.window['PE_SELL_THRESHOLD'].update(pe_preset.get('selling_pressure_threshold', -0.2))
            self.window['PE_TREND_THRESHOLD'].update(pe_preset.get('trend_strength_threshold', 0))
    
    def reset_to_defaults(self):
        """Varsayılan ayarlara dön"""
        if ConfirmDialog.show("Varsayılan Ayarlar", "Tüm ayarları varsayılan değerlere geri yüklemek istediğinize emin misiniz?"):
            # RSI Bands varsayılan ayarları
            for key, value in self.defaults['RSI Bands'].items():
                if key == 'trading_hours':
                    self.window['RSI_TRADING_START'].update(value['start'])
                    self.window['RSI_TRADING_END'].update(value['end'])
                elif key == 'rsi_length':
                    self.window['RSI_LENGTH'].update(value)
                elif key == 'rsi_overbought':
                    self.window['RSI_OVERBOUGHT'].update(value)
                elif key == 'rsi_oversold':
                    self.window['RSI_OVERSOLD'].update(value)
                elif key == 'min_volatility':
                    self.window['RSI_MIN_VOL'].update(value)
                elif key == 'max_volatility':
                    self.window['RSI_MAX_VOL'].update(value)
                elif key == 'min_volume_ratio':
                    self.window['RSI_MIN_VOL_RATIO'].update(value)
            
            # Perfect Entry varsayılan ayarları
            for key, value in self.defaults['Perfect Entry V9'].items():
                if key == 'signal_period':
                    self.window['PE_SIGNAL_PERIOD'].update(value)
                elif key == 'long_period':
                    self.window['PE_LONG_PERIOD'].update(value)
                elif key == 'atr_length':
                    self.window['PE_ATR_LENGTH'].update(value)
                elif key == 'atr_multiplier':
                    self.window['PE_ATR_MULTI'].update(value)
                elif key == 'buying_pressure_threshold':
                    self.window['PE_BUY_THRESHOLD'].update(value)
                elif key == 'selling_pressure_threshold':
                    self.window['PE_SELL_THRESHOLD'].update(value)
                elif key == 'trend_strength_threshold':
                    self.window['PE_TREND_THRESHOLD'].update(value)
                elif key == 'trend_smoothing':
                    self.window['PE_TREND_SMOOTH'].update(value)
                elif key == 'di_length':
                    self.window['PE_DI_LENGTH'].update(value)
    
    def save_settings(self):
        """Ayarları kaydet"""
        try:
            # RSI Bands ayarlarını topla
            rsi_settings = {
                'rsi_length': int(self.window['RSI_LENGTH'].get()),
                'rsi_overbought': int(self.window['RSI_OVERBOUGHT'].get()),
                'rsi_oversold': int(self.window['RSI_OVERSOLD'].get()),
                'trading_hours': {
                    'start': int(self.window['RSI_TRADING_START'].get()),
                    'end': int(self.window['RSI_TRADING_END'].get())
                },
                'min_volatility': float(self.window['RSI_MIN_VOL'].get()),
                'max_volatility': float(self.window['RSI_MAX_VOL'].get()),
                'min_volume_ratio': float(self.window['RSI_MIN_VOL_RATIO'].get())
            }
            
            # Perfect Entry ayarlarını topla
            pe_settings = {
                'signal_period': int(self.window['PE_SIGNAL_PERIOD'].get()),
                'long_period': int(self.window['PE_LONG_PERIOD'].get()),
                'buying_pressure_threshold': float(self.window['PE_BUY_THRESHOLD'].get()),
                'selling_pressure_threshold': float(self.window['PE_SELL_THRESHOLD'].get()),
                'trend_strength_threshold': float(self.window['PE_TREND_THRESHOLD'].get()),
                'trend_smoothing': int(self.window['PE_TREND_SMOOTH'].get()),
                'atr_multiplier': float(self.window['PE_ATR_MULTI'].get()),
                'atr_length': int(self.window['PE_ATR_LENGTH'].get()),
                'di_length': int(self.window['PE_DI_LENGTH'].get())
            }
            
            # Ayarları uygulamaya kaydet
            self.app.set_strategy_settings('RSI Bands', rsi_settings)
            self.app.set_strategy_settings('Perfect Entry V9', pe_settings)
            
            # Konfigürasyonu dosyaya kaydet
            self.app.save_config()
            
            sg.popup("Başarılı", "Strateji ayarları kaydedildi!", keep_on_top=True)
            
        except ValueError as e:
            ErrorDialog.show("Geçersiz Değer", "Lütfen tüm sayısal alanlara geçerli değerler girin.")
        except Exception as e:
            ErrorDialog.show("Hata", f"Ayarlar kaydedilirken hata: {str(e)}")
    
    def run_backtest(self):
        """Strateji backtest'ini çalıştır"""
        try:
            timeframe = self.window['BACKTEST_TF'].get()
            days = int(self.window['BACKTEST_DAYS'].get())
            
            self.window['BACKTEST_STATUS'].update("Backtest çalışıyor...", text_color='yellow')
            self.window.refresh()
            
            # Backtest'i çalıştır
            results = self.app.run_strategy_backtest(self.current_strategy, timeframe, days)
            
            if results:
                # Sonuçları göster
                performance = results.get('performance', {})
                total_return = results.get('total_return', 0)
                
                result_text = f"""
Strateji: {self.current_strategy}
Timeframe: {timeframe}
Tarih Aralığı: Son {days} gün

Sonuçlar:
Toplam İşlem: {performance.get('total_trades', 0)}
Kazanan İşlem: {performance.get('successful_trades', 0)}
Kazanma Oranı: {performance.get('win_rate', 0) * 100:.1f}%
Toplam Getiri: {total_return:.2f}%
Sharpe Oranı: {performance.get('sharpe_ratio', 0):.2f}
Max Drawdown: {performance.get('max_drawdown', 0):.2f}%
                """
                
                sg.popup_scrolled(result_text, title="Backtest Sonuçları", size=(50, 20), keep_on_top=True)
                self.window['BACKTEST_STATUS'].update("Backtest tamamlandı", text_color='green')
            else:
                self.window['BACKTEST_STATUS'].update("Backtest başarısız", text_color='red')
                
        except ValueError:
            ErrorDialog.show("Geçersiz Değer", "Gün sayısı için geçerli bir sayı girin.")
        except Exception as e:
            ErrorDialog.show("Hata", f"Backtest çalıştırılırken hata: {str(e)}")
            self.window['BACKTEST_STATUS'].update("Backtest hatası", text_color='red')
    
    def test_strategy(self):
        """Stratejiyi test et"""
        # Ayarları geçici olarak uygula ve test sinyali üret
        self.save_settings()
        test_result = self.app.test_strategy(self.current_strategy)
        
        if test_result:
            sg.popup("Test Sonucu", f"Strateji test edildi. Sonuç: {test_result}", keep_on_top=True)
        else:
            sg.popup("Test Sonucu", "Strateji testi başarısız oldu.", keep_on_top=True)
    
    def run_optimization(self):
        """Strateji optimizasyonunu çalıştır"""
        if ConfirmDialog.show("Optimizasyon", "Bu işlem birkaç dakika sürebilir. Devam etmek istiyor musunuz?"):
            self.window.hide()
            
            optimization_result = self.app.optimize_strategy(self.current_strategy)
            
            if optimization_result:
                best_params = optimization_result.get('best_parameters', {})
                performance = optimization_result.get('performance', {})
                
                result_text = f"""
Strateji Optimizasyonu: {self.current_strategy}

En İyi Parametreler:
{best_params}

Performans:
Sharpe Oranı: {performance.get('sharpe_ratio', 0):.2f}
Kazanma Oranı: {performance.get('win_rate', 0) * 100:.1f}%
Total Getiri: {performance.get('total_return', 0):.2f}%
                """
                
                if ConfirmDialog.show("Optimizasyon Sonucu", f"{result_text}\n\nBu parametreleri uygulamak ister misiniz?"):
                    self.app.apply_optimization_results(self.current_strategy, best_params)
                    self.load_current_settings()
            
            self.window.un_hide()
    
    def open(self):
        """Pencereyi aç ve çalıştır"""
        window = self.create_window()
        
        while True:
            event, values = window.read()
            
            if event == sg.WINDOW_CLOSED or event == 'CANCEL':
                break
            
            elif event == 'SAVE':
                self.save_settings()
                break
            
            elif event == 'STRATEGY_TABS':
                # Aktif sekme değiştiğinde mevcut stratejiyi güncelle
                if values['STRATEGY_TABS'] == 'RSI_TAB':
                    self.current_strategy = 'RSI Bands'
                elif values['STRATEGY_TABS'] == 'PE_TAB':
                    self.current_strategy = 'Perfect Entry V9'
            
            elif event == 'PRESET_AGGRESSIVE':
                self.apply_preset('aggressive')
            
            elif event == 'PRESET_MODERATE':
                self.apply_preset('moderate')
            
            elif event == 'PRESET_CONSERVATIVE':
                self.apply_preset('conservative')
            
            elif event == 'RESET_DEFAULTS':
                self.reset_to_defaults()
            
            elif event == 'BACKTEST':
                self.run_backtest()
            
            elif event == 'TEST_STRATEGY':
                self.test_strategy()
            
            elif event == 'OPTIMIZE':
                self.run_optimization()
        
        window.close()
        self.window = None