import PySimpleGUI as sg
from ui.components.dialogs import ConfirmDialog, ErrorDialog
from ui.components.charts import ChartComponent

class PortfolioStatusWindow:
    """Portföy durumu penceresi"""
    
    def __init__(self, app):
        self.app = app
        self.window = None
    
    def open(self):
        """Pencereyi aç ve çalıştır"""
        layout = [
            [sg.Text('Portföy Durumu', font=('Helvetica', 16, 'bold'))],
            [sg.HSeparator()],
            
            [sg.Frame('Genel Durum', [
                [sg.Text('Toplam Değer:', size=(15,1)), sg.Text('$0.00', key='TOTAL_VALUE', size=(20,1))],
                [sg.Text('Günlük Değişim:', size=(15,1)), sg.Text('0.00%', key='DAILY_CHANGE', size=(20,1))],
                [sg.Text('Açık Pozisyonlar:', size=(15,1)), sg.Text('0', key='OPEN_POSITIONS', size=(20,1))]
            ], expand_x=True)],
            
            [sg.Frame('Varlık Dağılımı', [
                [sg.Table(values=[],
                          headings=['Varlık', 'Ağırlık', 'Değer', 'P/L', 'Durum'],
                          col_widths=[10, 8, 15, 10, 10],
                          num_rows=10,
                          key='ASSETS_TABLE')]
            ], expand_x=True)],
            
            [sg.Button('Yenile', key='REFRESH'), 
             sg.Button('Yeniden Dengele', key='REBALANCE'),
             sg.Button('Kapat', key='CLOSE')]
        ]
        
        self.window = sg.Window('Portföy Durumu', layout, size=(800, 600), modal=True)
        
        self.refresh_data()
        
        while True:
            event, values = self.window.read()
            
            if event == sg.WINDOW_CLOSED or event == 'CLOSE':
                break
            
            elif event == 'REFRESH':
                self.refresh_data()
            
            elif event == 'REBALANCE':
                self.rebalance_portfolio()
        
        self.window.close()
        self.window = None
    
    def refresh_data(self):
        """Portföy verilerini yenile"""
        try:
            # TODO: App'ten veri çek
            portfolio_data = self.app.get_portfolio_status()
            
            if portfolio_data:
                self.window['TOTAL_VALUE'].update(f"${portfolio_data.get('total_value', 0):.2f}")
                self.window['DAILY_CHANGE'].update(f"{portfolio_data.get('daily_change', 0):.2f}%")
                self.window['OPEN_POSITIONS'].update(str(portfolio_data.get('open_positions', 0)))
                
                # Assets tablosu
                assets_data = []
                for asset_name, asset_data in portfolio_data.get('assets', {}).items():
                    assets_data.append([
                        asset_name,
                        f"{asset_data.get('weight', 0):.1f}%",
                        f"${asset_data.get('value', 0):.2f}",
                        f"{asset_data.get('pnl', 0):.2f}%",
                        asset_data.get('status', 'Unknown')
                    ])
                
                self.window['ASSETS_TABLE'].update(values=assets_data)
                
        except Exception as e:
            ErrorDialog.show("Hata", f"Portföy verileri yüklenirken hata: {str(e)}")
    
    def rebalance_portfolio(self):
        """Portföyü yeniden dengele"""
        if ConfirmDialog.show("Dengeleme", "Portföyü yeniden dengelemek istediğinize emin misiniz?"):
            try:
                self.app.rebalance_portfolio()
                self.refresh_data()
                sg.popup("Başarılı", "Portföy yeniden dengelendi!", keep_on_top=True)
            except Exception as e:
                ErrorDialog.show("Hata", f"Dengeleme hatası: {str(e)}")