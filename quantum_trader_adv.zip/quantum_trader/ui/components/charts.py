# ui/components/charts.py
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import matplotlib.dates as mdates
import matplotlib.style as style
import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime, timedelta
import mplfinance as mpf
import sys


class ChartComponent:
    """Grafik bileşeni sınıfı"""
    
    def __init__(self, canvas):
        self.canvas = canvas
        self.figure = Figure(figsize=(12, 6), dpi=100)
        self.figure.subplots_adjust(left=0.05, right=0.95, top=0.95, bottom=0.05, hspace=0.3)
        
        self.fig_canvas = FigureCanvasTkAgg(self.figure, master=canvas)
        self.fig_canvas.draw()
        self.fig_canvas.get_tk_widget().pack(side='top', fill='both', expand=1)
        
        # Navigation toolbar
        self.toolbar = NavigationToolbar2Tk(self.fig_canvas, canvas)
        self.toolbar.update()
        self.fig_canvas.get_tk_widget().pack(side='top', fill='both', expand=1)
        
        # Dark theme
        style.use('dark_background')
        
        # Axes
        self.axes = None
        self.subplots = []
        
        self.setup_layout()
    
    def setup_layout(self):
        """Grafik layout'unu ayarla"""
        # Ana grafik (3/4) + gösterge grafikleri (1/4)
        gs = self.figure.add_gridspec(4, 1, hspace=0.2)
        
        # Ana mum grafik
        self.ax_main = self.figure.add_subplot(gs[0:3, 0])
        
        # Alt grafik - Volume ve göstergeler
        self.ax_volume = self.figure.add_subplot(gs[3, 0])
        
        self.figure.tight_layout()
        
        # Stil ayarları
        self.setup_styles()
    
    def setup_styles(self):
        """Grafik stillerini ayarla"""
        # Ana grafik
        self.ax_main.set_ylabel('Fiyat', color='white')
        self.ax_main.tick_params(colors='white')
        self.ax_main.grid(True, alpha=0.1, color='gray')
        
        # Volume grafik
        self.ax_volume.set_ylabel('Volume', color='white')
        self.ax_volume.tick_params(colors='white')
        self.ax_volume.grid(True, alpha=0.1, color='gray')
        
        # X axis tarih formatı
        self.ax_main.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        self.ax_main.xaxis.set_major_locator(mdates.HourLocator(interval=4))
        
        self.ax_volume.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        self.ax_volume.xaxis.set_major_locator(mdates.HourLocator(interval=4))
        
        # Rotate and align labels
        plt.setp(self.ax_main.xaxis.get_majorticklabels(), rotation=45, ha='right')
        plt.setp(self.ax_volume.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    def plot_candlestick(self, df: pd.DataFrame, indicators: Optional[Dict[str, np.ndarray]] = None):
        """Mum grafiğini çiz"""
        try:
            # Veriyi hazırla
            df = df.copy()
            if 'timestamp' in df.columns:
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                df.set_index('timestamp', inplace=True)
            
            # Mevcut grafikleri temizle
            self.clear_charts()
            
            # Mum grafiği çiz
            up_color = '#2ecc71'  # Yeşil
            down_color = '#e74c3c'  # Kırmızı
            
            for i in range(len(df)):
                candle = df.iloc[i]
                x = i
                
                open_price = candle['open']
                high_price = candle['high']
                low_price = candle['low']
                close_price = candle['close']
                
                color = up_color if close_price >= open_price else down_color
                
                # Fitil çiz
                self.ax_main.plot([x, x], [low_price, high_price], color=color, linewidth=1)
                
                # Gövde çiz
                self.ax_main.bar(x, 
                                close_price - open_price, 
                                bottom=open_price,
                                width=0.8,
                                color=color,
                                alpha=0.8)
            
            # Volume grafiği
            self.plot_volume(df)
            
            # Göstergeleri çiz
            if indicators:
                self.plot_indicators(indicators)
            
            # Grid ve labels
            self.ax_main.grid(True, alpha=0.1, color='gray')
            self.ax_main.set_xlim(-1, len(df))
            
            # X ticks
            ticks = list(range(0, len(df), max(1, len(df) // 10)))
            labels = [df.index[i].strftime('%H:%M') for i in ticks]
            self.ax_main.set_xticks(ticks)
            self.ax_main.set_xticklabels(labels, rotation=45)
            
            # Başlık
            latest = df.iloc[-1]
            self.ax_main.set_title(f"Fiyat: {latest['close']:.4f}", 
                                  color='white', 
                                  loc='right', 
                                  fontsize=12)
            
            self.fig_canvas.draw()
            
        except Exception as e:
            print(f"Chart error: {e}")
    
    def plot_volume(self, df: pd.DataFrame):
        """Volume grafiğini çiz"""
        try:
            volumes = df['volume'].values
            colors = ['#2ecc71' if df['close'].iloc[i] >= df['open'].iloc[i] else '#e74c3c' 
                     for i in range(len(df))]
            
            self.ax_volume.bar(range(len(df)), volumes, color=colors, alpha=0.5, width=0.8)
            self.ax_volume.set_ylim(0, max(volumes) * 1.2)
            
        except Exception as e:
            print(f"Volume chart error: {e}")
    
    def plot_indicators(self, indicators: Dict[str, Any]):
        """Göstergeleri çiz"""
        try:
            # RSI Bands
            if 'upper_band' in indicators and 'lower_band' in indicators:
                self.ax_main.plot(indicators['upper_band'], color='cyan', alpha=0.7, linewidth=1)
                self.ax_main.plot(indicators['lower_band'], color='cyan', alpha=0.7, linewidth=1)
                if 'midline' in indicators:
                    self.ax_main.plot(indicators['midline'], color='cyan', alpha=0.4, linewidth=1, linestyle='--')
            
            # RSI alt grafik
            if 'rsi' in indicators:
                self.ax_volume.clear()
                self.ax_volume.plot(indicators['rsi'], color='yellow', alpha=0.8, linewidth=2)
                self.ax_volume.axhline(y=70, color='red', alpha=0.5, linestyle='--')
                self.ax_volume.axhline(y=30, color='green', alpha=0.5, linestyle='--')
                self.ax_volume.set_ylim(0, 100)
                self.ax_volume.set_ylabel('RSI', color='white')
                self.ax_volume.grid(True, alpha=0.1, color='gray')
            
            # Alım/Satım sinyalleri
            if 'buy_signals' in indicators:
                buy_indices = np.where(indicators['buy_signals'])[0]
                if len(buy_indices) > 0:
                    buy_prices = indicators.get('prices', [0] * len(buy_indices))
                    self.ax_main.scatter(buy_indices, buy_prices, 
                                       color='lime', marker='^', s=100, alpha=0.9, label='BUY')
            
            if 'sell_signals' in indicators:
                sell_indices = np.where(indicators['sell_signals'])[0]
                if len(sell_indices) > 0:
                    sell_prices = indicators.get('prices', [0] * len(sell_indices))
                    self.ax_main.scatter(sell_indices, sell_prices, 
                                       color='red', marker='v', s=100, alpha=0.9, label='SELL')
            
            # Legend
            if 'buy_signals' in indicators or 'sell_signals' in indicators:
                self.ax_main.legend(loc='upper left', framealpha=0.1)
            
        except Exception as e:
            print(f"Indicator plotting error: {e}")
    
    def plot_portfolio_allocation(self, allocation: Dict[str, float]):
        """Portföy dağılımını pasta grafiği olarak çiz"""
        try:
            self.clear_charts()
            
            # Ana ve yan grafikler
            gs = self.figure.add_gridspec(2, 2, width_ratios=[2, 1], height_ratios=[2, 1])
            ax_pie = self.figure.add_subplot(gs[:, 0])
            ax_table = self.figure.add_subplot(gs[0, 1])
            ax_risk = self.figure.add_subplot(gs[1, 1])
            
            # Pasta grafiği
            values = list(allocation.values())
            labels = list(allocation.keys())
            colors = plt.cm.viridis(np.linspace(0, 1, len(labels)))
            
            wedges, texts, autotexts = ax_pie.pie(values, labels=labels, colors=colors, 
                                                 autopct=lambda pct: f'{pct:.1f}%', 
                                                 shadow=True, startangle=90)
            
            # İyileştirme: metin renkleri
            for text in texts:
                text.set_color('white')
            for autotext in autotexts:
                autotext.set_color('white')
                autotext.set_weight('bold')
            
            ax_pie.set_title('Portföy Dağılımı', color='white', size=16)
            
            # Tablo
            table_data = []
            for coin, allocation_pct in allocation.items():
                table_data.append([coin, f'{allocation_pct:.1f}%'])
            
            table = ax_table.table(cellText=table_data, 
                                  colLabels=['Asset', 'Allocation'],
                                  cellLoc='center',
                                  loc='center')
            
            table.auto_set_font_size(False)
            table.set_fontsize(10)
            table.scale(1.2, 1.5)
            
            for cell in table.get_celld().values():
                cell.set_edgecolor('gray')
                cell.set_facecolor('#2c3e50')
                cell.set_text_props(color='white')
            
            ax_table.axis('off')
            ax_table.set_title('Varlık Detayları', color='white', size=12)
            
            # Risk analizi
            risk_data = self.calculate_risk_metrics(allocation)
            risk_text = '\n'.join([f'{k}: {v:.2f}' for k, v in risk_data.items()])
            
            ax_risk.text(0.5, 0.5, risk_text, 
                        transform=ax_risk.transAxes,
                        ha='center', va='center',
                        color='white', fontsize=12,
                        bbox=dict(boxstyle='round', facecolor='#2c3e50', alpha=0.8))
            
            ax_risk.axis('off')
            ax_risk.set_title('Risk Metrikleri', color='white', size=12)
            
            self.figure.tight_layout()
            self.fig_canvas.draw()
            
        except Exception as e:
            print(f"Portfolio allocation chart error: {e}")
    
    def calculate_risk_metrics(self, allocation: Dict[str, float]) -> Dict[str, float]:
        """Risk metriklerini hesapla"""
        try:
            # Dummy risk metrics for demonstration
            metrics = {
                'Volatility': sum(allocation.values()) * 0.02,
                'Sharpe Ratio': 1.5,
                'Max Drawdown': 0.15,
                'VaR (95%)': 0.10
            }
            return metrics
        except Exception as e:
            print(f"Risk metrics calculation error: {e}")
            return {}
    
    def plot_performance_chart(self, performance_data: pd.DataFrame):
        """Performans grafiğini çiz"""
        try:
            self.clear_charts()
            
            # Layout
            gs = self.figure.add_gridspec(3, 1, height_ratios=[2, 1, 1], hspace=0.3)
            ax_equity = self.figure.add_subplot(gs[0])
            ax_returns = self.figure.add_subplot(gs[1])
            ax_metrics = self.figure.add_subplot(gs[2])
            
            # Equity curve
            ax_equity.plot(performance_data['timestamp'], performance_data['equity'], 
                          color='#2ecc71', linewidth=2, label='Portfolio Value')
            ax_equity.fill_between(performance_data['timestamp'], performance_data['equity'], 
                                  alpha=0.1, color='#2ecc71')
            ax_equity.set_title('Portföy Performansı', color='white', size=14)
            ax_equity.set_ylabel('Değer (USDT)', color='white')
            ax_equity.grid(True, alpha=0.1, color='gray')
            ax_equity.legend(loc='upper left')
            
            # Returns distribution
            returns = performance_data['daily_returns'].values
            ax_returns.hist(returns, bins=30, color='#3498db', alpha=0.7, edgecolor='white')
            ax_returns.axvline(np.mean(returns), color='red', linestyle='--', label=f'Mean: {np.mean(returns):.2%}')
            ax_returns.set_title('Günlük Getiri Dağılımı', color='white', size=12)
            ax_returns.set_xlabel('Daily Returns (%)', color='white')
            ax_returns.legend()
            
            # Performance metrics
            metrics_text = f"""
            Total Return: {((performance_data['equity'].iloc[-1] / performance_data['equity'].iloc[0]) - 1) * 100:.2f}%
            Win Rate: {(returns > 0).mean() * 100:.1f}%
            Sharpe Ratio: {np.mean(returns) / np.std(returns):.2f}
            Max Drawdown: {((performance_data['equity'].cummax() - performance_data['equity']) / performance_data['equity'].cummax()).max() * 100:.2f}%
            """
            
            ax_metrics.text(0.5, 0.5, metrics_text,
                           transform=ax_metrics.transAxes,
                           ha='center', va='center',
                           color='white', fontsize=12,
                           bbox=dict(boxstyle='round', facecolor='#2c3e50', alpha=0.8))
            ax_metrics.axis('off')
            
            plt.tight_layout()
            self.fig_canvas.draw()
            
        except Exception as e:
            print(f"Performance chart error: {e}")
    
    def clear_charts(self):
        """Mevcut grafikleri temizle"""
        self.figure.clear()
        self.setup_layout()
        self.setup_styles()
    
    def save_chart(self, filename: str):
        """Grafiği kaydet"""
        try:
            self.figure.savefig(filename, dpi=300, bbox_inches='tight', 
                               facecolor='#1a1a1a', edgecolor='none')
        except Exception as e:
            print(f"Chart save error: {e}")


class MiniChart:
    """Küçük gömülü grafik bileşeni"""
    
    def __init__(self, parent_frame, size=(300, 150)):
        self.frame = parent_frame
        self.figure = Figure(figsize=(size[0]/100, size[1]/100), dpi=100)
        self.ax = self.figure.add_subplot(111)
        
        self.canvas = FigureCanvasTkAgg(self.figure, master=parent_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(side='top', fill='both', expand=1)
        
        # Style
        style.use('dark_background')
        self.ax.set_facecolor('#2c3e50')
        self.figure.patch.set_facecolor('#2c3e50')
        
        self.ax.tick_params(colors='white', labelsize=8)
        self.ax.spines['bottom'].set_color('gray')
        self.ax.spines['top'].set_color('gray')
        self.ax.spines['left'].set_color('gray')
        self.ax.spines['right'].set_color('gray')
    
    def plot_line(self, data: List[float], color: str = '#3498db', label: str = ''):
        """Basit çizgi grafik çiz"""
        self.ax.clear()
        self.ax.plot(data, color=color, linewidth=2, label=label)
        
        if label:
            self.ax.legend(fontsize=8, loc='upper left')
        
        self.ax.grid(True, alpha=0.1, color='gray')
        self.canvas.draw()
    
    def plot_bar(self, data: List[float], colors: List[str] = None):
        """Bar grafiği çiz"""
        self.ax.clear()
        
        if colors is None:
            colors = ['#3498db'] * len(data)
        
        self.ax.bar(range(len(data)), data, color=colors, alpha=0.7)
        self.ax.grid(True, alpha=0.1, color='gray', axis='y')
        self.canvas.draw()