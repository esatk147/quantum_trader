# ui/components/dialogs.py
import PySimpleGUI as sg
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
import os


class BaseDialog:
    """Temel dialog sınıfı"""
    
    def __init__(self, title: str, size: Tuple[int, int] = (400, 300)):
        self.title = title
        self.size = size
        self.window = None
        self.result = None
        
        # Tema
        sg.theme('DarkBlue15')
    
    def create_layout(self) -> List[List[sg.Element]]:
        """Layout oluştur - alt sınıflar override edecek"""
        return [[sg.Text('Base Dialog')], [sg.Button('OK'), sg.Button('Cancel')]]
    
    def show(self) -> Any:
        """Dialog'u göster"""
        layout = self.create_layout()
        self.window = sg.Window(self.title, layout, modal=True, size=self.size, finalize=True)
        
        while True:
            event, values = self.window.read()
            
            if event == sg.WINDOW_CLOSED or event == 'Cancel':
                self.result = None
                break
            
            elif event == 'OK':
                self.result = self.process_values(values)
                break
            
            else:
                self.handle_event(event, values)
        
        self.window.close()
        return self.result
    
    def process_values(self, values: Dict[str, Any]) -> Any:
        """Değerleri işle - alt sınıflar override edecek"""
        return values
    
    def handle_event(self, event: str, values: Dict[str, Any]):
        """Event işleme - alt sınıflar override edecek"""
        pass


class ConfirmDialog(BaseDialog):
    """Onay dialog'u"""
    
    def __init__(self, title: str, message: str):
        super().__init__(title, (300, 150))
        self.message = message
    
    def create_layout(self):
        return [
            [sg.Text('⚠️', font=('Helvetica', 20), text_color='yellow'), 
             sg.Text(self.message, font=('Helvetica', 12))],
            [sg.Button('Evet', key='YES', button_color=('white', 'green')), 
             sg.Button('Hayır', key='NO', button_color=('white', 'red'))]
        ]
    
    def show(self) -> bool:
        """Onay dialog'unu göster"""
        layout = self.create_layout()
        self.window = sg.Window(self.title, layout, modal=True, size=self.size, finalize=True)
        
        while True:
            event, _ = self.window.read()
            
            if event == sg.WINDOW_CLOSED or event == 'NO':
                result = False
                break
            
            elif event == 'YES':
                result = True
                break
        
        self.window.close()
        return result
    
    @staticmethod
    def ask(title: str, message: str) -> bool:
        """Statik metod için"""
        dialog = ConfirmDialog(title, message)
        return dialog.show()


class ErrorDialog(BaseDialog):
    """Hata dialog'u"""
    
    def __init__(self, title: str, error_message: str):
        super().__init__(title, (400, 200))
        self.error_message = error_message
    
    def create_layout(self):
        return [
            [sg.Text('❌', font=('Helvetica', 20), text_color='red'), 
             sg.Text('Hata:', font=('Helvetica', 12, 'bold'), text_color='red')],
            [sg.Multiline(self.error_message, size=(40, 5), disabled=True, 
                         font=('Courier', 10), background_color='#1a1a1a', text_color='white')],
            [sg.Button('Tamam', key='OK', button_color=('white', 'blue'))]
        ]
    
    @staticmethod
    def show(title: str, error_message: str):
        """Statik metod için - hata dialog'u göstermek için"""
        dialog = ErrorDialog(title, error_message)
        return dialog.show()


class InfoDialog(BaseDialog):
    """Bilgi dialog'u"""
    
    def __init__(self, title: str, message: str):
        super().__init__(title, (400, 200))
        self.message = message
    
    def create_layout(self):
        return [
            [sg.Text('ℹ️', font=('Helvetica', 20), text_color='cyan'), 
             sg.Text('Bilgi:', font=('Helvetica', 12, 'bold'), text_color='cyan')],
            [sg.Text(self.message, font=('Helvetica', 12))],
            [sg.Button('Tamam', key='OK', button_color=('white', 'blue'))]
        ]
    
    @staticmethod
    def show(title: str, message: str):
        """Statik metod için"""
        dialog = InfoDialog(title, message)
        return dialog.show()


class InputDialog(BaseDialog):
    """Giriş dialog'u"""
    
    def __init__(self, title: str, prompt: str, default_value: str = ""):
        super().__init__(title, (300, 150))
        self.prompt = prompt
        self.default_value = default_value
    
    def create_layout(self):
        return [
            [sg.Text(self.prompt, font=('Helvetica', 12))],
            [sg.InputText(self.default_value, key='INPUT', size=(30, 1))],
            [sg.Button('Tamam', key='OK'), sg.Button('İptal', key='CANCEL')]
        ]
    
    def process_values(self, values) -> Optional[str]:
        return values['INPUT'] if values['INPUT'] else None
    
    @staticmethod
    def ask_input(title: str, prompt: str, default_value: str = "") -> Optional[str]:
        """Statik metod için"""
        dialog = InputDialog(title, prompt, default_value)
        return dialog.show()


class FileSelectDialog(BaseDialog):
    """Dosya seçme dialog'u"""
    
    def __init__(self, title: str, file_types: List[Tuple[str, str]], 
                 initial_folder: str = '', save_as: bool = False):
        super().__init__(title, (500, 100))
        self.file_types = file_types
        self.initial_folder = initial_folder
        self.save_as = save_as
    
    def create_layout(self):
        return [
            [sg.Text('Dosya:', font=('Helvetica', 12))],
            [sg.InputText(key='FILE', disabled=True, size=(40, 1)), 
             sg.FileSaveAs('Seç', key='BROWSE') if self.save_as else sg.FileBrowse('Seç', key='BROWSE')],
            [sg.Button('Tamam', key='OK'), sg.Button('İptal', key='CANCEL')]
        ]
    
    def handle_event(self, event, values):
        if event == 'BROWSE':
            self.window['FILE'].update(values['BROWSE'])
    
    def process_values(self, values) -> Optional[str]:
        return values['FILE'] if values['FILE'] else None
    
    @staticmethod
    def browse_file(title: str, file_types: List[Tuple[str, str]], 
                    initial_folder: str = '') -> Optional[str]:
        """Dosya açma dialog'u"""
        dialog = FileSelectDialog(title, file_types, initial_folder, save_as=False)
        return dialog.show()
    
    @staticmethod
    def save_file(title: str, file_types: List[Tuple[str, str]], 
                  initial_folder: str = '') -> Optional[str]:
        """Dosya kaydetme dialog'u"""
        dialog = FileSelectDialog(title, file_types, initial_folder, save_as=True)
        return dialog.show()


class ProgressDialog(BaseDialog):
    """İlerleme çubuğu dialog'u"""
    
    def __init__(self, title: str, message: str, max_value: int = 100):
        super().__init__(title, (400, 150))
        self.message = message
        self.max_value = max_value
        self.cancelled = False
    
    def create_layout(self):
        return [
            [sg.Text(self.message, font=('Helvetica', 12))],
            [sg.ProgressBar(self.max_value, orientation='h', size=(30, 20), key='PROGRESS')],
            [sg.Text('', key='STATUS', size=(40, 1), justification='center')],
            [sg.Button('İptal', key='CANCEL', button_color=('white', 'red'))]
        ]
    
    def update_progress(self, value: int, status: str = ''):
        """İlerlemeyi güncelle"""
        if self.window:
            self.window['PROGRESS'].update(value)
            self.window['STATUS'].update(status)
            
            event, _ = self.window.read(timeout=0)
            if event == 'CANCEL' or event == sg.WINDOW_CLOSED:
                self.cancelled = True
                return False
            
            return True
    
    @staticmethod
    def run_with_progress(title: str, message: str, max_value: int, 
                          task_func, *args, **kwargs) -> Any:
        """İlerleme çubuğu ile görevi çalıştır"""
        dialog = ProgressDialog(title, message, max_value)
        layout = dialog.create_layout()
        dialog.window = sg.Window(dialog.title, layout, modal=True, 
                                 size=dialog.size, finalize=True)
        
        result = None
        try:
            # Task'ı çalıştır ve progress güncellemeleri için callback ver
            update_callback = lambda value, status: dialog.update_progress(value, status)
            result = task_func(update_callback, *args, **kwargs)
        finally:
            dialog.window.close()
        
        return result


class MultiInputDialog(BaseDialog):
    """Çoklu giriş dialog'u"""
    
    def __init__(self, title: str, inputs: List[Dict[str, Any]]):
        super().__init__(title, (400, 50 + 50 * len(inputs)))
        self.inputs = inputs
    
    def create_layout(self):
        layout = []
        
        for input_def in self.inputs:
            label = input_def.get('label', '')
            key = input_def.get('key', '')
            input_type = input_def.get('type', 'text')
            default = input_def.get('default', '')
            
            if input_type == 'text':
                layout.append([sg.Text(label, size=(15, 1)), 
                              sg.InputText(default, key=key, size=(20, 1))])
            elif input_type == 'number':
                layout.append([sg.Text(label, size=(15, 1)), 
                              sg.InputText(str(default), key=key, size=(20, 1))])
            elif input_type == 'checkbox':
                layout.append([sg.Checkbox(label, default=default, key=key)])
            elif input_type == 'combo':
                values = input_def.get('values', [])
                layout.append([sg.Text(label, size=(15, 1)), 
                              sg.Combo(values, default_value=default, key=key, readonly=True)])
        
        layout.append([sg.Button('Tamam', key='OK'), sg.Button('İptal', key='CANCEL')])
        
        return layout
    
    def process_values(self, values) -> Dict[str, Any]:
        """Girdi değerlerini işle"""
        result = {}
        for input_def in self.inputs:
            key = input_def.get('key', '')
            if key in values:
                value = values[key]
                # Sayısal değerleri dönüştür
                if input_def.get('type') == 'number':
                    try:
                        value = float(value)
                    except ValueError:
                        value = input_def.get('default', 0)
                result[key] = value
        return result
    
    @staticmethod
    def ask_multiple(title: str, inputs: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Çoklu giriş dialog'unu göster"""
        dialog = MultiInputDialog(title, inputs)
        return dialog.show()


class TableDialog(BaseDialog):
    """Tablo dialog'u"""
    
    def __init__(self, title: str, data: List[List[Any]], 
                 headers: List[str], size: Tuple[int, int] = (600, 400)):
        super().__init__(title, size)
        self.data = data
        self.headers = headers
    
    def create_layout(self):
        return [
            [sg.Table(values=self.data,
                     headings=self.headers,
                     max_col_width=25,
                     auto_size_columns=True,
                     display_row_numbers=True,
                     justification='right',
                     num_rows=min(len(self.data), 15),
                     key='TABLE')],
            [sg.Button('Tamam', key='OK')]
        ]
    
    @staticmethod
    def show_table(title: str, data: List[List[Any]], headers: List[str]):
        """Tablo dialog'unu göster"""
        dialog = TableDialog(title, data, headers)
        return dialog.show()


# Yardımcı fonksiyonlar

def show_warning(title: str, message: str):
    """Uyarı mesajı göster"""
    layout = [
        [sg.Text('⚠️', font=('Helvetica', 20), text_color='orange'),
         sg.Text(message, font=('Helvetica', 12))],
        [sg.Button('Tamam', key='OK', button_color=('white', 'orange'))]
    ]
    
    window = sg.Window(title, layout, modal=True, size=(400, 150), finalize=True)
    window.read()
    window.close()


def show_success(title: str, message: str):
    """Başarı mesajı göster"""
    layout = [
        [sg.Text('✅', font=('Helvetica', 20), text_color='green'),
         sg.Text(message, font=('Helvetica', 12))],
        [sg.Button('Tamam', key='OK', button_color=('white', 'green'))]
    ]
    
    window = sg.Window(title, layout, modal=True, size=(400, 150), finalize=True)
    window.read()
    window.close()


def quick_popup(message: str, auto_close_duration: int = 3):
    """Kısa ömürlü popup göster"""
    layout = [
        [sg.Text(message, font=('Helvetica', 12), justification='center')],
        [sg.Text('', size=(30, 1), justification='center', key='COUNTDOWN')]
    ]
    
    window = sg.Window('Bilgilendirme', layout, modal=True, size=(300, 100), 
                      finalize=True, no_titlebar=True, keep_on_top=True)
    
    for i in range(auto_close_duration, 0, -1):
        window['COUNTDOWN'].update(f'{i} saniye sonra kapanacak')
        event, _ = window.read(timeout=1000)
        if event == sg.WINDOW_CLOSED:
            break
    
    window.close()