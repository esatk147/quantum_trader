# ml/predictor.py
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
import joblib
import json
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
import asyncio
from core.logger import logger
from core.database import db_manager
from core.config import config


class FeatureEngineer:
    """Feature engineering sınıfı"""
    
    @staticmethod
    def create_technical_features(df: pd.DataFrame) -> pd.DataFrame:
        """Teknik gösterge features'ları oluştur"""
        df = df.copy()
        
        # Trend features
        df['price_change'] = df['close'].pct_change()
        df['price_volatility'] = df['price_change'].rolling(20).std()
        df['trend_strength'] = df['close'].rolling(50).mean() - df['close'].rolling(200).mean()
        
        # Momentum features
        df['rsi_momentum'] = df['rsi_4h'].diff()
        df['rsi_divergence'] = df['rsi_4h'] - df['rsi_15m']
        df['volume_surge'] = df['volume'] / df['volume'].rolling(20).mean()
        
        # Seasonality features
        df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
        df['day_of_week'] = pd.to_datetime(df['timestamp']).dt.dayofweek
        df['is_weekend'] = df['day_of_week'].isin([5, 6]).astype(int)
        
        # Lag features
        for i in range(1, 6):
            df[f'price_lag_{i}'] = df['close'].shift(i)
            df[f'volume_lag_{i}'] = df['volume'].shift(i)
            df[f'rsi_lag_{i}'] = df['rsi_4h'].shift(i)
        
        # Market context features
        df['btc_price_change'] = df['btc_price'].pct_change()
        df['btc_dominance_change'] = df['btc_dominance'].diff()
        df['funding_rate_change'] = df['funding_rate'].diff()
        
        return df.dropna()
    
    @staticmethod
    def create_interaction_features(df: pd.DataFrame) -> pd.DataFrame:
        """Interaction features oluştur"""
        df = df.copy()
        
        # Price-Volume interactions
        df['price_volume_ratio'] = df['close'] / df['volume']
        df['price_volume_change'] = df['price_change'] * df['volume_surge']
        
        # RSI-Trend interactions
        df['rsi_trend'] = df['rsi_4h'] * df['trend_strength']
        df['rsi_volume'] = df['rsi_4h'] * df['volume_surge']
        
        # Market condition interactions
        df['market_risk'] = df['btc_price_change'] * df['price_volatility']
        df['funding_sentiment'] = df['funding_rate'] * df['volume']
        
        return df


class MLPredictor:
    """ML Tahmin Sistemi"""
    
    def __init__(self, model_path: str = None):
        self.model_path = model_path or str(Path("data/models"))
        self.models: Dict[str, Pipeline] = {}
        self.feature_importance: Dict[str, pd.DataFrame] = {}
        self.training_history: List[Dict[str, Any]] = []
        
        # Feature tanımları
        self.technical_features = [
            # Basic OHLC features
            'price_change', 'price_volatility', 'trend_strength',
            
            # RSI features
            'rsi_4h', 'rsi_15m', 'rsi_momentum', 'rsi_divergence',
            
            # Volume features
            'volume', 'volume_surge',
            
            # Temporal features
            'hour', 'day_of_week', 'is_weekend',
            
            # Lag features
            'price_lag_1', 'price_lag_2', 'price_lag_3',
            'volume_lag_1', 'volume_lag_2',
            'rsi_lag_1', 'rsi_lag_2',
            
            # Market context
            'btc_price_change', 'btc_dominance_change', 'funding_rate_change',
            
            # Interaction features
            'price_volume_ratio', 'price_volume_change',
            'rsi_trend', 'rsi_volume', 'market_risk', 'funding_sentiment'
        ]
        
        self.target_columns = ['profit_target']
        
    def prepare_training_data(self, min_samples: int = 1000) -> Tuple[pd.DataFrame, pd.Series]:
        """Eğitim verisini hazırla"""
        try:
            with db_manager.get_session() as session:
                # İşlemleri veritabanından al
                signals = session.query(TradeSignal).filter(
                    TradeSignal.execution_status == 'closed',
                    TradeSignal.pnl_percent.isnot(None)
                ).all()
                
                if len(signals) < min_samples:
                    logger.warning(f"Not enough data for training. Need {min_samples}, have {len(signals)}")
                    return None, None
                
                # DataFrame'e çevir
                data = []
                for signal in signals:
                    params = json.loads(signal.parameters) if signal.parameters else {}
                    data.append({
                        'timestamp': signal.timestamp,
                        'coin': signal.coin,
                        'direction': signal.direction,
                        'entry_price': signal.entry_price,
                        'close': signal.entry_price,  # çıkış fiyatı olarak
                        'volume': signal.volume,
                        'rsi_4h': signal.rsi_4h,
                        'rsi_15m': signal.rsi_15m,
                        'btc_price': signal.btc_price,
                        'btc_dominance': signal.btc_dominance,
                        'funding_rate': signal.funding_rate,
                        'pnl_percent': signal.pnl_percent,
                        'trade_duration': signal.trade_duration,
                        'market_condition': signal.market_condition,
                        **params
                    })
                
                df = pd.DataFrame(data)
                
                # Feature engineering
                df = FeatureEngineer.create_technical_features(df)
                df = FeatureEngineer.create_interaction_features(df)
                
                # Target variable
                df['profit_target'] = (df['pnl_percent'] > 0).astype(int)
                
                # Mevcut feature'ları filtrele
                available_features = [col for col in self.technical_features if col in df.columns]
                
                X = df[available_features]
                y = df['profit_target']
                
                return X, y
                
        except Exception as e:
            logger.error(f"Error preparing training data: {e}")
            return None, None
    
    def train_model(self, market_condition: str = 'all') -> bool:
        """Modeli eğit"""
        try:
            X, y = self.prepare_training_data()
            
            if X is None or y is None:
                return False
            
            # Train/test split
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # Model pipeline oluştur
            pipeline = Pipeline([
                ('scaler', StandardScaler()),
                ('classifier', RandomForestClassifier(
                    n_estimators=100,
                    max_depth=10,
                    min_samples_split=10,
                    min_samples_leaf=5,
                    random_state=42,
                    n_jobs=-1
                ))
            ])
            
            # Hyperparameter tuning (isteğe bağlı)
            if len(X) > 5000:  # Sadece yeterli veri varsa
                param_grid = {
                    'classifier__n_estimators': [100, 200],
                    'classifier__max_depth': [10, 15, 20],
                    'classifier__min_samples_split': [5, 10, 15]
                }
                
                grid_search = GridSearchCV(
                    pipeline, param_grid, cv=5, n_jobs=-1, scoring='f1'
                )
                
                grid_search.fit(X_train, y_train)
                best_model = grid_search.best_estimator_
            else:
                best_model = pipeline
                best_model.fit(X_train, y_train)
            
            # Modeli kaydet
            self.models[market_condition] = best_model
            
            # Performans değerlendirme
            y_pred = best_model.predict(X_test)
            y_pred_proba = best_model.predict_proba(X_test)[:, 1]
            
            metrics = {
                'accuracy': accuracy_score(y_test, y_pred),
                'precision': precision_score(y_test, y_pred),
                'recall': recall_score(y_test, y_pred),
                'f1': f1_score(y_test, y_pred),
                'roc_auc': roc_auc_score(y_test, y_pred_proba) if len(np.unique(y_test)) > 1 else 0.0
            }
            
            # Feature importance
            if hasattr(best_model.named_steps['classifier'], 'feature_importances_'):
                importance_df = pd.DataFrame({
                    'feature': X.columns,
                    'importance': best_model.named_steps['classifier'].feature_importances_
                }).sort_values('importance', ascending=False)
                
                self.feature_importance[market_condition] = importance_df
            
            # Training history
            training_record = {
                'timestamp': datetime.utcnow().isoformat(),
                'market_condition': market_condition,
                'sample_size': len(X),
                'metrics': metrics,
                'top_10_features': importance_df.head(10).to_dict() if market_condition in self.feature_importance else None
            }
            
            self.training_history.append(training_record)
            
            # Modeli kaydet
            self.save_model(market_condition)
            
            logger.info(f"Model trained for {market_condition}: Accuracy={metrics['accuracy']:.3f}, F1={metrics['f1']:.3f}")
            return True
            
        except Exception as e:
            logger.error(f"Model training failed: {e}")
            return False
    
    def predict(self, features: Dict[str, Any], market_condition: str = 'all') -> Dict[str, Any]:
        """Tahmin yap"""
        try:
            if market_condition not in self.models:
                logger.warning(f"Model not found for {market_condition}, using default")
                market_condition = 'all'
                if market_condition not in self.models:
                    return {'prediction': None, 'confidence': 0.0, 'error': 'Model not available'}
            
            model = self.models[market_condition]
            
            # Feature dictionary'e göre DataFrame oluştur
            feature_df = pd.DataFrame([features])
            
            # Eksik feature'ları 0 ile doldur
            for feature in self.technical_features:
                if feature not in feature_df.columns:
                    feature_df[feature] = 0
            
            # Feature sıralamasını koru
            X = feature_df[self.technical_features]
            
            # Tahmin
            prediction = model.predict(X)[0]
            prediction_proba = model.predict_proba(X)[0]
            
            confidence = prediction_proba[1] if prediction == 1 else prediction_proba[0]
            
            return {
                'prediction': int(prediction),
                'confidence': float(confidence),
                'win_probability': float(prediction_proba[1]),
                'should_trade': confidence > 0.6 and prediction == 1
            }
            
        except Exception as e:
            logger.error(f"Prediction failed: {e}")
            return {'prediction': None, 'confidence': 0.0, 'error': str(e)}
    
    def save_model(self, market_condition: str):
        """Modeli kaydet"""
        try:
            save_path = Path(self.model_path) / f"model_{market_condition}.joblib"
            save_path.parent.mkdir(parents=True, exist_ok=True)
            
            joblib.dump(self.models[market_condition], save_path)
            
            # Feature importance ve history'yi kaydet
            metadata = {
                'feature_importance': self.feature_importance.get(market_condition, {}).to_dict() if market_condition in self.feature_importance else {},
                'training_history': self.training_history,
                'last_training': datetime.utcnow().isoformat()
            }
            
            metadata_path = Path(self.model_path) / f"metadata_{market_condition}.json"
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=4)
                
            logger.info(f"Model saved to {save_path}")
            
        except Exception as e:
            logger.error(f"Failed to save model: {e}")
    
    def load_model(self, market_condition: str) -> bool:
        """Modeli yükle"""
        try:
            load_path = Path(self.model_path) / f"model_{market_condition}.joblib"
            
            if not load_path.exists():
                logger.warning(f"Model file not found: {load_path}")
                return False
                
            self.models[market_condition] = joblib.load(load_path)
            
            # Metadata yükle
            metadata_path = Path(self.model_path) / f"metadata_{market_condition}.json"
            if metadata_path.exists():
                with open(metadata_path, 'r') as f:
                    metadata = json.load(f)
                    
                    self.training_history = metadata.get('training_history', [])
                    
                    if 'feature_importance' in metadata:
                        self.feature_importance[market_condition] = pd.DataFrame(metadata['feature_importance'])
                        
            logger.info(f"Model loaded from {load_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            return False
    
    def get_model_metrics(self, market_condition: str = 'all') -> Dict[str, Any]:
        """Model performans metriklerini al"""
        if not self.training_history:
            return {}
            
        # Son training metriklerini getir
        latest_training = None
        for record in reversed(self.training_history):
            if record['market_condition'] == market_condition:
                latest_training = record
                break
                
        return latest_training if latest_training else {}
    
    async def train_async(self, market_condition: str = 'all') -> bool:
        """Asenkron model eğitimi"""
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, self.train_model, market_condition)
        return result


# Global ML predictor instance
ml_predictor = MLPredictor()