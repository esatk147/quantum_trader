# main.py
import sys
import os
import asyncio
import signal
import threading
from datetime import datetime
from pathlib import Path
import json
import pandas as pd
import numpy as np
from concurrent.futures import ThreadPoolExecutor
import queue

# Core imports
from core.config import config
from core.logger import logger_manager, logger
from core.database import db_manager
from core.exchange import exchange_manager
from core.thread_manager import thread_manager, hybrid_manager

# ML and Analytics
from ml.predictor import ml_predictor
from portfolio.optimizer import PortfolioOptimizer
from portfolio.correlation import correlation_analyzer
from core.data_collector import data_collector

# Strategies
from strategies.rsi_bands import RSIBandsStrategy
from strategies.perfect_entry import PerfectEntryV9Strategy

# UI
from ui.dashboard import Dashboard

# WebSocket
from core.websocket import AsyncWebSocket


class QuantumTraderApp:
    """Ana uygulama sınıfı"""
    
    def __init__(self):
        # Core components
        self.dashboard = None
        self.exchange = None
        self.db = None
        
        # Strategies
        self.strategies = {
            'RSI Bands': RSIBandsStrategy(),
            'Perfect Entry V9': PerfectEntryV9Strategy()
        }
        self.active_strategy = None
        
        # State
        self.is_running = False
        self.watchlist_spot = []
        self.watchlist_futures = []
        self.open_positions = {}
        self.pending_orders = {}
        self.order_history = []
        
        # Settings
        self.trading_mode = 'spot'
        self.trading_enabled = False
        self.telegram_enabled = True
        self.demo_mode = True
        
        # Threading
        self.executor = ThreadPoolExecutor(max_workers=10)
        self.async_loop = None
        self.shutdown_event = threading.Event()
        
        # WebSocket
        self.ws_manager = None
        
        # Initialize
        self.initialize_system()
    
    def initialize_system(self):
        """Sistemi başlat"""
        try:
            # Create directories
            config.ensure_directories()
            
            # Load configuration
            config.load_env()
            
            # Initialize logger
            logger_manager.setup_logger(config.get('log_level', 'INFO'))
            logger.info("System initialization started")
            
            # Initialize database
            self.db = db_manager
            if not self.db.connect():
                raise Exception("Database connection failed")
            
            # Initialize exchange
            self.exchange = exchange_manager
            
            logger.info("System initialization completed")
            
        except Exception as e:
            logger.error(f"System initialization failed: {e}")
            sys.exit(1)
    
    def init_exchange(self):
        """Exchange'e bağlan"""
        try:
            if self.exchange.connect():
                logger.info(f"Connected to {config.get('exchange_name')} exchange")
                return True
            else:
                logger.error("Exchange connection failed")
                return False
                
        except Exception as e:
            logger.error(f"Exchange initialization failed: {e}")
            return False
    
    def init_telegram(self):
        """Telegram bot'unu başlat"""
        try:
            import telegram
            
            token = config.get('telegram_token')
            chat_id = config.get('telegram_chat_id')
            
            if not token or not chat_id:
                logger.warning("Telegram credentials not provided")
                return False
            
            self.telegram_bot = telegram.Bot(token=token)
            self.telegram_chat_id = chat_id
            
            # Test message
            self.telegram_bot.send_message(chat_id=chat_id, text="🚀 Quantum Trader Pro - System Online!")
            
            logger.info("Telegram bot initialized")
            return True
            
        except Exception as e:
            logger.error(f"Telegram initialization failed: {e}")
            return False
    
    def initialize_ml(self):
        """ML sistemini başlat"""
        try:
            # Load model if exists
            for strategy_name in self.strategies:
                if ml_predictor.load_model(strategy_name):
                    logger.info(f"ML model loaded for {strategy_name}")
                else:
                    logger.info(f"No ML model found for {strategy_name}")
            
            # Check if we have enough data to train
            signal_count = data_collector.get_signal_statistics().get('total_signals', 0)
            learning_threshold = config.get('learning_threshold', 5000)
            
            if signal_count >= learning_threshold:
                self.train_ml_models()
            else:
                logger.info(f"ML training requires {learning_threshold - signal_count} more signals")
                
        except Exception as e:
            logger.error(f"ML initialization failed: {e}")
    
    def train_ml_models(self):
        """ML modellerini eğit"""
        def train_task():
            for strategy_name in self.strategies:
                if ml_predictor.train_model(strategy_name):
                    logger.info(f"ML model trained for {strategy_name}")
                else:
                    logger.error(f"ML training failed for {strategy_name}")
        
        self.executor.submit(train_task)
    
    async def start_websocket(self):
        """WebSocket bağlantısını başlat"""
        try:
            if config.get('exchange_name').lower() == 'binance':
                async with AsyncWebSocket('binance') as ws:
                    self.ws_manager = ws
                    
                    # Subscribe to priority symbols
                    for symbol in (self.watchlist_spot + self.watchlist_futures)[:5]:
                        await ws.subscribe_ticker(symbol, self.on_ticker_update)
                        await ws.subscribe_orderbook(symbol, self.on_orderbook_update)
                        await ws.subscribe_trades(symbol, self.on_trade_update)
                    
                    # Keep connection alive
                    while self.is_running:
                        await asyncio.sleep(1)
                        
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
    
    async def on_ticker_update(self, message):
        """Ticker güncellemelerini işle"""
        try:
            # Extract data and update strategies
            symbol = message.data.get('s')
            price = float(message.data.get('c'))
            
            # Update strategy data
            if symbol in self.strategies:
                # Real-time strategy updates
                pass
                
        except Exception as e:
            logger.error(f"Ticker processing error: {e}")
    
    async def on_orderbook_update(self, message):
        """Order book güncellemelerini işle"""
        # Implement order book processing
        pass
    
    async def on_trade_update(self, message):
        """Trade akışını işle"""
        # Implement trade flow processing
        pass
    
    def start_scanning(self):
        """Tarama işlemini başlat"""
        self.is_running = True
        
        def scan_loop():
            while self.is_running and not self.shutdown_event.is_set():
                try:
                    # Scan watchlist
                    if self.trading_mode == 'spot':
                        watchlist = self.watchlist_spot
                    else:
                        watchlist = self.watchlist_futures
                    
                    if not watchlist:
                        logger.warning("Watchlist is empty")
                        continue
                    
                    # Parallel scanning
                    with ThreadPoolExecutor(max_workers=10) as scan_executor:
                        futures = []
                        for symbol in watchlist:
                            future = scan_executor.submit(self.scan_symbol, symbol)
                            futures.append(future)
                        
                        # Process results
                        for future in futures:
                            try:
                                result = future.result()
                                if result:
                                    self.process_signal(result)
                            except Exception as e:
                                logger.error(f"Scan error: {e}")
                    
                    # Sleep based on interval
                    interval_seconds = self.get_interval_seconds()
                    self.shutdown_event.wait(interval_seconds)
                    
                except Exception as e:
                    logger.error(f"Scan loop error: {e}")
                    self.shutdown_event.wait(5)
    
    def scan_symbol(self, symbol):
        """Tek bir sembolü tara"""
        try:
            # Get data
            df = self.exchange.get_ohlcv_df(symbol, config.get('timeframe', '1h'))
            if df.empty:
                return None
            
            # Run strategies
            results = []
            for strategy_name, strategy in self.strategies.items():
                signal, signal_data = strategy.run(df)
                if signal:
                    results.append({
                        'symbol': symbol,
                        'strategy': strategy_name,
                        'signal': signal,
                        'data': signal_data
                    })
            
            return results
            
        except Exception as e:
            logger.error(f"Symbol scan error for {symbol}: {e}")
            return None
    
    def process_signal(self, signal_data):
        """Sinyali işle"""
        try:
            for signal in signal_data:
                # Save signal to database
                self.save_signal(signal)
                
                # Check ML confidence if model is trained
                ml_result = self.get_ml_prediction(signal)
                
                # Send telegram notification
                self.send_telegram_notification(signal, ml_result)
                
                # Execute trade if enabled
                if self.trading_enabled and self.should_trade(signal, ml_result):
                    self.execute_trade(signal)
                
        except Exception as e:
            logger.error(f"Signal processing error: {e}")
    
    def save_signal(self, signal):
        """Sinyali kaydet"""
        signal_data = {
            'coin': signal['symbol'],
            'direction': signal['signal'],
            'entry_price': signal['data'].get('close'),
            'timestamp': datetime.utcnow(),
            'parameters': signal['data']
        }
        data_collector.save_signal(signal_data)
    
    def get_ml_prediction(self, signal):
        """ML tahmini al"""
        try:
            strategy_name = signal['strategy']
            return ml_predictor.predict(signal['data'], strategy_name)
        except Exception as e:
            logger.error(f"ML prediction error: {e}")
            return None
    
    def should_trade(self, signal, ml_result):
        """Trade yapılıp yapılmayacağını kontrol et"""
        if not ml_result:
            return True  # ML not available, use strategy signal
        
        return ml_result.get('should_trade', False)
    
    def execute_trade(self, signal):
        """Trade gerçekleştir"""
        try:
            symbol = signal['symbol']
            direction = signal['signal']
            
            # Get position size
            position_size = self.calculate_position_size(signal)
            
            # Place order
            if position_size > 0:
                self.place_order(symbol, direction, position_size)
                
        except Exception as e:
            logger.error(f"Trade execution error: {e}")
    
    def calculate_position_size(self, signal):
        """Pozisyon büyüklüğünü hesapla"""
        # Risk management based position sizing
        account_balance = self.get_account_balance()
        risk_percent = config.get('risk_percent', 1.0)
        position_size = account_balance * (risk_percent / 100)
        
        return position_size
    
    def get_account_balance(self):
        """Hesap bakiyesini al"""
        try:
            balance = self.exchange.fetch_balance()
            if self.trading_mode == 'spot':
                return balance.get('USDT', {}).get('free', 0)
            else:
                return balance.get('USDT', {}).get('wallet_balance', 0)
        except Exception as e:
            logger.error(f"Balance fetch error: {e}")
            return 0
    
    def place_order(self, symbol, side, amount):
        """Emir ver"""
        try:
            # Calculate stop loss and take profit
            current_price = self.exchange.fetch_ticker(symbol)['last']
            sl_price = self.calculate_stop_loss(current_price, side)
            tp_price = self.calculate_take_profit(current_price, side)
            
            # Place main order
            order = self.exchange.create_order(
                symbol=symbol,
                order_type='market',
                side=side.lower(),
                amount=amount
            )
            
            # Save order
            self.pending_orders[order['id']] = {
                'symbol': symbol,
                'side': side,
                'amount': amount,
                'price': order.get('price', current_price),
                'timestamp': datetime.utcnow()
            }
            
            logger.info(f"Order placed: {symbol} {side} {amount}")
            
        except Exception as e:
            logger.error(f"Order placement error: {e}")
    
    def calculate_stop_loss(self, entry_price, direction):
        """Stop loss hesapla"""
        sl_percent = config.get('stop_loss_percent', 2.0)
        if direction == 'BUY':
            return entry_price * (1 - sl_percent / 100)
        else:
            return entry_price * (1 + sl_percent / 100)
    
    def calculate_take_profit(self, entry_price, direction):
        """Take profit hesapla"""
        tp_percent = config.get('take_profit_percent', 3.0)
        if direction == 'BUY':
            return entry_price * (1 + tp_percent / 100)
        else:
            return entry_price * (1 - tp_percent / 100)
    
    def send_telegram_notification(self, signal, ml_result):
        """Telegram bildirimi gönder"""
        try:
            if not self.telegram_enabled or not hasattr(self, 'telegram_bot'):
                return
            
            symbol = signal['symbol']
            direction = signal['signal']
            strategy = signal['strategy']
            price = signal['data'].get('close', 0)
            
            # Format message
            message = f"""
🔔 {strategy} Strategy Signal
━━━━━━━━━━━━━━━━━━━
📊 Symbol: {symbol}
📈 Signal: {direction}
💰 Price: ${price:.4f}
⚡ Strategy: {strategy}
"""
            
            if ml_result:
                message += f"""
🤖 ML Prediction: {'✅ Trade' if ml_result.get('should_trade') else '❌ Skip'}
🎯 Confidence: {ml_result.get('confidence', 0):.2%}
📈 Win Probability: {ml_result.get('win_probability', 0):.2%}
"""
            
            self.telegram_bot.send_message(
                chat_id=self.telegram_chat_id,
                text=message,
                parse_mode='HTML'
            )
            
        except Exception as e:
            logger.error(f"Telegram notification error: {e}")
    
    def stop_scanning(self):
        """Tarama işlemini durdur"""
        self.is_running = False
        self.shutdown_event.set()
        logger.info("Scanning stopped")
    
    def stop(self):
        """Uygulamayı kapat"""
        try:
            logger.info("Shutting down...")
            
            self.stop_scanning()
            
            # Close exchange connection
            if self.exchange:
                self.exchange.close()
            
            # Close database connection
            if self.db:
                self.db.close()
            
            # Shutdown thread managers
            thread_manager.shutdown()
            hybrid_manager.shutdown()
            
            # Close executor
            self.executor.shutdown(wait=True)
            
            logger.info("Application shutdown complete")
            
        except Exception as e:
            logger.error(f"Shutdown error: {e}")
    
    def run(self):
        """Uygulamayı çalıştır"""
        try:
            # Create dashboard
            self.dashboard = Dashboard()
            
            # Run dashboard in main thread
            self.dashboard.run(self)
            
        except Exception as e:
            logger.error(f"Application error: {e}")
        finally:
            self.stop()
    
    def get_interval_seconds(self):
        """Tarama interval'ını saniyeye çevir"""
        interval = config.get('timeframe', '1h')
        intervals = {
            '1m': 60,
            '5m': 300,
            '15m': 900,
            '30m': 1800,
            '1h': 3600,
            '4h': 14400,
            '1d': 86400
        }
        return intervals.get(interval, 3600)
    
    # GUI Interface Methods
    def quick_scan(self):
        """Hızlı sinyal taraması"""
        # Implement quick scan
        pass
    
    def rebalance_portfolio(self):
        """Portföyü yeniden dengele"""
        try:
            if not self.open_positions:
                return
            
            # Get current portfolio
            current_portfolio = self.get_current_portfolio()
            
            # Optimize portfolio
            optimizer = PortfolioOptimizer(self.exchange)
            optimal_allocation = asyncio.run(
                optimizer.optimize_portfolio(
                    self.watchlist_spot if self.trading_mode == 'spot' else self.watchlist_futures,
                    self.get_account_balance(),
                    current_portfolio
                )
            )
            
            # Execute rebalancing
            actions = optimizer.rebalance_portfolio(current_portfolio, optimal_allocation)
            for action in actions:
                self.execute_rebalance_action(action)
                
        except Exception as e:
            logger.error(f"Portfolio rebalancing error: {e}")
    
    def emergency_exit_all_positions(self):
        """Tüm pozisyonları kapat"""
        try:
            for position_id, position in self.open_positions.items():
                self.close_position(position_id, 'emergency')
                
        except Exception as e:
            logger.error(f"Emergency exit error: {e}")
    
    def get_current_portfolio(self):
        """Mevcut portföyü al"""
        # Implementation
        return self.open_positions
    
    def execute_rebalance_action(self, action):
        """Rebalance aksiyonunu gerçekleştir"""
        # Implementation
        pass
    
    def close_position(self, position_id, reason):
        """Pozisyonu kapat"""
        # Implementation
        pass


def signal_handler(signum, frame):
    """Sistem sinyallerini yakala"""
    logger.info("Received shutdown signal, cleaning up...")
    if 'app' in globals():
        app.stop()
    sys.exit(0)


if __name__ == "__main__":
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        # Create and run application
        app = QuantumTraderApp()
        app.run()
        
    except Exception as e:
        logger.critical(f"Application failed: {e}")
        sys.exit(1)